import chalk from 'chalk'
import path from 'path'
import { fileURLToPath } from 'url'
import { getContentType } from 'zapo-js'
import { hotModule } from '../lib/hotCore.js'
import { loadPlugins } from '../lib/loadPlugins.js'
import { registerWelcome } from '../lib/welcome.js'

import { saveRawMessage } from '../db/rawMessage.js'
import { saveOrUpdateContact } from '../db/contacts.js'
import { isTrustedFeature } from '../db/group.js'

const handlerMod = hotModule('../handler.js', import.meta.url)
const utilsMod = hotModule('../lib/utils.js', import.meta.url)
const groupAndBotMod = hotModule('../lib/groupAndBot.js', import.meta.url)
const groupDetectionMod = hotModule('../lib/groupDetection.js', import.meta.url)
const functionMod = hotModule('../lib/function.js', import.meta.url)
const settingsMod = hotModule('../settings.js', import.meta.url)
const groupCacheMod = hotModule('../db/groupCache.js', import.meta.url)
const gameManagerMod = hotModule('../lib/gameManager.js', import.meta.url)
const antiDeleteMod = hotModule('../lib/antiDelete.js', import.meta.url)
const deviceAlertMod = hotModule('../lib/deviceAlert.js', import.meta.url)
const aiChatMod = hotModule('../lib/aiChat.js', import.meta.url)
import { claimMessageOnce } from '../lib/messageClaim.js'
import { checkGameInput } from '../lib/gameManager.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PLUGINS_DIR = path.join(__dirname, '..', 'plugins')

const TYPING_REFRESH = 8_000
const PROCESS_STARTED_AT = Math.floor(Date.now() / 1000)

const handledCommandIds = new Set()
const MAX_HANDLED_COMMANDS = 4096

function claimCommand(id) {
  if (!id || handledCommandIds.has(id)) return false
  handledCommandIds.add(id)
  if (handledCommandIds.size > MAX_HANDLED_COMMANDS) {
    handledCommandIds.delete(handledCommandIds.values().next().value)
  }
  return true
}

function isHistoricalMessage(m) {
  const offline = m.raw?.offline === true ||
    m.raw?.offline === '1' ||
    m.raw?.rawNode?.attrs?.offline === '1'
  if (offline) return true

  const timestamp = Number(m.raw?.messageTimestamp)
  return Number.isFinite(timestamp) && timestamp > 0 && timestamp < PROCESS_STARTED_AT
}

function extractArgs(m) {
  if (!m.command) return []
  const stripped = m.text.slice(m.prefix.length + m.command.length).trim()
  return stripped ? stripped.split(/\s+/) : []
}

function serializeOutgoing(sendEvent, sock) {
  if (!sendEvent?.id || !sendEvent?.to) return null

  const messageType = getContentType(sendEvent.message)
  if (!messageType) return null

  const content = sendEvent.message[messageType]

  const text =
    sendEvent.message.conversation ??
    content?.text ??
    content?.caption ??
    null

  const mime = content?.mimetype || ''
  const creds = sock.getCredentials?.()
  const senderJid = handlerMod.normalizeJid(creds?.meJid)
  const { prefix, command } = handlerMod.extractCommand(text)

  return {
    raw: sendEvent,
    id: sendEvent.id,
    chat: sendEvent.to,
    sender: senderJid,
    pushName: creds?.pushName || 'Bot',
    isGroup: sendEvent.to?.endsWith('@g.us') ?? false,
    isFromMe: true,
    type: messageType,
    prefix,
    command,
    text,
    isMedia: !!mime,
    mediaType: utilsMod.detectMediaType(mime)
  }
}

async function processCommand(m, sock) {
  if (!m.command) return

  const plugin = global.plugins?.get(m.command)
  if (!plugin) return

  const config = settingsMod.config

  const trusted = m.isGroup && (isTrustedFeature(m.chat, plugin.command) || isTrustedFeature(m.sender, plugin.command))

  const selfMode = groupAndBotMod.getBotSettingValue('self') || (m.isGroup && groupAndBotMod.isGroupSelf(m.chat))
  if (selfMode && !m.isOwner && !trusted) return
  if (utilsMod.isLocked() && plugin.command !== 'lock') return

  const isGroupOnly = plugin.groupOnly || plugin.onlyGroup
  const isAdminOnly = plugin.adminOnly || plugin.onlyAdmin
  const isBotAdminOnly = plugin.botAdminOnly || plugin.onlyBotAdmin

  if (m.isGroup && (isAdminOnly || isBotAdminOnly) && !groupCacheMod.getCachedGroupMetadata(m.chat)) {
    await groupCacheMod.getGroupMetadata(m.chat, sock).catch(() => null)
  }

  if (isGroupOnly && !m.isGroup) return m.reply(config.pesan.groupOnly)

  if (!m.isOwner && !trusted) {
    const isOwnerOnly = plugin.ownerOnly || plugin.onlyOwner
    const isPrivateOnly = plugin.privateOnly || plugin.onlyPrivate

    if (isOwnerOnly && !m.isOwner) return m.reply(config.pesan.ownerOnly)
    if (isPrivateOnly && m.isGroup) return m.reply(config.pesan.privateOnly)
    if (isAdminOnly && !m.isGroup) return m.reply(config.pesan.groupOnly)
    if (isAdminOnly && !m.isAdmin) return m.reply(config.pesan.adminOnly)
    if (isBotAdminOnly && !m.isBotAdmin) return m.reply(config.pesan.botAdmin)
  }

  const args = extractArgs(m)
  m.args = args

  console.log(chalk.magenta(`[CMD] -> .${m.command} ${args.join(' ')}`.trim()))

  if (plugin.wait) {
    await sock.message.send(m.chat, config.pesan.wait, { quote: m.raw })
  }

  const context = { sock, args, plugins: global.plugins }

  let typingInterval = null

  if (plugin.typing) {
    await sock.presence.sendChatstate(m.chat, { state: 'composing' }).catch(() => { })
    typingInterval = setInterval(() => {
      sock.presence.sendChatstate(m.chat, { state: 'composing' }).catch(() => { })
    }, TYPING_REFRESH)
  }

  try {
    await plugin.execute(m, context)
  } finally {
    if (typingInterval) {
      clearInterval(typingInterval)
      typingInterval = null
      await sock.presence.sendChatstate(m.chat, { state: 'paused' }).catch(() => { })
    }
  }
}


export async function messageHandler(sock) {
  await Promise.all([
    handlerMod.__ready,
    utilsMod.__ready,
    groupAndBotMod.__ready,
    groupDetectionMod.__ready,
    functionMod.__ready,
    settingsMod.__ready,
    groupCacheMod.__ready,
    gameManagerMod.__ready,
    antiDeleteMod.__ready,
    deviceAlertMod.__ready,
    aiChatMod.__ready
  ])

  const { temp: loadedPlugins } = await loadPlugins(PLUGINS_DIR)
  //ini buat plugin
  global.plugins = loadedPlugins
  //ini buat bungkam
  global.bungkamList = global.bungkamList || new Set()
  //ini buat welcome left
  registerWelcome(sock)

  sock.on('message', async (event) => {
    const config = settingsMod.config

    if (config.eventMessage || config.eventAll) {
      handlerMod.logRawDebug(event)
    }

    const m = handlerMod.serializeMessage(event, sock)
    if (!m) return

    if (antiDeleteMod.isRevokeEvent(event)) {
      await antiDeleteMod.handleAntiDelete(m, event, sock).catch((err) => {
        console.error(chalk.red('[ANTIDELETE] Gagal proses event delete:'), err?.message || err)
      })
      return
    }

    if (!isHistoricalMessage(m)) {
      deviceAlertMod.checkNewDevice(m, sock).catch(() => { })
    }
      

    if (m.sender && !m.fromMe) {
      const { lidJid, pnJid } = handlerMod.extractIdentityPair(event.key)

      const checkLid = lidJid ? lidJid.split('@')[0].split(':')[0] + '@s.whatsapp.net' : ''
      const checkPn = pnJid ? pnJid.split('@')[0].split(':')[0] + '@s.whatsapp.net' : ''
      const checkSender = m.sender ? m.sender.split('@')[0].split(':')[0] + '@s.whatsapp.net' : ''

      if (global.bungkamList.has(checkLid) || global.bungkamList.has(checkPn) || global.bungkamList.has(checkSender)) {
        const stanzaId = m.id || m.key?.id
        if (stanzaId) {
          try {
            const temp1 = await sock.message.send(m.chat, {
                groupStatusMessageV2: { message: { extendedTextMessage: { text: '', contextInfo: { isGroupStatus: true } } } }
            }, {})
            const tempId = temp1.id || (temp1.key && temp1.key.id)

            const temp2 = await sock.message.send(m.chat, '\0', {
                editKey: { id: tempId }, id: stanzaId
            })
            const temp2Id = temp2.id || (temp2.key && temp2.key.id)

            await new Promise(resolve => setTimeout(resolve, 100))

            await Promise.allSettled([
                sock.message.send(m.chat, { type: 'revoke', target: { remoteJid: m.chat, id: tempId, fromMe: true } }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true }),
                sock.message.send(m.chat, { type: 'revoke', target: { remoteJid: m.chat, id: temp2Id, fromMe: true } }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true })
            ])
          } catch (e) {
            console.error(chalk.red('[AUTO BUNGKAM ERROR] Santet gagal:'), e)
          }
        }
        return
      }
    }
   
  const isGameHandled = await checkGameInput(m, sock)
    if (isGameHandled) return
    const historical = isHistoricalMessage(m)

    // AI "ler": jalan di background (ga di-await) & ga pake `return`,
    // jadi pesan tetep disimpan ke DB, ke-log, dan kena enforceGroupPolicies (antilink dll).
    // Pesan lama (offline/backlog) ga dibales.
    if (!historical && aiChatMod.isAiTrigger(m, sock)) {
      aiChatMod.handleAI(m, sock).catch((err) => console.error(chalk.red('[AI] handler error:'), err?.message || err))
    } else if (m.command && !historical && claimCommand(m.id)) {
      await processCommand(m, sock)
        .catch((err) => functionMod.sendErrorToOwner(sock, err, m, m.command))
    }

    if (m.isGroup && !isHistoricalMessage(m)) {
      await groupDetectionMod.enforceGroupPolicies(m, sock).catch(() => { })
    }

    const { lidJid, pnJid } = handlerMod.extractIdentityPair(event.key)
    const contactResult = saveOrUpdateContact({ lidJid, pnJid, pushName: event.pushName })

    if (m.isNewsletter) {
      handlerMod.logPesanMasuk(m, contactResult)
      saveRawMessage(m)
      return
    }

    if (m.isGroup) {
      groupCacheMod.getGroupMetadata(m.chat, sock).catch(() => { })
    }

    if (!groupAndBotMod.isSilentLog(m.chat)) {
      handlerMod.logPesanMasuk(m, contactResult)
    }
    saveRawMessage(m)
  })

  sock.on('message_send', (sendEvent) => {
    const outgoing = serializeOutgoing(sendEvent, sock)
    if (!outgoing) return

    saveRawMessage(outgoing)
  })
}
