// index.js

import chalk from 'chalk'
import { createSocket } from './src/createSocket.js'
import { connectionHandler } from './src/connectionHandler.js'
import { messageHandler } from './src/messageHandler.js'
import { groupEventHandler } from './src/groupEventHandler.js'
import { startThumbAutoRefresh } from './lib/thumbAutoRefresh.js'
import { startDbMaintenance } from './lib/dbMaintenance.js'
import { ensureRpgReady, flushRpgNow } from './lib/rpgMongo.js'

let sock

try {
  // Connect & load semua data RPG dari MongoDB ke memory DULU, sebelum
  // socket nyambung / plugin mulai jalan -- biar gak ada race condition
  // (pesan RPG masuk duluan sebelum data user ke-load).
  await ensureRpgReady()

  sock = createSocket()

  connectionHandler(sock)
  groupEventHandler(sock)

  messageHandler(sock).catch(err => {
    console.error(
      chalk.red('[MESSAGE] Handler error:'),
      err?.stack || err?.message || err
    )
  })

  await sock.connect()

  startThumbAutoRefresh(sock)
  startDbMaintenance()

} catch (err) {
  console.error(
    chalk.red('[WA] Gagal connect awal:'),
    err?.stack || err?.message || err
  )

  process.exit(1)
}

let shuttingDown = false

async function shutdown(signal) {
  if (shuttingDown) return

  shuttingDown = true

  console.log(
    chalk.yellow(`\n[WA] Menerima ${signal}, menutup koneksi...`)
  )

  try {
    if (sock) {
      await sock.disconnect()
    }
  } catch (err) {
    console.error(
      chalk.red('[WA] Gagal menutup koneksi:'),
      err?.stack || err?.message || err
    )
  }

  try {
    await flushRpgNow()
  } catch (err) {
    console.error(
      chalk.red('[RPG] Gagal flush data RPG terakhir ke MongoDB:'),
      err?.stack || err?.message || err
    )
  }

  process.exit(0)
}

process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))