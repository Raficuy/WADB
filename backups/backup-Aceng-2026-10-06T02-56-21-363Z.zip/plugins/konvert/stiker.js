import { Sticker } from 'wa-sticker-formatter'
import { config } from '../../settings.js'
import { downloadContentFromMessage } from 'baileys'

export default {
  command: 'sticker',
  alias: ['s', 'stiker'],
  category: 'konvert',
  description: 'Mengubah gambar atau video pendek menjadi stiker dengan watermark.',
  help: '(kirim/reply gambar atau video)',
  typing: true,

  async execute(m, { sock, q }) {
    try {
      const qi = q || m.quoted || m
      const type = qi?.type || qi?.mtype || ''

      if (!type.includes('imageMessage') && !type.includes('videoMessage')) {
        return m.reply('❌ Kirim atau reply gambar/video dengan caption .s')
      }

      let mediaObj
      let mediaTypeStr

      const rawMsg = m.raw?.message
      if (m.quoted) {
        const quotedMsg = rawMsg?.extendedTextMessage?.contextInfo?.quotedMessage
        if (quotedMsg?.imageMessage) {
          mediaObj = quotedMsg.imageMessage
          mediaTypeStr = 'image'
        } else if (quotedMsg?.videoMessage) {
          mediaObj = quotedMsg.videoMessage
          mediaTypeStr = 'video'
        }
      } else {
        if (rawMsg?.imageMessage) {
          mediaObj = rawMsg.imageMessage
          mediaTypeStr = 'image'
        } else if (rawMsg?.videoMessage) {
          mediaObj = rawMsg.videoMessage
          mediaTypeStr = 'video'
        }
      }

      if (!mediaObj || !mediaTypeStr) {
        return m.reply('Gagal mengekstrak data media mentah dari pesan lu.')
      }

      if (mediaTypeStr === 'video' && mediaObj.seconds > 10) {
        return m.reply('Video kepanjangan! Maksimal 10 detik untuk dijadikan stiker.')
      }


      const stream = await downloadContentFromMessage(mediaObj, mediaTypeStr)
      const chunks = []
      for await (const chunk of stream) {
        chunks.push(chunk)
      }
      const mediaBuffer = Buffer.concat(chunks)

      if (!mediaBuffer || mediaBuffer.length === 0) {
        return m.reply('Gagal mengunduh buffer media.')
      }

      const packName = m.pushName || 'User'
      const authorName = config.botName || 'bot'

      const stickerQuality = mediaTypeStr === 'video' ? 15 : 70

      const sticker = new Sticker(mediaBuffer, {
        pack: packName,
        author: authorName,
        type: 'full', 
        quality: stickerQuality
      })

      const finalSticker = await sticker.toBuffer()

      await sock.message.send(m.chat, {
        type: 'sticker',
        media: finalSticker,
        mimetype: 'image/webp'
      }, { quoted: m })

    } catch (err) {
      console.error('[STICKER ERROR]', err)
      
      if (err.message?.includes('413')) {
        return m.reply(' Gagal: Ukuran video masih terlalu besar setelah di-compress. Coba durasi yang lebih pendek!')
      }
      
      return m.reply(`Duar Plugin Error:\n${err.message || err}`)
    }
  }
}