import { Sticker } from 'wa-sticker-formatter'
import { downloadContentFromMessage } from 'baileys'

export default {
  command: 'wm',
  alias: ['swm'],
  category: 'konvert',
  description: 'Mengubah watermark (pack dan author) dari stiker orang lain.',
  help: 'pack | author (reply sticker)',
  typing: true,

  async execute(m, { sock, args }) {
    if (!m.quoted || m.quoted.type !== 'stickerMessage') {
      return m.reply('❌ Reply stiker yang mau dicolong watermarknya.')
    }

    try {
      const text = args.join(' ')
      let [packName, authorName] = text.split('|')
      
      packName = packName ? packName.trim() : m.pushName || 'User'
      authorName = authorName ? authorName.trim() : ''

      const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
      const stickerMessage = rawQuoted?.stickerMessage

      if (!stickerMessage) {
        return m.reply('❌ Gagal mengekstrak data stiker mentah dari pesan lu.')
      }

      const stream = await downloadContentFromMessage(stickerMessage, 'sticker')
      const chunks = []
      for await (const chunk of stream) {
        chunks.push(chunk)
      }
      const mediaBuffer = Buffer.concat(chunks)

      if (!mediaBuffer || mediaBuffer.length === 0) {
        return m.reply('❌ Gagal mengunduh buffer stiker dari server.')
      }

      const sticker = new Sticker(mediaBuffer, {
        pack: packName,
        author: authorName,
        type: 'full',
        quality: 70
      })

      const finalSticker = await sticker.toBuffer()

      await sock.message.send(m.chat, {
        type: 'sticker',
        media: finalSticker,
        mimetype: 'image/webp'
      }, { quoted: m })

    } catch (err) {
      return m.reply(`Duar Plugin Error:\n${err.message || err}`)
    }
  }
}