export default {
  command: 'voxtts',
  alias: ['tts', 'voice', 'vox'],
  category: 'maker',
  description: 'Membuat Voice Note (TTS) dengan bypass Turnstile CF',
  help: '<teks>',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const text = args.join(' ').trim() || m.quoted?.text || ''
    
    if (!text) {
      return m.reply('Masukkan teks yang ingin diubah menjadi suara.')
    }

    const axios = (await import('axios')).default || await import('axios')
    let SocksProxyAgent
    try {
      const sp = await import('socks-proxy-agent')
      SocksProxyAgent = sp.SocksProxyAgent
    } catch (e) {
      return m.reply('Modul socks-proxy-agent tidak ditemukan. Silakan install terlebih dahulu.')
    }

    const TARGET_URL = 'https://voxlabs.ornzora.workers.dev'
    const TTS_ENDPOINT = `${TARGET_URL}/api/tts`
    const SITEKEY = '0x4AAAAAADxGWHctWk2yfROX'
    const BYPASS_API = 'https://api.ikyyxd.my.id/bypass/turnstile-cf-min'
    const PROXY_API_URL = 'https://api.ikyyxd.my.id/v2l/proxy-free/ikyy-xsample'

    try {
      const proxyRes = await axios.get(PROXY_API_URL, { timeout: 10000 })
      const rawList = Array.isArray(proxyRes.data) ? proxyRes.data : []
      const proxyList = rawList.map(p => {
        const parts = p.trim().split(':')
        return parts.length === 4 ? {
          host: parts[0], port: parseInt(parts[1]),
          userId: parts[2], password: parts[3]
        } : null
      }).filter(Boolean)

      if (proxyList.length === 0) {
        throw new Error('List proxy kosong dari server.')
      }

      let audioBuffer = null
      let lastError = null
      const maxRetries = 3

      for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
          const activeProxy = proxyList[attempt % proxyList.length]
          const proxyUrl = `socks5://${activeProxy.userId}:${activeProxy.password}@${activeProxy.host}:${activeProxy.port}`
          const agent = new SocksProxyAgent(proxyUrl)

          const client = axios.create({
            httpAgent: agent,
            httpsAgent: agent,
            timeout: 60000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': '*/*',
              'Content-Type': 'application/json',
              'Origin': TARGET_URL,
              'Referer': `${TARGET_URL}/`
            }
          })

          const bypassRes = await axios.get(`${BYPASS_API}?url=${encodeURIComponent(TTS_ENDPOINT)}&sitekey=${SITEKEY}`, { timeout: 30000 })
          
          if (!bypassRes.data?.status || !bypassRes.data?.result?.token) {
            throw new Error('Gagal mem-bypass Turnstile.')
          }

          const token = bypassRes.data.result.token

          const payload = {
            text: text,
            lang: 0,
            reverb: true,
            turnstileToken: token,
            voice: 1 
          }

          const ttsRes = await client.post(TTS_ENDPOINT, payload, { responseType: 'arraybuffer' })

          const contentType = ttsRes.headers['content-type'] || ''
          if (contentType.includes('application/json')) {
            throw new Error(Buffer.from(ttsRes.data).toString())
          }

          if (ttsRes.status === 200 && ttsRes.data.byteLength > 1000) {
            audioBuffer = Buffer.from(ttsRes.data)
            break
          }
        } catch (err) {
          lastError = err
          if (err.response?.status === 403) continue
        }
      }

      if (!audioBuffer) throw lastError

      await sock.message.send(m.chat, {
        type: 'audio',
        media: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: true 
      }, { quote: m.raw })

    } catch (err) {
      return m.reply(`Gagal membuat TTS: ${err.message || err}`)
    }
  }
}