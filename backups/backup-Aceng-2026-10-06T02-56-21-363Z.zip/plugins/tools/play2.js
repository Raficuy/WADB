import axios from 'axios'

export default {
    command: 'play2',
    alias: ['mainkan', 'playflac', 'deezer'],
    category: 'tools',
    description: 'Play dan Download lagu kualitas FLAC dari Deezer',
    help: '<judul lagu atau link deezer>',
    typing: true,
    wait: true,

    async execute(m, { args }) {
        const query = args.join(' ').trim()

        if (!query) {
            return m.reply('Masukkan judul lagu atau link Deezer.\nContoh: .play night changes')
        }

        try {
            let trackId = ''
            let trackUrl = ''
            let trackTitle = ''
            let trackArtist = ''

            if (query.includes('deezer.com')) {
                trackId = query.match(/\/track\/(\d+)/)?.[1]
                trackUrl = query
            } else {
                const { data: searchRes } = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}`)
                if (!searchRes || !searchRes.data || searchRes.data.length === 0) {
                    return m.reply('Lagu tidak ditemukan.')
                }
                const firstTrack = searchRes.data[0]
                trackId = firstTrack.id
                trackUrl = firstTrack.link
                trackTitle = firstTrack.title
                trackArtist = firstTrack.artist.name
            }

            if (!trackId) {
                return m.reply('URL Deezer atau lagu tidak valid.')
            }

            if (!trackTitle) {
                const { data: trackInfo } = await axios.get(`https://api.deezer.com/track/${trackId}`)
                if (!trackInfo || !trackInfo.title) {
                    return m.reply('Gagal mengambil metadata lagu.')
                }
                trackTitle = trackInfo.title
                trackArtist = trackInfo.artist.name
            }

            const { data: taskRes } = await axios.post('https://cap.jhx.my.id/api/createTask', {
                url: 'https://flacdownloader.com/en',
                type: 'turnstile-min',
                sitekey: '0x4AAAAAAD2MQMVORZcldmdE'
            })

            if (!taskRes.success || !taskRes.jobId) {
                return m.reply('Gagal membuat task Turnstile.')
            }

            let cfToken = null
            for (let i = 0; i < 30 && !cfToken; i++) {
                await new Promise(r => setTimeout(r, 2000))
                const { data: pollRes } = await axios.post('https://cap.jhx.my.id/api/getResult', { jobId: taskRes.jobId })
                if (pollRes.status === 'ready' && pollRes.solution && pollRes.solution.token) {
                    cfToken = pollRes.solution.token
                }
            }

            if (!cfToken) {
                return m.reply('Timeout saat bypass Turnstile.')
            }

            const headers = {
                'content-type': 'application/json',
                'origin': 'https://flacdownloader.com',
                'referer': 'https://flacdownloader.com/en/download'
            }

            const { data: prepRes } = await axios.post('https://flacdownloader.com/prepare', { cf: cfToken }, { headers })
            const dlToken = prepRes.t
            
            if (!dlToken) {
                return m.reply('Gagal mendapatkan token download.')
            }

            headers['x-dl-token'] = dlToken

            const payload = {
                url: trackUrl,
                title: trackTitle,
                artist: trackArtist,
                format: 'flac',
                accept_fallback: false
            }

            const { data: assetRes } = await axios.post('https://flacdownloader.com/asset', payload, { headers })
            
            if (!assetRes.u) {
                return m.reply('Gagal mendapatkan direct link FLAC.')
            }

            await axios.post('https://flacdownloader.com/asset-done', {
                ok: true,
                url: payload.url,
                title: payload.title,
                artist: payload.artist,
                quality: 'FLAC',
                filename: assetRes.n,
                size: assetRes.s
            }, { headers })

            let caption = `DEEZER FLAC DOWNLOADER\n\n`
            caption += `Judul: ${assetRes.m?.title || trackTitle}\n`
            caption += `Artis: ${assetRes.m?.artist || trackArtist}\n`
            caption += `File: ${assetRes.n}\n\n`
            caption += `Silakan klik tombol di bawah untuk mengunduh audio.`

            const interactiveMessage = {
                header: { 
                    title: "FLAC Siap",
                    hasMediaAttachment: false
                },
                body: { text: caption },
                footer: { text: "Zapo Tools" },
                nativeFlowMessage: {
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Download FLAC",
                                url: assetRes.u
                            })
                        }
                    ]
                }
            }

            return m.reply({ interactiveMessage })

        } catch (err) {
            return m.reply(`Terjadi kesalahan:\n${err.message}`)
        }
    }
}