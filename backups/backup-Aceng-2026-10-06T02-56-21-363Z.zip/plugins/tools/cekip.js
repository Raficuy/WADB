export default {
  command: 'cekip',
  alias: ['ipinfo', 'lacakip', 'checkip'],
  category: 'tools',
  description: 'Lacak informasi detail dari alamat IP atau Domain.',
  typing: true,
  wait: true, // Kasih efek loading

  async execute(m, { args }) {
    const target = args[0]

    // Kalo user kaga masukin IP/Domain
    if (!target) {
      return m.reply('❌ Masukin alamat IP atau Domain yang mau dilacak!\nContoh: `.cekip 8.8.8.8` atau `.cekip google.com`')
    }

    try {
      // Tarik data dari ip-api
      const res = await fetch(`http://ip-api.com/json/${encodeURIComponent(target)}`)
      const data = await res.json()

      // Kalo IP atau formatnya ngaco
      if (data.status === 'fail') {
        return m.reply(`❌ Gagal melacak: *${data.message}*\nPastikan IP atau domainnya valid!`)
      }

      // Susun hasil lacakan
      let text = `🌐 *INFORMASI IP / DOMAIN* 🌐\n\n`
      text += `🖥️ *IP Target:* ${data.query}\n`
      text += `🏢 *ISP:* ${data.isp}\n`
      text += `🏢 *Organisasi:* ${data.org || '-'}\n`
      text += `📡 *ASN:* ${data.as || '-'}\n\n`
      
      text += `📍 *DETAIL LOKASI*\n`
      text += `Negara: ${data.country} (${data.countryCode})\n`
      text += `Region: ${data.regionName}\n`
      text += `Kota: ${data.city}\n`
      text += `Kode Pos: ${data.zip || '-'}\n`
      text += `Zona Waktu: ${data.timezone}\n\n`
      
      text += `🗺️ *KOORDINAT*\n`
      text += `Lat: ${data.lat}\n`
      text += `Lon: ${data.lon}\n`
      text += `_Cek di Maps: https://www.google.com/maps?q=${data.lat},${data.lon}_`

      return m.reply(text)

    } catch (err) {
      console.error('[CekIP Error]', err)
      return m.reply('❌ Terjadi kesalahan saat menghubungi server pelacak IP.')
    }
  }
}