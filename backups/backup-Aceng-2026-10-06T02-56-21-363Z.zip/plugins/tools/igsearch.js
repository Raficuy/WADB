import axios from 'axios'

export default {
  command: 'igsearch',
  alias: ['igreels', 'searchig', 'carireels'],
  category: 'search',
  description: 'Mencari Instagram Reels spesifik menggunakan Premium AI.',
  help: '<kata kunci>',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const query = args.join(' ').trim()

    if (!query) {
      return m.reply('❌ Kasih kata kuncinya cuy!\n\n*Contoh:* .igsearch Lookism Edits')
    }

    await m.reply('⏳ *AI sedang mengais link Reels mutlak...*')

    try {
      // Prompt super ketat
      const pr = `Search Instagram Reels related to ${query}. All results must be Reels only, not search URLs or anything else. Only Reels from Instagram are mandatory. Use site:instagram.com/p/ and site:instagram.com/reel/`
      
      // Decode URL Base64 bawaan script lu
      const base = Buffer.from("aHR0cHM6Ly9lbWFtLWFwaS10ZXN0LnZlcmNlbC5hcHAvaG9tZS9zZWN0aW9ucy9BaS9hcGkvcHJlbWl1bS9jaGF0", "base64").toString()

      // Tembak API Mutlak
      const response = await axios.post(base, {
        q: pr,
        image: null,
        video: null,
        audio: null,
        document: null,
        text2image: false,
        search: true, 
        thinking: false,
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      })

      const data = response.data
      
      // Logika Parser Barbar Anti [object Object]
      let resultText = data?.result || data?.message || data?.response || data?.data || data
      
      // Kalau dalemannya ternyata masih object, kita stringify paksa
      if (typeof resultText === 'object') {
        resultText = JSON.stringify(resultText, null, 2)
      }

      // Format Output ala Zapo
      const caption = `🔍 *IG REELS SEARCH*\n` +
                      `🔎 *Query:* ${query}\n` +
                      `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n\n` +
                      `${resultText}`

      return m.reply(caption)

    } catch (err) {
      return m.reply(`❌ *Sistem API Error:*\n${err.message || err}`)
    }
  }
}