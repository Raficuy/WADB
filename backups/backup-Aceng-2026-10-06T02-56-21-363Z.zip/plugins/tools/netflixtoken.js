import axios from 'axios'
import { buildQuoteContext } from '../../lib/utils.js' // Sesuaikan path utils-nya kalau beda folder

export default {
    command: 'nftoken',
    alias: ['netflixtoken', 'nf'],
    category: 'tools',
    description: 'Generate link login Netflix Token via Omegatech',
    help: '',
    typing: true,
    wait: true,

    async execute(m) {
        try {
            const { data } = await axios.get(
                "https://api.omegatech.app/api/tools/Nftoken?action=generate",
                {
                    timeout: 60000,
                    headers: {
                        "Accept": "application/json",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                    }
                }
            )

            if (!data?.success || !data?.data?.token) {
                    return m.reply("Terhadi kesalahan.")
            }

            const result = data.data
            const links = result.links || {}
            const allLinks = Array.isArray(links.all) ? links.all : []

            let bodyText = `* *Generated :* ${result.generatedAt || "-"}\n` +
                           `* *Source :* ${data.source || "Omegatech"}\n\n`

            if (allLinks.length > 0) {
                bodyText += `*LINK DEVICE :*\n`
                for (const item of allLinks) {
                    bodyText += `\n▪️ *${item.device || "Device"}*\n${item.url}\n`
                }
            } else {
                bodyText += `* *PC / Browser :*\n${links.pc || "-"}\n\n` +
                            `** Android :*\n${links.android || "-"}\n\n` +
                            `* *TV (6 Digit) :*\n${links.tv6 || "-"}\n\n` +
                            `* *TV (8 Digit) :*\n${links.tv8 || "-"}\n`
            }
            
            bodyText += ``

           
            await m.reply({
                interactiveMessage: {
                    header: { 
                        title: '*NETFLIX GENERATOR*\n', 
                        hasMediaAttachment: false 
                    },
                    body: { text: bodyText },
                    footer: { text: 'Author: Gatau siapa tapi itu lah' },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'cta_copy',
                                buttonParamsJson: JSON.stringify({
                                    display_text: ' Copy Token Netflix',
                                    copy_code: result.token
                                })
                            }
                        ],
                        messageVersion: 1
                    },
                    contextInfo: buildQuoteContext(m)
                }
            })

        } catch (err) {
            console.error("[NFTOKEN] Error:", err?.response?.data || err.message)
            return m.reply(
                "❌ *NFTOKEN GAGAL*\n\n" +
                (err?.response?.data?.message || err.message || "Gagal menghubungi API.")
            )
        }
    }
}