import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import { writeFile, mkdir } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'

const ASSETS_DIR = join(process.cwd(), 'assets', 'quote_premium')
const FONTS_DIR = join(ASSETS_DIR, 'fonts')
const BACKGROUND_URL = 'https://ar-hosting.pages.dev/1783829450995.jpg'

const FONT_FILES = [
    { url: 'https://fonts.gstatic.com/s/poppins/v20/pxiByp8kv8JHgFVrLCz7Z1xlFd2JQEk.woff2', file: 'Poppins-ExtraBold.ttf', family: 'QuoteFont' },
    { url: 'https://fonts.gstatic.com/s/poppins/v20/pxiByp8kv8JHgFVrLEj6Z1xlFd2JQEk.woff2', file: 'Poppins-SemiBold.ttf', family: 'QuoteFontSemi' },
    { url: 'https://fonts.gstatic.com/s/poppins/v20/pxiByp8kv8JHgFVrLGT9Z1xlFd2JQEk.woff2', file: 'Poppins-Medium.ttf', family: 'AuthorFont' }
]

const QUOTE_FONT = 'QuoteFont, "Segoe UI", Arial, sans-serif'
const AUTHOR_FONT = 'AuthorFont, "Segoe UI", Arial, sans-serif'

const OUTPUT_WIDTH = 1280
const OUTPUT_HEIGHT = 720
const SCALE = 2 
const CANVAS_WIDTH = OUTPUT_WIDTH * SCALE
const CANVAS_HEIGHT = OUTPUT_HEIGHT * SCALE

async function prepareAssets() {
    if (!existsSync(FONTS_DIR)) {
        await mkdir(FONTS_DIR, { recursive: true })
    }
    for (const f of FONT_FILES) {
        const fPath = join(FONTS_DIR, f.file)
        if (!existsSync(fPath)) {
            const res = await fetch(f.url, { headers: { 'User-Agent': 'Mozilla/5.0' } })
            if (!res.ok) throw new Error('Gagal mengunduh font')
            const buffer = Buffer.from(await res.arrayBuffer())
            await writeFile(fPath, buffer)
        }
        GlobalFonts.registerFromPath(fPath, f.family)
    }
}

async function getBuffer(url) {
    const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } })
    if (!res.ok) throw new Error('Gagal mengambil background')
    return Buffer.from(await res.arrayBuffer())
}

function drawRoundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath()
    ctx.moveTo(x + r, y)
    ctx.lineTo(x + w - r, y)
    ctx.quadraticCurveTo(x + w, y, x + w, y + r)
    ctx.lineTo(x + w, y + h - r)
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
    ctx.lineTo(x + r, y + h)
    ctx.quadraticCurveTo(x, y + h, x, y + h - r)
    ctx.lineTo(x, y + r)
    ctx.quadraticCurveTo(x, y, x + r, y)
    ctx.closePath()
}

function fitFontSize(ctx, text, maxWidth, maxHeight, initialSize, minSize) {
    let fontSize = initialSize
    let lines = []

    while (fontSize >= minSize) {
        ctx.font = `800 ${fontSize}px ${QUOTE_FONT}`
        lines = []
        let currentLine = ''
        const words = text.split(' ')

        for (let word of words) {
            const testLine = currentLine + word + ' '
            const metrics = ctx.measureText(testLine)
            if (metrics.width > maxWidth && currentLine.length > 0) {
                lines.push(currentLine.trim())
                currentLine = word + ' '
            } else {
                currentLine = testLine
            }
        }
        if (currentLine.trim().length > 0) {
            lines.push(currentLine.trim())
        }

        const totalHeight = lines.length * (fontSize * 1.4)
        if (totalHeight <= maxHeight) break
        fontSize -= 2
    }

    return { fontSize, lines }
}

function drawFilmGrain(ctx, width, height, opacity = 0.035) {
    const grainCanvas = createCanvas(256, 256)
    const gctx = grainCanvas.getContext('2d')
    const imageData = gctx.createImageData(256, 256)
    const data = imageData.data
    for (let i = 0; i < data.length; i += 4) {
        const gray = Math.floor(Math.random() * 255)
        data[i] = gray
        data[i + 1] = gray
        data[i + 2] = gray
        data[i + 3] = 255
    }
    gctx.putImageData(imageData, 0, 0)

    ctx.save()
    ctx.globalAlpha = opacity
    const pattern = ctx.createPattern(grainCanvas, 'repeat')
    ctx.fillStyle = pattern
    ctx.fillRect(0, 0, width, height)
    ctx.restore()
}

function drawVignette(ctx, width, height) {
    const gradient = ctx.createRadialGradient(width / 2, height / 2, height * 0.3, width / 2, height / 2, height * 0.95)
    gradient.addColorStop(0, 'rgba(0,0,0,0)')
    gradient.addColorStop(0.5, 'rgba(0,0,0,0.05)')
    gradient.addColorStop(1, 'rgba(0,0,0,0.6)')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)
}

function drawGradient(ctx, width, height) {
    const gradient = ctx.createLinearGradient(0, 0, width, height)
    gradient.addColorStop(0, 'rgba(0,0,0,0.2)')
    gradient.addColorStop(0.5, 'rgba(0,0,0,0.05)')
    gradient.addColorStop(1, 'rgba(0,0,0,0.4)')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)
}

function drawGlassPanel(ctx, x, y, w, h, r) {
    ctx.save()
    drawRoundedRect(ctx, x, y, w, h, r)
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)'
    ctx.fill()
    ctx.shadowColor = 'rgba(255,255,255,0.06)'
    ctx.shadowBlur = 30
    ctx.strokeStyle = 'rgba(255,255,255,0.10)'
    ctx.lineWidth = 1.5
    ctx.stroke()
    ctx.shadowBlur = 0
    ctx.restore()

    ctx.save()
    drawRoundedRect(ctx, x + 6, y + 6, w - 12, h - 12, r - 4)
    ctx.fillStyle = 'rgba(255,255,255,0.04)'
    ctx.fill()
    ctx.restore()
}

function drawDivider(ctx, x, y, width) {
    const gradient = ctx.createLinearGradient(x, y, x + width, y)
    gradient.addColorStop(0, 'rgba(255,255,255,0)')
    gradient.addColorStop(0.5, 'rgba(255,255,255,0.5)')
    gradient.addColorStop(1, 'rgba(255,255,255,0)')
    ctx.fillStyle = gradient
    ctx.fillRect(x, y, width, 1.5)
}

function drawWatermark(ctx, text, x, y, fontSize) {
    ctx.save()
    ctx.globalAlpha = 0.12
    ctx.fillStyle = '#ffffff'
    ctx.font = `${fontSize}px ${AUTHOR_FONT}`
    ctx.textAlign = 'right'
    ctx.textBaseline = 'bottom'
    ctx.fillText(text, x, y)
    ctx.restore()
}

function drawDate(ctx, x, y, fontSize) {
    const now = new Date()
    const dateStr = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
    ctx.save()
    ctx.globalAlpha = 0.25
    ctx.fillStyle = '#ffffff'
    ctx.font = `${fontSize}px ${AUTHOR_FONT}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'bottom'
    ctx.fillText(dateStr, x, y)
    ctx.restore()
}

function drawAuthor(ctx, text, x, y, fontSize) {
    ctx.save()
    ctx.shadowColor = 'rgba(0,0,0,0.6)'
    ctx.shadowBlur = 15
    ctx.fillStyle = '#ffffff'
    ctx.font = `600 ${fontSize}px ${AUTHOR_FONT}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'bottom'
    ctx.fillText(`— ${text}`, x, y)
    ctx.restore()
}

function drawQuoteIcon(ctx, x, y, size) {
    ctx.save()
    ctx.globalAlpha = 0.06
    ctx.fillStyle = '#ffffff'
    ctx.font = `${size}px Georgia, serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText('"', x, y)
    ctx.restore()
}

export default {
  command: 'quote',
  alias: ['q', 'quotemaker'],
  category: 'maker',
  description: 'Buat quote premium dengan anime background dan glass panel',
  help: '<teks> | <author>',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const text = args.join(' ').trim() || m.quoted?.text || ''

    if (!text || !text.includes('|')) {
        return m.reply(`Format salah.\nContoh:\n${m.prefix}${m.command} life is like a dih, sometimes is up, and sometimes is down | Paduka Rafi`)
    }

    try {
        await prepareAssets()

        const [quoteText, authorText] = text.split('|').map(s => s.trim())
        
        const bgBuffer = await getBuffer(BACKGROUND_URL)
        const bgImage = await loadImage(bgBuffer)
        
        const canvas = createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT)
        const canvasCtx = canvas.getContext('2d')

        canvasCtx.imageSmoothingEnabled = true
        canvasCtx.imageSmoothingQuality = 'high'

        canvasCtx.drawImage(bgImage, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

        drawGradient(canvasCtx, CANVAS_WIDTH, CANVAS_HEIGHT)
        drawVignette(canvasCtx, CANVAS_WIDTH, CANVAS_HEIGHT)

        const animeX = 120 * SCALE
        const animeY = 0
        const animeW = 480 * SCALE
        const animeH = CANVAS_HEIGHT
        canvasCtx.save()
        drawRoundedRect(canvasCtx, animeX, animeY + 20 * SCALE, animeW - 40 * SCALE, animeH - 40 * SCALE, 24 * SCALE)
        canvasCtx.clip()
        
        const imgAspect = bgImage.width / bgImage.height
        const targetAspect = animeW / animeH
        let sx, sy, sw, sh
        
        if (imgAspect > targetAspect) {
            sw = bgImage.width
            sh = bgImage.width / targetAspect
            sx = 0
            sy = (bgImage.height - sh) / 2
        } else {
            sh = bgImage.height
            sw = bgImage.height * targetAspect
            sx = (bgImage.width - sw) / 2
            sy = 0
        }
        
        canvasCtx.drawImage(bgImage, sx, sy, sw, sh, animeX, 20 * SCALE, animeW - 40 * SCALE, animeH - 40 * SCALE)
        canvasCtx.restore()

        const panelX = 660 * SCALE
        const panelY = 80 * SCALE
        const panelW = 520 * SCALE
        const panelH = 560 * SCALE
        drawGlassPanel(canvasCtx, panelX, panelY, panelW, panelH, 32 * SCALE)

        drawQuoteIcon(canvasCtx, panelX + 40 * SCALE, panelY + 80 * SCALE, 80 * SCALE)

        const textMaxWidth = panelW - 100 * SCALE
        const textMaxHeight = panelH - 180 * SCALE
        const fit = fitFontSize(canvasCtx, quoteText || 'Diam bukan berarti kalah', textMaxWidth, textMaxHeight, 52 * SCALE, 20 * SCALE)
        const lineHeight = fit.fontSize * 1.4

        const quoteX = panelX + panelW / 2
        const quoteY = panelY + 90 * SCALE

        canvasCtx.save()
        canvasCtx.shadowColor = 'rgba(0,0,0,0.9)'
        canvasCtx.shadowBlur = 30 * SCALE
        canvasCtx.shadowOffsetX = 0
        canvasCtx.shadowOffsetY = 2 * SCALE
        canvasCtx.fillStyle = '#ffffff'
        canvasCtx.font = `800 ${fit.fontSize}px ${QUOTE_FONT}`
        canvasCtx.textAlign = 'center'
        canvasCtx.textBaseline = 'top'

        let currentY = quoteY
        for (let line of fit.lines) {
            canvasCtx.fillText(line, quoteX, currentY)
            currentY += lineHeight
        }
        canvasCtx.restore()

        const dividerY = panelY + panelH - 70 * SCALE
        drawDivider(canvasCtx, panelX + 60 * SCALE, dividerY, panelW - 120 * SCALE)

        drawAuthor(canvasCtx, authorText || 'Paduka Rafi', panelX + panelW / 2, panelY + panelH - 30 * SCALE, 22 * SCALE)
        drawDate(canvasCtx, panelX + 30 * SCALE, panelY + panelH - 10 * SCALE, 14 * SCALE)
        drawWatermark(canvasCtx, '@PadukaRafi', CANVAS_WIDTH - 30 * SCALE, CANVAS_HEIGHT - 20 * SCALE, 14 * SCALE)

        drawFilmGrain(canvasCtx, CANVAS_WIDTH, CANVAS_HEIGHT, 0.03)

        canvasCtx.save()
        canvasCtx.globalAlpha = 0.03
        const highlight = canvasCtx.createRadialGradient(CANVAS_WIDTH / 2, 0, 0, CANVAS_WIDTH / 2, 0, CANVAS_HEIGHT)
        highlight.addColorStop(0, 'rgba(255,255,255,0)')
        highlight.addColorStop(0.5, 'rgba(255,255,255,0)')
        highlight.addColorStop(1, 'rgba(255,255,255,0.1)')
        canvasCtx.fillStyle = highlight
        canvasCtx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)
        canvasCtx.restore()

        const finalCanvas = createCanvas(OUTPUT_WIDTH, OUTPUT_HEIGHT)
        const finalCtx = finalCanvas.getContext('2d')
        finalCtx.imageSmoothingEnabled = true
        finalCtx.imageSmoothingQuality = 'high'
        finalCtx.drawImage(canvas, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT, 0, 0, OUTPUT_WIDTH, OUTPUT_HEIGHT)

        const resultBuffer = await finalCanvas.encode('png')

        await sock.message.send(m.chat, {
            type: 'image',
            media: resultBuffer,
            mimetype: 'image/png',
            caption: `quote\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n"${quoteText}"\n\n— ${authorText}`
        }, { quote: m.raw })

    } catch (error) {
        console.error(error)
        return m.reply(`Gagal membuat quote premium: ${error.message}`)
    }
  }
}