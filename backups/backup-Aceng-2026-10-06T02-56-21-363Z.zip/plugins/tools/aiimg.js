import axios from 'axios'

export default {
  command: 'image',
  alias: ['img', 'aiimg', 'generate', 'create'],
  category: 'tools',
  description: 'Menciptakan gambar cinematic dari teks.',
  help: '<text>',
  typing: true,
  wait: true,

  async execute(m, q, text ) {
    const input = m.text || q.text
    
    if (!input) {
      return m.reply('❌ Kasih detail gambar yang mau dibuat.\n\n*Contoh:* .img cewek cantik, cinematic lighting, kostum adat jawa, detail batik, 8k resolution, unreal engine 5')
    }


    try {

      const targetUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(input)}?width=1024&height=1024&nologo=true&model=flux`

      const response = await axios.get(targetUrl, {
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      })

      const imageBuffer = Buffer.from(response.data, 'binary')

      if (!imageBuffer || imageBuffer.length === 0) {
        return m.reply('❌ Server AI ngasih buffer kosong. Coba ganti kata-katanya.')
      }

      return m.reply({
        type: 'image',
        media: imageBuffer,
        mimetype: 'image/jpeg',
        caption: `*Render Selesai*\n\n*Prompt:* ${input}`
      })

    } catch (err) {
      return m.reply(`❌ *Gagal merender gambar:*\nServer AI mungkin lagi penuh atau koneksi panel lu putus.\n\nLog: ${err.message || err}`)
    }
  }
}