// plugins/ai/hd.js

const config = ['2', '4'] 

async function gettoken() {
  const html = await fetch('https://www.iloveimg.com/upscale-image').then(r => r.text())
  const token = html.match(/"token":"(eyJ[^"]+)"/)?.[1]
  const task = html.match(/ilovepdfConfig\.taskId\s*=\s*'([^']+)'/)?.[1]
  return { token, task }
}

async function upimage(buffer, token, task) {
  const form = new FormData()
  form.append('name', 'image.jpg')
  form.append('chunk', '0')
  form.append('chunks', '1')
  form.append('task', task)
  form.append('preview', '1')
  form.append('v', 'web.0')
  form.append('file', new Blob([buffer], { type: 'image/jpeg' }), 'image.jpg')

  const r = await fetch('https://api29g.iloveimg.com/v1/upload', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Origin: 'https://www.iloveimg.com',
      Referer: 'https://www.iloveimg.com/'
    },
    body: form
  })

  const json = await r.json()
  return json.server_filename
}

async function doUpscale(serverfilename, token, task, scale) {
  if (!config.includes(String(scale))) throw new Error('Scale tidak valid')

  const form = new FormData()
  form.append('task', task)
  form.append('server_filename', serverfilename)
  form.append('scale', scale)

  const r = await fetch('https://api29g.iloveimg.com/v1/upscale', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Origin: 'https://www.iloveimg.com',
      Referer: 'https://www.iloveimg.com/'
    },
    body: form
  })

  return Buffer.from(await r.arrayBuffer())
}

async function upscale(buffer, scale = '4') {
  const { token, task } = await gettoken()
  if (!token || !task) throw new Error('Gagal mendapatkan token API')
  
  const serverfilename = await upimage(buffer, token, task)
  return await doUpscale(serverfilename, token, task, scale)
}

export default {
  command: 'hd',
  alias: ['remini', 'upscale', 'hdr'],
  category: 'ai',
  description: 'Meningkatkan resolusi (upscale) gambar menjadi HD.',
  help: '(kirim/reply gambar)',
  typing: true,
  wait: true,

  async execute(m, { sock }) {
    try {
      let bytes;

      if (m.quoted?.isMedia || m.quoted?.mediaType === 'image') {
        bytes = await m.quoted.download()
      } else if (m.isMedia || m.mediaType === 'image') {
        bytes = await sock.message.downloadBytes(m.raw.message)
      } else {
        return m.reply('❌ Reply atau kirim gambar dengan caption .hd')
      }

      if (!bytes) return m.reply('❌ Gagal mengunduh gambar. Pastikan medianya belum kadaluarsa.')

      const buffer = Buffer.from(bytes)

      const hdBuffer = await upscale(buffer, '4')

      await m.reply({
        type: 'image',
        media: hdBuffer,
        mimetype: 'image/jpeg',
        caption: 'Berhasil dihadekan'
      })
    } catch (err) {
      return m.reply(`❌ Gagal memproses gambar:\n${err.message || err}`)
    }
  }
}