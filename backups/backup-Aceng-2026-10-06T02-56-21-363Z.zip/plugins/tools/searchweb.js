import axios from 'axios'

export default {
    command: 'search',
    alias: ['websearch', 'cari', 'google'],
    category: 'tools',
    description: 'Mencari informasi atau berita terbaru dari internet mutlak.',
    help: '<kata kunci>',
    typing: true,
    wait: true,

    async execute(m, { args }) {
        const query = args.join(' ').trim()
        
        if (!query) {
            return m.reply('❌ Kasih kata kunci pencariannya cuy!\n\n*Contoh:* .search latest AI news')
        }


        try {
            const response = await axios.post('https://api.apinex.bond/v1/tools/web/search', {
                query: query,
                count: 5,
                freshness: "week"
            }, {
                headers: {
                    'Authorization': 'Bearer sk-apxbd18d32d536bc91c07ca10ddd72a770ef1cc077dcd89fe0',
                    'Content-Type': 'application/json'
                },
                timeout: 15000
            })

            const dataResults = response.data?.results
            
            if (!dataResults || (!dataResults.web?.length && !dataResults.news?.length)) {
                return m.reply('❌ Kaga nemu hasil apa-apa buat pencarian itu.')
            }

            const combinedResults = [...(dataResults.web || []), ...(dataResults.news || [])].slice(0, 5)

            let text = `*HASIL PENCARIAN*\n`
            text += `*Kueri:* ${query}\n`
            text += `\n\n`

            combinedResults.forEach((res, index) => {
                const title = res.title || 'Tanpa Judul'
                const snippet = res.snippet || res.description || res.summary || '-'
                const url = res.url || res.link || '#'

                text += `*${index + 1}. ${title}*\n`
                text += `📝 ${snippet}\n`
                text += `🔗 ${url}\n\n`
            })

            return m.reply(text.trim())

        } catch (err) {
            let errorMsg = err.response?.data ? JSON.stringify(err.response.data) : err.message
            return m.reply(`❌ *Search API Error:*\n${errorMsg}`)
        }
    }
}