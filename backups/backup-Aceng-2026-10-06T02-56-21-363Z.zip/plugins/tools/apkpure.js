import { gotScraping } from 'got-scraping'
import * as cheerio from 'cheerio'

const BASE_URL = 'https://apkpure.com'

function cleanText(text) {
    if (!text) return ''
    return text.replace(/\s+/g, ' ').trim()
}

function formatUrl(url) {
    if (!url) return ''
    if (url.startsWith('http')) return url
    return url.startsWith('/') ? `${BASE_URL}${url}` : `${BASE_URL}/${url}`
}

export default {
    command: 'apk',
    alias: ['apkpure', 'getapk', 'downloadapk', 'playstore'],
    category: 'tools',
    description: 'Scraper & Downloader APK dari APKPure (Bypass Cloudflare mutlak).',
    help: '<nama aplikasi/game>',
    typing: true,
    wait: true,

    async execute(m, { args, sock }) {
        const query = args.join(' ').trim()
        
        if (!query) {
            return m.reply('❌ Kasih nama aplikasi atau gamenya cuy!\n\n*Contoh:* .apk free fire')
        }


        try {

            const searchUrl = `${BASE_URL}/id/search?q=${encodeURIComponent(query)}`
            const searchRes = await gotScraping({ url: searchUrl, timeout: { request: 15000 } })
            const $search = cheerio.load(searchRes.body)

            let targetUrl = ''
            
            const firstBrand = $search('.first.brand')
            if (firstBrand.length > 0) {
                targetUrl = formatUrl(firstBrand.find('.first-info a, a').attr('href'))
            } else {

                const firstItem = $search('ul.search-res > li').first()
                if (firstItem.length > 0) {
                    targetUrl = formatUrl(firstItem.find('a').attr('href'))
                }
            }

            if (!targetUrl) {
                return m.reply(`❌ Kaga nemu aplikasi *${query}* di APKPure. Coba kata kunci lain.`)
            }

            const downloadPageUrl = targetUrl.endsWith('/') ? `${targetUrl}download` : `${targetUrl}/download`
            const dlRes = await gotScraping({ url: downloadPageUrl, timeout: { request: 15000 } })
            const $dl = cheerio.load(dlRes.body)

            const mainDownloadBtn = $dl('a.download-start-btn, a[href*="d.apkpure.com/b/"]').first()
            let directUrl = mainDownloadBtn.attr('href') || ''
            const btnText = cleanText(mainDownloadBtn.text()) || 'Unduh APK'
            
            const title = cleanText($dl('.title-box h1').text()) || query.toUpperCase()
            const developer = cleanText($dl('.details-author p').text()) || 'Developer Unknown'
            const iconUrl = $dl('.icon-box img').attr('src') || ''

            let fileSize = 'Unknown Size'
            const sizeMatch = btnText.match(/\(([^)]+)\)/)
            if (sizeMatch && sizeMatch[1]) fileSize = sizeMatch[1]

            if (!directUrl) {
                const pkgMatch = targetUrl.match(/\/([^\/]+)$/)
                const pkg = pkgMatch ? pkgMatch[1] : 'unknown'
                const fileType = btnText.toUpperCase().includes('XAPK') ? 'XAPK' : 'APK'
                directUrl = `${BASE_URL}/d/${fileType}/${pkg}?version=latest`
            }

            let caption = `*APKPURE*\n`
            caption += `* *Nama:* ${title}\n`
            caption += `* *Dev:* ${developer}\n`
            caption += `* *Ukuran:* ${fileSize}\n`
            caption += `_Pencet tombol di bawah buat langsung download filenya!_`

            const payload = {
                interactiveMessage: {
                    header: { 
                        title: "✅ APK Ditemukan",
                        hasMediaAttachment: iconUrl ? true : false,
                        ...(iconUrl && { imageMessage: await sock.generateWAMessageContent({ image: { url: iconUrl } }, { upload: sock.waUploadToServer }) })
                    },
                    body: { text: caption },
                    footer: { text: "Apk Purel" },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "⬇️ Download Sekarang",
                                    url: directUrl
                                })
                            }
                        ]
                    }
                }
            }

            const extraOpts = {
                additionalNodes: [
                    {
                        tag: "biz",
                        attrs: {},
                        content: [
                            {
                                tag: "interactive",
                                attrs: { type: "native_flow", v: "1" },
                                content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                            }
                        ]
                    }
                ]
            }

            return await sock.message.send(m.chat, payload, extraOpts)

        } catch (err) {
            return m.reply(`❌ *Scraper Error:*\n${err.message || err}`)
        }
    }
}