export default {
  command: 'lirik',
  alias: ['lyrics', 'lyric'],
  category: 'tools',
  description: 'Mencari lirik lagu dari judul atau link Spotify',
  help: '<judul lagu / link spotify>',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const query = args.join(' ').trim() || m.quoted?.text || ''
    
    if (!query) {
      return m.reply(`Masukkan judul lagu atau link Spotify.\nContoh: ${m.prefix}${m.command} bohemian rhapsody`)
    }

    let trackName = query
    let artistName = ''

    // Ekstraksi data jika input berupa link Spotify
    if (query.includes('spotify.com/track/')) {
      const match = query.match(/track\/([a-zA-Z0-9]+)/)
      if (match) {
        try {
          const oembedRes = await fetch(`https://open.spotify.com/oembed?url=https://open.spotify.com/track/${match[1]}`, { signal: AbortSignal.timeout(5000) })
          if (oembedRes.ok) {
            const oembedData = await oembedRes.json()
            trackName = (oembedData.title || trackName).replace(/\(feat\..*?\)/i, '').trim()
          }
          
          const embedRes = await fetch(`https://open.spotify.com/embed/track/${match[1]}`, { signal: AbortSignal.timeout(5000) })
          if (embedRes.ok) {
            const embedText = await embedRes.text()
            const matchArtist = embedText.match(/"artists":\[\{"name":"([^"]+)"/)
            if (matchArtist) {
              artistName = matchArtist[1]
            }
          }
        } catch (err) {}
      }
    }

    let result = null

    // 1. Coba exact search API LRCLIB
    try {
      const params = new URLSearchParams()
      if (trackName) params.append('track_name', trackName)
      if (artistName) params.append('artist_name', artistName)
      
      const res = await fetch(`https://lrclib.net/api/get?${params.toString()}`, { signal: AbortSignal.timeout(10000) })
      if (res.ok) {
        const data = await res.json()
        if (data.plainLyrics || data.syncedLyrics) {
          result = data
        }
      }
    } catch (err) {}

    // 2. Fallback: Fuzzy search query LRCLIB
    if (!result) {
      try {
        const searchParams = new URLSearchParams({ q: `${trackName} ${artistName}`.trim() })
        const searchRes = await fetch(`https://lrclib.net/api/search?${searchParams.toString()}`, { signal: AbortSignal.timeout(10000) })
        if (searchRes.ok) {
          const data = await searchRes.json()
          if (Array.isArray(data) && data.length > 0) {
            result = data[0]
          }
        }
      } catch (err) {}
    }

    if (!result || (!result.plainLyrics && !result.syncedLyrics)) {
      return m.reply('Lirik lagu tidak ditemukan.')
    }

    let teks = 'LIRIK LAGU\n\n'
    teks += `Judul: ${result.trackName || trackName}\n`
    teks += `Artis: ${result.artistName || artistName}\n`
    if (result.albumName) teks += `Album: ${result.albumName}\n`
    if (result.duration) {
      const mnt = Math.floor(result.duration / 60)
      const dtk = String(Math.floor(result.duration % 60)).padStart(2, '0')
      teks += `Durasi: ${mnt}:${dtk}\n`
    }

    teks += `\n${result.plainLyrics || result.syncedLyrics}`

    if (teks.length > 4000) {
      return m.reply(teks.substring(0, 4000) + '\n\n[Lirik terlalu panjang, sebagian dipotong]')
    }

    return m.reply(teks)
  }
}