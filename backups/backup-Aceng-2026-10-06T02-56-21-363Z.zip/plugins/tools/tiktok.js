const TIKTOK_REGEX = /(https?:\/\/(?:www\.|vt\.|vm\.)?tiktok\.com\/\S+)/i

export default {
  command: 'tiktok',
  alias: ['tt', 'ttdl', 'tiktokdl', 'ttslide'],
  category: 'downloader',
  description: 'Download video/foto slide TikTok beserta audionya.',
  help: '<link tiktok> atau (reply pesan berisi link)',
  typing: true,
  wait: true, 

  async execute(m, { sock, args }) {
    const source = args.join(' ') || m.quoted?.text || ''
    const match = source.match(TIKTOK_REGEX)

    if (!match) {
      return m.reply('❌ Masukkan atau reply URL TikTok yang valid!')
    }

    const url = match[1]

    try {
      const res = await fetch(`https://api.nexray.eu.cc/downloader/tiktok?url=${encodeURIComponent(url)}`)
      const json = await res.json()

      if (!json.status || !json.result) {
        return m.reply('❌ Gagal mengambil data, URL tidak valid atau video diprivasi.')
      }

      const { title, region, duration, data, images, author, stats, music_info } = json.result

      const caption = `*\`${title || 'TikTok'}\`*\n\n` +
        ` Oleh: ${author.nickname} (@${author.fullname})\n` +
        ` Durasi: ${duration} \n Region: ${region}\n` +
        ` Views: ${stats.views} \n Likes: ${stats.likes} •  Comment: ${stats.comment} \n Share: ${stats.share}`

      if (Array.isArray(images) && images.length > 0) {
        
        await sock.sendAlbum(m.chat, images, { 
          caption: caption,
          quote: m.raw 
        })
      } 
      else if (data) {
        const vidRes = await fetch(data)
        if (!vidRes.ok) throw new Error('Gagal fetch video buffer.')
        const vidBuf = Buffer.from(await vidRes.arrayBuffer())

        await sock.message.send(m.chat, { 
          type: 'video', 
          media: vidBuf, 
          mimetype: 'video/mp4', 
          caption 
        }, { quote: m.raw })
      } else {
         return m.reply('❌ Gagal mendapatkan media video atau foto dari link tersebut.')
      }

      if (music_info?.url) {
        const audRes = await fetch(music_info.url)
        if (audRes.ok) {
          const audBuf = Buffer.from(await audRes.arrayBuffer())
          
          await sock.message.send(m.chat, { 
            type: 'audio', 
            media: audBuf, 
            mimetype: 'audio/mpeg', 
            ptt: false 
          }, { quote: m.raw })
        }
      }

    } catch (err) {
      return m.reply(`❌ Terjadi kesalahan:\n${err.message || err}`)
    }
  }
}