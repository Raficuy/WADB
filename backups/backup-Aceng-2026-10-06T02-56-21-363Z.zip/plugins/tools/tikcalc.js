// plugins/info/tikcalc.js


import axios from "axios";

class TikTokCalculatorAPI {
  constructor() {
    this.baseUrl = "https://tikcalculator.com";
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 15000,
    });
  }

  getHeaders(customHeaders = {}) {
    return {
      accept: "*/*",
      "accept-language": "en-US,en;q=0.9,id;q=0.8",
      priority: "u=1, i",
      referer: `${this.baseUrl}/`,
      "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      ...customHeaders,
    };
  }

  async getSessionCookie() {
    try {
      const response = await this.client.get("/", {
        headers: this.getHeaders(),
      });

      const setCookie = response.headers["set-cookie"];
      let cookie = "";

      if (Array.isArray(setCookie)) {
        const sessionCookie = setCookie.find((c) => c.includes("session_data"));
        if (sessionCookie) {
          cookie = sessionCookie.split(";")[0];
        }
      }

      return cookie;
    } catch (err) {
      throw new Error(`Gagal mengambil session cookie: ${err.message}`);
    }
  }

  async calculate({ username, user, ...rest }) {
    const targetUser = username || user;

    if (!targetUser) {
      throw { status: 400, message: "Parameter 'username' wajib diisi." };
    }

    const cleanUsername = String(targetUser).trim().replace(/^@/, "");

    try {
      const cookie = await this.getSessionCookie();

      const { data } = await this.client.get("/result", {
        params: { username: cleanUsername, ...rest },
        headers: this.getHeaders({ ...(cookie ? { cookie } : {}) }),
      });

      if (!data) throw new Error("Respons data dari TikCalculator kosong.");

      return data;
    } catch (err) {
      const errMessage = err.response?.data?.message || err.response?.data?.error || err.message;
      throw {
        status: err.status || err.response?.status || 500,
        message: errMessage || "Gagal mengambil data pendapatan akun dari TikCalculator.",
      };
    }
  }
}

// Inisialisasi Instance
const api = new TikTokCalculatorAPI();

export default {
  command: 'ttstalk',
  alias: ['tiktokstalk'],
  category: 'info',
  description: 'stalking tt.',
  help: '<username>',
  typing: true,

  async execute(m, { args }) {
    const username = args[0]
    
    if (!username) {
      return m.reply('❌ Masukkan username TikTok yang mau dicek!\n*Contoh:* `.tikcalc khaby.lame`')
    }


    try {
      const res = await api.calculate({ username })

      const formatData = (obj, indent = '') => {
        let str = '';
        for (const [key, val] of Object.entries(obj)) {

          if (val === null || val === '') continue; 

          const cleanKey = key.replace(/_/g, ' ').toUpperCase()

          if (typeof val === 'object') {
            if (Array.isArray(val)) {
              str += `${indent}• *${cleanKey}*: ${val.join(', ')}\n`;
            } else {
              str += `\n${indent}*━ ${cleanKey} ━*\n${formatData(val, indent + '  ')}`;
            }
          } else {
            str += `${indent}• *${cleanKey}*: ${val}\n`;
          }
        }
        return str;
      }

      let text = ` *TIKTOK STALK | @${username.replace(/^@/, '')}*\n\n`
      text += formatData(res)
      text += ``

      return m.reply(text.trim())

    } catch (err) {
      return m.reply(`❌ Gagal mengambil data:\n${err.message || err}`)
    }
  }
}