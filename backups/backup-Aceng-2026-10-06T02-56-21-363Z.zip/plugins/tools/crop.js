import fs from 'fs'
import path from 'path'
import { exec } from 'child_process'

export default {
  command: 'burik',
  alias: ['crop', 'lowres', '8bit'],
  category: 'tools',
  description: 'Bikin foto atau video jadi burik (resolusi & kualitas diturunin abis).',
  typing: true,
  wait: true,
  
  async execute(m, { sock }) {
   
    const msg = m.quoted ? m.quoted : m
    const mime = msg.type || msg.mtype || ''

    if (!mime.includes('image') && !mime.includes('video')) {
      return m.reply('❌ Reply foto atau video yang mau dibikin burik bos!')
    }

    try {

      const buffer = await msg.download()
      
      const isVideo = mime.includes('video')
      const ext = isVideo ? '.mp4' : '.jpg'
      
      const tmpIn = path.join(process.cwd(), `tmpIn_${Date.now()}${ext}`)
      const tmpOut = path.join(process.cwd(), `tmpOut_${Date.now()}${ext}`)

      fs.writeFileSync(tmpIn, buffer)

      let cmd = ''
      if (isVideo) {
        
        cmd = `ffmpeg -i ${tmpIn} -vf "scale=144:-2" -b:v 20k -r 10 -c:a aac -b:a 16k ${tmpOut}`
      } else {
               cmd = `ffmpeg -i ${tmpIn} -vf "scale=144:-2" -q:v 31 ${tmpOut}`
      }

      exec(cmd, async (err) => {
      
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn)

        if (err) {
          console.error('[FFmpeg Error]', err)
          return m.reply('❌ Gagal memproses! Pastikan FFmpeg udah ke-install di server bot lu.')
        }

        const finalBuffer = fs.readFileSync(tmpOut)

        
        if (isVideo) {
          await sock.message.send(m.chat, { 
            type: 'video', 
            media: finalBuffer, 
            mimetype: 'video/mp4', 
            caption: 'Nih video burik lu 🗿' 
          }, { quote: m.raw })
        } else {
          await sock.message.send(m.chat, { 
            type: 'image', 
            media: finalBuffer, 
            mimetype: 'image/jpeg', 
            caption: 'Nih foto burik lu 🗿' 
          }, { quote: m.raw })
        }

        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut)
      })

    } catch (error) {
      console.error('[Burik Error]', error)
      return m.reply(`❌ Terjadi kesalahan:\n${error.message || error}`)
    }
  }
}