import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'

export default {
  command: 'jarvis',
  alias: ['memejarvis'],
  category: 'canvas',
  description: 'Bikin meme Jarvis dengan teks otomatis pas.',
  help: '<teks>',
  typing: true,
  wait: true,

  async execute(m, q) {
    const tek = m.text || q.text
    if (!tek) {
      return m.reply(' Kasih teks buat Jarvis.\n\n*Contoh:* .jarvis Tolong diapakan dulu apa itu biar ga apa kali')
    }


    try {
      const BG_URL = "https://cdn.jsdelivr.net/gh/Ditzzx-vibecoder/Assets@main/Image/jarvismeme.png"
      const FONT_URL = "https://cdn.jsdelivr.net/gh/adrienverge/copr-some-nice-fonts@master/ArialBd.ttf"
      const CANVAS_SIZE = { width: 735, height: 678 }

      const ASSETS_DIR = join(process.cwd(), 'assets', 'jarvismeme')
      await mkdir(ASSETS_DIR, { recursive: true })

      async function download(url) {
        const res = await fetch(url, {
          headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
        })
        if (!res.ok) throw new Error(`Fetch failed ${url}`)
        return Buffer.from(await res.arrayBuffer())
      }

      const bgLocal = join(ASSETS_DIR, 'jarvismeme.png')
      if (!existsSync(bgLocal)) {
        await writeFile(bgLocal, await download(BG_URL))
      }

      const fontLocal = join(ASSETS_DIR, 'ArialBd.ttf')
      if (!existsSync(fontLocal)) {
        await writeFile(fontLocal, await download(FONT_URL))
      }

      GlobalFonts.registerFromPath(fontLocal, 'ARIALBD')

      function drawTextInSafeZone(ctx, tek, zone, initialFontSize, align) {
        let fontSize = initialFontSize
        let lines = []
        let lh = fontSize * 1.2

        while (fontSize > 10) {
          lh = fontSize * 1.2
          ctx.font = `500 ${fontSize}px ARIALBD, sans-serif`
          lines = []
          let fits = true
          
          const paragraphs = tek.split('\n')
          for (const p of paragraphs) {
            let cur = ''
            const words = p.split(' ')
            
            for (const w of words) {
              const t = cur ? cur + ' ' + w : w
              if (ctx.measureText(t).width > zone.w) {
                if (cur) {
                  lines.push(cur)
                  cur = w
                  if (ctx.measureText(w).width > zone.w) {
                    fits = false
                    break
                  }
                } else {
                  fits = false
                  break
                }
              } else {
                cur = t
              }
            }
            if (!fits) break
            lines.push(cur)
          }

          if (fits && (lines.length * lh) <= zone.h) break 
          fontSize -= 2
        }

        ctx.font = `500 ${fontSize}px ARIALBD, sans-serif`
        ctx.fillStyle = '#111111'
        ctx.textBaseline = 'middle'
        ctx.textAlign = align

        const drawX = align === 'center' ? zone.x + zone.w / 2 : align === 'right' ? zone.x + zone.w : zone.x
        
        ctx.save()
        ctx.beginPath()
        ctx.rect(zone.x, zone.y, zone.w, zone.h)
        ctx.clip()
        
        const startY = zone.y + zone.h / 2 - (lines.length * lh) / 2 + lh / 2
        lines.forEach((l, i) => ctx.fillText(l, drawX, startY + i * lh))
        ctx.restore()
      }

      const canvas = createCanvas(CANVAS_SIZE.width, CANVAS_SIZE.height)
      const ctx = canvas.getContext('2d')

      const bgImg = await loadImage(bgLocal)
      ctx.drawImage(bgImg, 0, 0, CANVAS_SIZE.width, CANVAS_SIZE.height)

      const safeZone_el1 = { x: 20, y: 3, w: 695, h: 237 }
      drawTextInSafeZone(ctx, tek, safeZone_el1, 100, 'center')

      const finalBuffer = await canvas.encode('png')

      return m.reply({
        type: 'image',
        media: finalBuffer,
        mimetype: 'image/png',
        caption: '✅ *Perintah diterima.*'
      })

    } catch (err) {
      return m.reply(`❌ *Gagal merender gambar:*\n${err.message || err}`)
    }
  }
}