export default {
  command: 'instagram',
  alias: ['ig', 'igdl', 'instagramdl'],
  category: 'downloader',
  description: 'Download media video atau foto dari Instagram',
  help: '<link ig>',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const source = args.join(' ') || m.quoted?.text || ''
    const match = source.match(/(https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel|tv|stories)\/[^\s]+)/i)

    if (!match) {
      return m.reply('Masukkan atau reply URL Instagram yang valid')
    }

    const url = match[1]

    try {
      const res = await fetch(`https://api.nexray.eu.cc/downloader/instagram?url=${encodeURIComponent(url)}`)
      const json = await res.json()

      if (!json.status || !json.result || json.result.length === 0) {
        return m.reply('Gagal mengambil data, URL tidak valid atau akun diprivasi.')
      }

      const caption = `URL: ${url}`

      for (let i = 0; i < json.result.length; i++) {
        const item = json.result[i]
        
        const mediaRes = await fetch(item.url)
        if (!mediaRes.ok) continue
        
        const buffer = Buffer.from(await mediaRes.arrayBuffer())
        const isVideo = item.type === 'video'
        
        await sock.message.send(m.chat, {
          type: isVideo ? 'video' : 'image',
          media: buffer,
          mimetype: isVideo ? 'video/mp4' : 'image/jpeg',
          caption: i === 0 ? caption : ''
        }, { quote: m.raw })
      }

    } catch (err) {
      return m.reply(`Terjadi kesalahan:\n${err.message || err}`)
    }
  }
}