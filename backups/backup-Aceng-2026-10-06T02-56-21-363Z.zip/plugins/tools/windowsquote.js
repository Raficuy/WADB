import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import { writeFile, mkdir } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join } from 'node:path'

const ASSETS_DIR = join(process.cwd(), 'assets', 'wdws_meme')
const FONTS_DIR = join(ASSETS_DIR, 'fonts')
const BG_LOCAL = join(ASSETS_DIR, 'template_wdws.png')
const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/allimagerin/refs/heads/main/wdws.png'
const FONT_URL = 'https://fonts.gstatic.com/s/inter/v18/UcCO3FwrK3iLTeHuS_nVMrMxCp50SjIw2boKoduKmMEVuFuYAZ9hiJ-Ek-_EeA.woff2'
const FONT_NAME = 'Inter-Bold.ttf'
const FONT_FAMILY = 'InterBoldMeme'

async function prepareAssets() {
    if (!existsSync(FONTS_DIR)) {
        await mkdir(FONTS_DIR, { recursive: true })
    }

    const fPath = join(FONTS_DIR, FONT_NAME)
    if (!existsSync(fPath)) {
        const fRes = await fetch(FONT_URL, { headers: { 'User-Agent': 'Mozilla/5.0' } })
        if (!fRes.ok) throw new Error('Gagal mengunduh font')
        const fBuffer = Buffer.from(await fRes.arrayBuffer())
        await writeFile(fPath, fBuffer)
    }
    GlobalFonts.registerFromPath(fPath, FONT_FAMILY)

    if (!existsSync(BG_LOCAL)) {
        const resBg = await fetch(BG_URL, { headers: { 'User-Agent': 'Mozilla/5.0' } })
        if (!resBg.ok) throw new Error('Gagal mengunduh template background')
        const bgBuffer = Buffer.from(await resBg.arrayBuffer())
        await writeFile(BG_LOCAL, bgBuffer)
    }
}

function getWrappedLines(context, textStr, maxWidth) {
    const words = textStr.split(/\s+/)
    const resLines = []
    let currentLine = ''

    for (let i = 0; i < words.length; i++) {
        if (!words[i]) continue
        let testLine = currentLine + words[i] + ' '
        let metrics = context.measureText(testLine.trim())
        
        if (metrics.width > maxWidth && i > 0) {
            resLines.push(currentLine.trim())
            currentLine = words[i] + ' '
        } else {
            currentLine = testLine
        }
    }
    if (currentLine.trim()) resLines.push(currentLine.trim())
    return resLines
}

export default {
  command: 'quotedwindows',
  alias: ['wq', 'qw', 'windowsc', 'windowsquote'],
  category: 'maker',
  description: 'Membuat gambar quotes estetik dengan template error Windows.',
  help: '<teks> atau (reply pesan)',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const rawText = args.join(' ').trim() || m.quoted?.text || ''
    
    if (!rawText) {
        return m.reply(`Format salah\n\nContoh penggunaan:\n${m.prefix}${m.command} ldr tidur, besok janji bakal sampe nikah lagi\n(Bisa juga dengan reply pesan)`)
    }

    try {
        await prepareAssets()

        const bgImg = await loadImage(BG_LOCAL)
        const canvas = createCanvas(bgImg.width, bgImg.height)
        const canvasCtx = canvas.getContext('2d')
        canvasCtx.drawImage(bgImg, 0, 0, canvas.width, canvas.height)

        const x = 127
        const y = 406
        const w = 450
        const h = 601
        let fSize = 150 
        const lHeight = 1.3

        canvasCtx.fillStyle = '#1c1d21'
        canvasCtx.textBaseline = 'top'

        canvasCtx.font = `700 ${fSize}px ${FONT_FAMILY}`
        let lines = getWrappedLines(canvasCtx, rawText, w)

        let totalTextHeight = lines.length * (fSize * lHeight)
        
        while (totalTextHeight > h && fSize > 24) {
            fSize -= 4
            canvasCtx.font = `700 ${fSize}px ${FONT_FAMILY}`
            lines = getWrappedLines(canvasCtx, rawText, w)
            totalTextHeight = lines.length * (fSize * lHeight)
        }

        let startY = y
        if (totalTextHeight < h) {
            startY = y + (h - totalTextHeight) / 2 
        }

        const wordCount = rawText.split(/\s+/).filter(word => word.length > 0).length

        lines.forEach((line, index) => {
            const currentY = startY + (index * (fSize * lHeight))
            
            if (currentY + fSize <= y + h) {
                if (wordCount === 1) {
                    canvasCtx.textAlign = 'center'
                    canvasCtx.fillText(line, x + (w / 2), currentY)
                } else {
                    canvasCtx.textAlign = 'left'
                    canvasCtx.fillText(line, x, currentY)
                }
            }
        })

        const finalBuffer = await canvas.encode('png')

        await sock.message.send(m.chat, {
            type: 'image',
            media: finalBuffer,
            mimetype: 'image/png',
            caption: `Quotes Windows:\n"${rawText}"`
        }, { quote: m.raw })

    } catch (err) {
        console.error(err)
        return m.reply(`Terjadi kesalahan saat memproses gambar: ${err.message}`)
    }
  }
}