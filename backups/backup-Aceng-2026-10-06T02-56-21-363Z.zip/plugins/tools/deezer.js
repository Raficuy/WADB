import axios from 'axios'

export default {
    command: 'deezer',
    alias: ['flac', 'dz'],
    category: 'tools',
    description: 'Search and Download Deezer FLAC',
    help: '<search|dl> <query|url>',
    typing: true,
    wait: true,

    async execute(m, { args, sock }) {
        const mode = args[0]?.toLowerCase()
        const query = args.slice(1).join(' ').trim()

        if (!mode || !['search', 'dl'].includes(mode) || !query) {
            return m.reply('Format salah.\n\nContoh:\n.deezer search night changes\n.deezer dl https://www.deezer.com/track/123456')
        }

        try {
            if (mode === 'search') {
                const { data: searchRes } = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}`)
                
                if (!searchRes || !searchRes.data || searchRes.data.length === 0) {
                    return m.reply('Lagu tidak ditemukan.')
                }

                let text = 'Hasil Pencarian Deezer\n\n'
                searchRes.data.slice(0, 5).forEach((track, i) => {
                    text += `${i + 1}. ${track.title} - ${track.artist.name}\n`
                    text += `Link: ${track.link}\n\n`
                })

                return m.reply(text.trim())
            }

            if (mode === 'dl') {
                const trackUrl = query
                const trackId = trackUrl.match(/\/track\/(\d+)/)?.[1]
                
                if (!trackId) {
                    return m.reply('URL Deezer tidak valid.')
                }

                const { data: trackInfo } = await axios.get(`https://api.deezer.com/track/${trackId}`)
                if (!trackInfo || !trackInfo.title) {
                    return m.reply('Gagal mengambil metadata lagu.')
                }

                const { data: taskRes } = await axios.post('https://cap.jhx.my.id/api/createTask', {
                    url: 'https://flacdownloader.com/en',
                    type: 'turnstile-min',
                    sitekey: '0x4AAAAAAD2MQMVORZcldmdE'
                })

                if (!taskRes.success || !taskRes.jobId) {
                    return m.reply('Gagal membuat task Turnstile.')
                }

                let cfToken = null
                for (let i = 0; i < 30 && !cfToken; i++) {
                    await new Promise(r => setTimeout(r, 2000))
                    const { data: pollRes } = await axios.post('https://cap.jhx.my.id/api/getResult', { jobId: taskRes.jobId })
                    if (pollRes.status === 'ready' && pollRes.solution && pollRes.solution.token) {
                        cfToken = pollRes.solution.token
                    }
                }

                if (!cfToken) {
                    return m.reply('Timeout saat bypass Turnstile.')
                }

                const headers = {
                    'content-type': 'application/json',
                    'origin': 'https://flacdownloader.com',
                    'referer': 'https://flacdownloader.com/en/download'
                }

                const { data: prepRes } = await axios.post('https://flacdownloader.com/prepare', { cf: cfToken }, { headers })
                const dlToken = prepRes.t
                
                if (!dlToken) {
                    return m.reply('Gagal mendapatkan token download.')
                }

                headers['x-dl-token'] = dlToken

                const payload = {
                    url: trackUrl,
                    title: trackInfo.title,
                    artist: trackInfo.artist.name,
                    format: 'flac',
                    accept_fallback: false
                }

                const { data: assetRes } = await axios.post('https://flacdownloader.com/asset', payload, { headers })
                
                if (!assetRes.u) {
                    return m.reply('Gagal mendapatkan direct link FLAC.')
                }

                await axios.post('https://flacdownloader.com/asset-done', {
                    ok: true,
                    url: payload.url,
                    title: payload.title,
                    artist: payload.artist,
                    quality: 'FLAC',
                    filename: assetRes.n,
                    size: assetRes.s
                }, { headers })

                let caption = `DEEZER FLAC DOWNLOADER\n\n`
                caption += `Judul: ${assetRes.m?.title || trackInfo.title}\n`
                caption += `Artis: ${assetRes.m?.artist || trackInfo.artist.name}\n`
                caption += `File: ${assetRes.n}\n\n`
                caption += `Silakan klik tombol di bawah untuk mengunduh audio.`

                const interactivePayload = {
                    interactiveMessage: {
                        header: { 
                            title: "FLAC Siap",
                            hasMediaAttachment: false
                        },
                        body: { text: caption },
                        footer: { text: "Zapo Tools" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "Download FLAC",
                                        url: assetRes.u
                                    })
                                }
                            ]
                        }
                    }
                }

                const extraOpts = {
                    additionalNodes: [
                        {
                            tag: "biz",
                            attrs: {},
                            content: [
                                {
                                    tag: "interactive",
                                    attrs: { type: "native_flow", v: "1" },
                                    content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                                }
                            ]
                        }
                    ]
                }

                return await sock.message.send(m.chat, interactivePayload, extraOpts)
            }

        } catch (err) {
            return m.reply(`Terjadi kesalahan:\n${err.message}`)
        }
    }
}