function normalizeUrl(input) {
  if (!input) return null
  let u = String(input).trim()
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u.replace(/^\/+/, '')
  return u
}

function repoSlug(meta, fallbackUrl) {
  if (meta && meta.owner && meta.repo) return `${meta.owner}/${meta.repo}`
  try {
    const p = new URL(fallbackUrl).pathname.split('/').filter(Boolean)
    return p.slice(0, 2).join('/')
  } catch {
    return fallbackUrl
  }
}

export default {
  command: 'scanrepo',
  alias: ['scangithub', 'reposcan'],
  category: 'tools',
  description: 'Menganalisis repository Github menggunakan engine scanrepo.dev',
  help: '<url github>',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const target = normalizeUrl(args.join(' ') || m.quoted?.text || '')
    
    if (!target) {
      return m.reply('Masukkan atau reply URL Github yang valid.')
    }

    const API = 'https://www.scanrepo.dev/api/scan'
    let res

    try {
      res = await fetch(API, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'accept': 'text/plain' },
        body: JSON.stringify({ url: target }),
        signal: AbortSignal.timeout(120000)
      })
    } catch (e) {
      return m.reply('Request gagal: ' + e.message)
    }

    const status = res.status
    const ct = res.headers.get('content-type') || ''

    if (!res.ok && ct.includes('application/json')) {
      let err = {}
      try { err = await res.json() } catch {}
      return m.reply('Scan gagal: ' + (err.error || 'Status ' + status))
    }

    const decoder = new TextDecoder()
    let buf = ''
    let result = null
    let streamErr = null

    try {
      for await (const chunk of res.body) {
        buf += decoder.decode(chunk, { stream: true })
        let nl
        while ((nl = buf.indexOf('\n')) !== -1) {
          const line = buf.slice(0, nl).trim()
          buf = buf.slice(nl + 1)
          if (!line) continue
          let o
          try { o = JSON.parse(line) } catch { continue }
          if (o.type === 'result') {
            result = o.data
          } else if (o.type === 'error') {
            streamErr = o.error || o.message || 'Scan error'
          }
        }
      }
      
      const last = buf.trim()
      if (last) {
        try {
          const o = JSON.parse(last)
          if (o.type === 'result') result = o.data
          else if (o.type === 'error') streamErr = o.error || o.message
        } catch {}
      }
    } catch (e) {
      streamErr = 'Stream read failed: ' + e.message
    }

    if (!result) {
      return m.reply('Gagal memproses hasil: ' + (streamErr || 'Tidak ada data result'))
    }

    const mData = result.meta || {}
    const repo = repoSlug(mData, target)
    
    let teks = 'SCANREPO RESULT\n\n'
    teks += `Repo: ${repo}\n`
    teks += `Provider: ${mData.provider || 'Tidak diketahui'}\n`
    teks += `Language: ${mData.language || 'Tidak diketahui'}\n`
    teks += `Stars: ${mData.stars || 0} | Forks: ${mData.forks || 0}\n`
    teks += `Risk Score: ${result.riskScore || 0}\n`
    teks += `Risk Level: ${result.riskLevel || 'Tidak diketahui'}\n`
    teks += `Files Scanned: ${result.filesScanned || 0} / ${result.totalRepoFiles || 0}\n`
    teks += `Coverage: ${result.coverage || 0}%\n`

    if (Array.isArray(result.badges) && result.badges.length > 0) {
      const badges = result.badges.map(b => b.label).filter(Boolean).join(', ')
      teks += `Badges: ${badges}\n`
    }

    if (Array.isArray(result.categories) && result.categories.length > 0) {
      teks += '\nKATEGORI RISIKO:\n'
      result.categories.forEach(c => {
        const findingsCount = Array.isArray(c.findings) ? c.findings.length : 0
        teks += `- ${c.name}: Score ${c.score} (${findingsCount} temuan)\n`
      })
    }

    if (Array.isArray(result.findings) && result.findings.length > 0) {
      teks += '\nTEMUAN UTAMA:\n'
      const limit = result.findings.length > 5 ? 5 : result.findings.length
      for (let i = 0; i < limit; i++) {
        const f = result.findings[i]
        teks += `> ${f.title}\n`
        teks += `  File: ${f.file || f.path || 'Unknown'}:${f.line || '?'}\n`
        teks += `  Rule: ${f.ruleId} | Points: ${f.points}\n`
      }
      if (result.findings.length > 5) teks += `...dan ${result.findings.length - 5} temuan lainnya.\n`
    }

    if (mData.provider && mData.owner && mData.repo) {
      teks += `\nDetail: https://www.scanrepo.dev/scan/${mData.provider}/${mData.owner}/${mData.repo}`
    }
    
    teks += '\n\nCreator: Yamzzdev'

    return m.reply(teks.trim())
  }
}