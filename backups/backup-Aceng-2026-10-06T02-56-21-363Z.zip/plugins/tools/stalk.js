export default {
  command: 'stalk',
  alias: ['kepoin', 'profil', 'info'],
  category: 'tools',
  typing: true,
  description: '> Ekstraksi data maksimal (Server Meta + Local Metadata).',
  help: '(@mention atau reply)',

  async execute(m, { sock, args }) {
    
    const targets = resolveTargets(m, args.join(' ').trim())
    if (!targets.length) {
      return m.reply('❌ Target tidak ditemukan. Reply pesan, mention, atau ketik nomor target.')
    }

    const jid = targets[0]
 
    let pushName = 'Tidak terdeteksi'
    let deviceId = 'Tidak terdeteksi'
    let msgType = 'Tidak ada (Bukan dari reply)'

    if (m.quoted && (jid === m.quoted.sender || jid === m.quoted.participant)) {

      pushName = m.quoted.pushName || 'Tidak terdeteksi'
      deviceId = m.quoted.deviceId || 'Primary/Web'
      msgType = m.quoted.type || 'unknown'
    }

    let buffer = null
    let ppUrl = null
    let statusInfo = 'Tidak ada / Diprivasi'
    let disappearingMode = 'Mati / Default'
    let waUsername = 'Tidak disetel'
    let profileData = 'Tidak ada data tambahan'

    try {
      const pp = await sock.profile.getProfilePicture(jid, 'image')
      if (pp?.url) {
        ppUrl = pp.url
        const res = await fetch(ppUrl)
        if (res.ok) buffer = Buffer.from(await res.arrayBuffer())
      }
    } catch (err) {}

    try {
      let bio = await sock.profile.getAboutStatus(jid).catch(() => null)
      if (!bio && sock.profile.getStatus) bio = await sock.profile.getStatus(jid).catch(() => null)
      if (!bio && sock.profile.getTextStatuses) bio = await sock.profile.getTextStatuses([jid]).catch(() => null)
      
      if (bio) {
        if (typeof bio === 'string') statusInfo = bio
        else if (Array.isArray(bio) && bio.length > 0) statusInfo = bio[0]?.status || bio[0]?.about || 'Diprivasi'
        else statusInfo = bio?.status || bio?.about || 'Diprivasi'
      }
    } catch (err) {}

    try {
      if (sock.profile.getDisappearingMode) {
        const dm = await sock.profile.getDisappearingMode(jid)
        if (dm && dm.duration) disappearingMode = `Aktif (${dm.duration} detik)`
        else if (dm === true) disappearingMode = 'Aktif'
      }
    } catch (err) {}

    try {
      if (sock.profile.getUsernames) {
        const usernames = await sock.profile.getUsernames([jid])
        if (Array.isArray(usernames) && usernames.length > 0 && usernames[0]) {
          waUsername = `@${usernames[0].username || usernames[0]}`
        }
      }
    } catch (err) {}

    try {
      if (sock.profile.getProfiles) {
        const p = await sock.profile.getProfiles([jid])
        if (p && p.length > 0) profileData = 'profil ditemukan'
      }
    } catch (err) {}

    const idType = jid.includes('@lid') ? 'LID (Hidden ID)' : 'JID (Nomor Asli)'
    const cleanId = jid.split('@')[0]

    const caption = `*WANGSAF STALKER*\n\n` +
                    `* *(Metadata)*\n` +
                    `├  *Nama WA:* ${pushName}\n` +
                    `├  *Device:* ${deviceId}\n` +
                    `└  *Tipe Pesan:* ${msgType}\n\n` +
                    `├  *ID Target:* ${cleanId}\n` +
                    `├  *Tipe ID:* ${idType}\n` +
                    `├  *Username:* ${waUsername}\n` +
                    `├  *Bio WA:* ${statusInfo}\n` +
                    `├  *Pesan Sementara:* ${disappearingMode}\n` +
                    `└ *Status Server:* ${profileData}`

    if (buffer) {
      await sock.message.send(m.chat, { 
        type: 'image', 
        media: buffer, 
        mimetype: 'image/jpeg', 
        caption: caption 
      }, { quoted: m })
    } else {
      await m.reply(`${caption}\n\n_(Gambar: Profil disembunyikan / tidak ada)_`)
    }
  }
}

function resolveTargets(m, rawArgs) {
  const targets = new Set()

  if (m.quoted?.sender && !m.quoted.sender.endsWith('@g.us') && !m.quoted.sender.endsWith('@newsletter')) {
    targets.add(m.quoted.sender)
  }

  const mentioned = (m.mentionedJid || []).filter(j => !j.endsWith('@g.us') && !j.endsWith('@newsletter'))
  for (const jid of mentioned) targets.add(jid)

  if (rawArgs) {
    const parts = rawArgs.split(',').map(s => s.trim()).filter(Boolean)
    for (const part of parts) {
      const cleaned = part.replace(/^@/, '')
      if (/^\d+@(s\.whatsapp\.net|lid)$/.test(cleaned)) {
        targets.add(cleaned)
      } else if (/^\d{8,20}$/.test(cleaned)) {
        targets.add(`${cleaned}@s.whatsapp.net`)
      }
    }
  }

  return [...targets]
}