import axios from 'axios'

export default {
  command: 'testskrep',
  alias: ['curl'],
  category: 'tools',
  description: 'Cek status website target scraper (Cloudflare/Error/200)',
  help: '<url>',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    let url = args[0]
    if (!url) {
      return m.reply('Masukin URL targetnya cuy.\nContoh: .testskrep https://google.com')
    }

    if (!url.startsWith('http')) {
      url = 'https://' + url
    }

    try {
      
      const start = Date.now()
      const res = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        },
        timeout: 15000,
        validateStatus: () => true 
      })
      const time = Date.now() - start

      const status = res.status
      const rawData = res.data
      const html = typeof rawData === 'string' ? rawData : JSON.stringify(rawData, null, 2)
      
      let title = '-'
      const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)
      if (titleMatch) title = titleMatch[1].trim().replace(/\s+/g, ' ')

      const isCloudflare = 
        status === 403 || 
        status === 503 ||
        html.toLowerCase().includes('cloudflare') || 
        html.toLowerCase().includes('just a moment') ||
        html.toLowerCase().includes('ray id')

      let msg = `*Cek websire*\n\n`
      msg += `* *Target:* ${url}\n`
      msg += `* *Speed:* ${time}ms\n`
      msg += `* *Status:* ${status} ${status === 200 ? '✅ (Aman)' : '❌ (Bermasalah)'}\n`
      msg += `* *Title:* ${title}\n`
      
      if (isCloudflare) {
        msg += `\n*WARNING:* cf/hcapca on.\n`
      }

      msg += `\n*Preview HTML: abcd*\n`
      msg += `_Karena text htmlnya panjang, full HTML-nya dikirim kirim sebagai file html_`

      await m.reply(msg.trim())

      const htmlBuffer = Buffer.from(html, 'utf-8')
      await sock.message.send(m.chat, {
        type: 'document',
        media: htmlBuffer,
        mimetype: 'text/html',
        fileName: 'source_code.html'
      }, { quote: m.raw })

    } catch (err) {
      return m.reply(`❌ Gagal konek ke URL:\n${err.message}`)
    }
  }
}