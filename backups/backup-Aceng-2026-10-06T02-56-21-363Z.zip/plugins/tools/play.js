import ytSearch from 'yt-search'
import { AIRich } from '../../lib/MessageBuilder.js'
import { mkdtemp, writeFile, readFile, rm } from 'fs/promises'
import { tmpdir } from 'os'
import { join } from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'

const execFileAsync = promisify(execFile)

// Fungsi untuk mengecilkan ukuran lagu dan mengubahnya ke Base64 (Syarat wajib bypass WA)
async function compressForAIRich(inputPath, tempDir) {
  const outputPath = join(tempDir, 'airich-compressed.mp3')
  try {
    // Kompresi bitrate ke 16k agar muat di limit HTML WhatsApp (< 1MB)
    await execFileAsync('ffmpeg', [
      '-y', '-hide_banner', '-loglevel', 'error',
      '-i', inputPath, '-vn',
      '-t', '300', // Limit 5 menit
      '-codec:a', 'libmp3lame', '-b:a', '16k', '-ac', '1', '-ar', '16000',
      outputPath
    ], { maxBuffer: 1024 * 1024 * 10 })

    const buffer = await readFile(outputPath)
    return 'data:audio/mpeg;base64,' + buffer.toString('base64')
  } catch (e) { 
    return null 
  }
}

export default {
  command: 'play',
  alias: ['music', 'song'],
  category: 'downloader',
  description: 'Mencari dan memutar lagu dengan Audio murni & AIRich Premium Player',
  help: '<judul lagu>',
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const query = args.join(' ').trim() || m.quoted?.text || ''

    if (!query) {
      return m.reply('Masukkan judul lagu yang ingin diputar.')
    }

    let tempDir = null

    try {
      const search = await ytSearch(query)
      if (!search || !search.videos || !search.videos.length) {
        return m.reply('Lagu tidak ditemukan.')
      }
      
      const video = search.videos[0]
      const title = video.title
      const channel = video.author.name
      const duration = video.timestamp
      const thumbnail = "https://d.tmpfile.link/public/2026-09-01/ef658c6c-0347-4401-9a3d-dacd2604ab28/file_1788278415149.jpeg"
      const cylicLogo = 'https://d.tmpfile.link/public/2026-09-01/ef658c6c-0347-4401-9a3d-dacd2604ab28/file_1788278415149.jpeg'

      const rich = new AIRich(sock)
      rich.addText(`Loading:\n*${title}*...`, { id: 'loading_player' })
      await rich.send(m.chat)

      const apiRes = await fetch(`https://api.azbry.com/api/download/ytplay2?q=${encodeURIComponent(video.url)}`)
      const data = await apiRes.json()

      if (!data.status || !data.result) {
        throw new Error('Gagal mengambil data dari server downloader.')
      }

      const audioUrl = data.result.download
      const audioRes = await fetch(audioUrl)
      if (!audioRes.ok) throw new Error('Gagal menarik file audio murni.')
      const audioBuffer = Buffer.from(await audioRes.arrayBuffer())

      await sock.message.send(m.chat, {
        type: 'audio',
        media: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quote: m.raw })

      tempDir = await mkdtemp(join(tmpdir(), 'Audio-play-'))
      const inputPath = join(tempDir, 'original.mp3')
      await writeFile(inputPath, audioBuffer)

      const audioDataUri = await compressForAIRich(inputPath, tempDir)
      if (!audioDataUri) throw new Error('Gagal memproses audio untuk Player HTML.')

      const html = `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;touch-action:none;}
html,body{margin:0;padding:0;width:100%;background:transparent;font-family:Arial,Helvetica,sans-serif;color:#fff}
.playerWrap{width:100%;max-width:620px;margin:auto;padding:8px}
.player{position:relative;overflow:hidden;padding:16px;border-radius:22px;background:linear-gradient(145deg,#111318 0%,#090a0d 55%,#050506 100%);border:1px solid rgba(255,255,255,.14);box-shadow:0 12px 35px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,255,255,.07)}
.glow{position:absolute;width:190px;height:190px;right:-90px;top:-100px;border-radius:50%;background:rgba(108,92,231,.12);filter:blur(55px);pointer-events:none}
.header{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;margin-bottom:15px}
.brand{display:flex;align-items:center;gap:9px;font-size:14px;font-weight:bold;letter-spacing:.7px}
.logo{width:31px;height:31px;border-radius:9px;object-fit:contain;background:#fff;padding:4px;box-shadow:0 3px 12px rgba(0,0,0,.5)}
.botName{font-size:13px;font-weight:bold}
.botSub{margin-top:2px;font-size:8px;color:#777;letter-spacing:1px}
.live{padding:5px 9px;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.04);font-size:8px;font-family:monospace;color:#aaa;letter-spacing:1px}
.main{position:relative;z-index:2;display:flex;align-items:center;gap:15px;padding:13px;border-radius:17px;border:1px solid rgba(255,255,255,.09);background:linear-gradient(145deg,#17181d,#0d0e11);box-shadow:0 6px 16px rgba(0,0,0,.4)}
.cover{position:relative;flex:none;width:82px;height:82px;border-radius:17px;overflow:hidden;border:1px solid rgba(255,255,255,.18);background:#08090b;box-shadow:0 5px 15px rgba(0,0,0,.55)}
.cover img{width:100%;height:100%;object-fit:cover;display:block}
.coverOverlay{position:absolute;left:0;right:0;bottom:0;height:38%;background:linear-gradient(transparent,rgba(0,0,0,.75))}
.details{min-width:0;flex:1}
.title{font-size:16px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.channel{margin-top:5px;font-size:9px;font-family:monospace;color:#777;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.visualizer{height:28px;display:flex;align-items:center;gap:3px;margin-top:9px}
.visualizer span{width:3px;height:4px;border-radius:4px;background:#ddd;opacity:.8}
.visualizer.playing span{animation:bars .72s ease-in-out infinite alternate}
.visualizer span:nth-child(1){animation-delay:-.7s}
.visualizer span:nth-child(2){animation-delay:-.5s}
.visualizer span:nth-child(3){animation-delay:-.2s}
.visualizer span:nth-child(4){animation-delay:-.6s}
.visualizer span:nth-child(5){animation-delay:-.3s}
.visualizer span:nth-child(6){animation-delay:-.8s}
.visualizer span:nth-child(7){animation-delay:-.4s}
.visualizer span:nth-child(8){animation-delay:-.1s}
.visualizer span:nth-child(9){animation-delay:-.55s}
.visualizer span:nth-child(10){animation-delay:-.25s}
@keyframes bars{0%{height:4px}50%{height:14px}100%{height:26px}}
.progressArea{position:relative;z-index:2;margin-top:17px}
.progress{position:relative;width:100%;height:15px;display:flex;align-items:center;cursor:pointer}
.progressTrack{width:100%;height:6px;border-radius:8px;background:#24252a;border:1px solid rgba(255,255,255,.08);position:relative;pointer-events:none}
.progressBar{position:absolute;left:0;top:-1px;width:0%;height:6px;border-radius:8px;background:#fff;box-shadow:0 0 9px rgba(255,255,255,.3)}
.progressDot{position:absolute;left:0%;top:50%;width:13px;height:13px;transform:translate(-50%,-50%);border-radius:50%;background:#fff;border:2px solid #777;box-shadow:0 0 8px rgba(255,255,255,.25)}
.time{display:flex;justify-content:space-between;margin-top:2px;font-size:9px;font-family:monospace;color:#777}
.controls{position:relative;z-index:2;display:flex;gap:10px;margin-top:15px}
.playBtn{width:100px;height:45px;border:none;border-radius:13px;background:#fff;color:#000;font-size:10px;font-weight:bold;letter-spacing:1px;box-shadow:0 5px 15px rgba(0,0,0,.45);transition:transform .12s ease}
.playBtn:active{transform:scale(.94)}
.volumeBox{flex:1;height:45px;display:flex;align-items:center;gap:9px;padding:0 12px;border-radius:13px;border:1px solid rgba(255,255,255,.09);background:#111216}
.volumeLabel{font-size:8px;font-family:monospace;color:#888;letter-spacing:1px}
.volume{width:100%;height:4px;accent-color:#fff}
.status{position:relative;z-index:2;margin-top:13px;text-align:center;font-size:8px;font-family:monospace;font-weight:bold;letter-spacing:1.7px;color:#aaa}
.line{position:relative;z-index:2;height:1px;margin-top:12px;background:linear-gradient(90deg,transparent,#444,transparent)}
.footer{position:relative;z-index:2;margin-top:9px;text-align:center;font-size:7px;font-family:monospace;color:#4e4e53;letter-spacing:.5px}
</style>

<div class="playerWrap">
  <div class="player">
    <div class="glow"></div>
    <div class="header">
      <div class="brand">
        <img class="logo" src="${cylicLogo}">
        <div>
          <div class="botName">Audio Musik</div>
          <div class="botSub">MUSIC PLAYER</div>
        </div>
      </div>
      <div class="live">MP3</div>
    </div>
    
    <div class="main">
      <div class="cover">
        <img src="${thumbnail}" onerror="this.style.display='none'">
        <div class="coverOverlay"></div>
      </div>
      <div class="details">
        <div class="title">${title}</div>
        <div class="channel">${channel}</div>
        <div class="visualizer" id="visualizer">
          <span></span><span></span><span></span><span></span><span></span>
          <span></span><span></span><span></span><span></span><span></span>
        </div>
      </div>
    </div>

    <div class="progressArea">
      <div class="progress" id="progress">
        <div class="progressTrack">
          <div class="progressBar" id="progressBar"></div>
          <div class="progressDot" id="progressDot"></div>
        </div>
      </div>
      <div class="time">
        <span id="current">0:00</span>
        <span id="duration">${duration}</span>
      </div>
    </div>

    <div class="controls">
      <button class="playBtn" id="play" type="button">▶ PLAY</button>
      <div class="volumeBox">
        <div class="volumeLabel">VOL</div>
        <input class="volume" id="volume" type="range" min="0" max="1" step=".01" value=".8">
      </div>
    </div>

    <div class="status" id="status">READY TO PLAY</div>
    <div class="line"></div>
    <div class="footer">CYLICDEV • YOUTUBE MUSIC PLAYER</div>
  </div>
</div>

<!-- BASE64 AUDIO URI DIPASANG DI SINI -->
<audio id="audio" preload="auto" playsinline src="${audioDataUri}"></audio>

<script>
(function(){
  const audio = document.getElementById('audio');
  const play = document.getElementById('play');
  const volume = document.getElementById('volume');
  const progress = document.getElementById('progress');
  const progressBar = document.getElementById('progressBar');
  const progressDot = document.getElementById('progressDot');
  const current = document.getElementById('current');
  const duration = document.getElementById('duration');
  const status = document.getElementById('status');
  const visualizer = document.getElementById('visualizer');

  if(!audio || !play) return;
  audio.volume = 0.8;

  function formatTime(sec){
    if(!Number.isFinite(sec)) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ':' + String(s).padStart(2,'0');
  }

  function update(){
    if(!Number.isFinite(audio.duration) || audio.duration <= 0) return;
    const percent = (audio.currentTime / audio.duration) * 100;
    progressBar.style.width = percent + '%';
    progressDot.style.left = percent + '%';
    current.textContent = formatTime(audio.currentTime);
    duration.textContent = formatTime(audio.duration);
  }

  function playing(){
    play.textContent = 'Ⅱ PAUSE';
    status.textContent = 'NOW PLAYING';
    visualizer.classList.add('playing');
  }

  function paused(){
    play.textContent = '▶ PLAY';
    status.textContent = 'PAUSED';
    visualizer.classList.remove('playing');
  }

  play.addEventListener('pointerdown', async function(e){
    e.preventDefault();
    try{
      if(audio.paused){
        status.textContent = 'LOADING AUDIO...';
        play.textContent = '◌ LOAD';
        await audio.play();
        playing();
      }else{
        audio.pause();
        paused();
      }
    }catch(error){
      status.textContent = 'AUDIO LOAD ERROR';
      play.textContent = '↻ RETRY';
      visualizer.classList.remove('playing');
    }
  });

  volume.addEventListener('input', function(){ audio.volume = Number(volume.value); });

  progress.addEventListener('pointerdown', function(e){
    e.preventDefault();
    if(!Number.isFinite(audio.duration) || audio.duration <= 0) return;
    const rect = progress.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    audio.currentTime = (x / rect.width) * audio.duration;
    update();
  });

  audio.addEventListener('loadedmetadata', function(){ duration.textContent = formatTime(audio.duration); });
  audio.addEventListener('timeupdate', function(){ update(); });
  audio.addEventListener('play', function(){ playing(); });
  audio.addEventListener('pause', function(){ if(!audio.ended) paused(); });
  audio.addEventListener('error', function(){
    status.textContent = 'AUDIO LOAD ERROR';
    play.textContent = '↻ RETRY';
    visualizer.classList.remove('playing');
  });
  audio.addEventListener('ended', function(){
    play.textContent = '▶ PLAY';
    status.textContent = 'PLAYBACK COMPLETE';
    visualizer.classList.remove('playing');
    progressBar.style.width = '0%';
    progressDot.style.left = '0%';
    current.textContent = '0:00';
  });
})();
</script>`

      const minifiedHtml = html.replace(/\n/g, '').replace(/\s{2,}/g, ' ').trim()

      if (Buffer.byteLength(minifiedHtml, 'utf8') > 950000) {
        throw new Error('Ukuran lagu terlalu besar untuk player interaktif.')
      }

      const customHtmlSection = AIRich.newLayout('Single', {
        __typename: "GenAIaeacdsnwHtmlPrimitive",
        payload: minifiedHtml,
        trusted_sources: ["cylic.dev", "youtube.com", "store.ubet.my.id", "api.azbry.com"]
      })

      const customSubmessage = {
        messageType: 2,
        messageText: "CYLICDEV MUSIC PLAYER"
      }

      rich._addContent(customHtmlSection, customSubmessage, { replace: 'loading_player', id: 'player_ready' })

      await rich.sendEdit()

    } catch (err) {
      return m.reply(`❌ Gagal memutar lagu: ${err.message || err}`)
    } finally {

      if (tempDir) await rm(tempDir, { recursive: true, force: true }).catch(() => {})
    }
  }
}