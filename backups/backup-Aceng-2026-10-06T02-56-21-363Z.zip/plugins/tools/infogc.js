export default {
  command: 'infogc',
  alias: ['groupinfo', 'gcinfo', 'infogrup'],
  category: 'grup',
  description: 'Menampilkan informasi super lengkap tentang grup beserta pengaturannya',
  help: '',
  groupOnly: true,

  async execute(m, { sock }) {
    try {
      const metadata = await sock.group.queryGroupMetadata(m.chat)
      
      const subject = metadata.subject || 'Tidak diketahui'
      const owner = metadata.owner ? metadata.owner.split('@')[0] : 'Tidak diketahui'
      const creation = metadata.creation ? new Date(metadata.creation * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : 'Tidak diketahui'
      
      const members = metadata.participants || []
      const totalMembers = members.length
      const admins = members.filter(p => p.admin === 'admin' || p.admin === 'superadmin').length
      
      const desc = metadata.desc ? metadata.desc.toString() : 'Tidak ada deskripsi'

      const isAnnounce = metadata.announce ? 'Hanya Admin' : 'Semua Member'
      const isRestrict = metadata.restrict ? 'Hanya Admin' : 'Semua Member'
      const isEphemeral = metadata.ephemeralDuration ? `Aktif (${metadata.ephemeralDuration} detik)` : 'Mati'
      const approvalMode = metadata.joinApprovalMode ? 'Aktif (Butuh Persetujuan)' : 'Mati (Bebas Masuk)'
      const memberAddMode = metadata.memberAddMode === 'admin_add' ? 'Hanya Admin' : 'Semua Member'
      const isCommunity = metadata.linkedParent ? 'Ya (Sub-grup Komunitas)' : (metadata.isCommunity ? 'Ya (Grup Komunitas Utama)' : 'Bukan Komunitas')

      let teks = 'INFORMASI GRUP\n\n'
      
      teks += 'DATA UTAMA\n'
      teks += `Nama: ${subject}\n`
      teks += `ID: ${metadata.id}\n`
      teks += `Owner: ${owner}\n`
      teks += `Dibuat: ${creation}\n`
      teks += `Komunitas: ${isCommunity}\n\n`

      teks += 'STATISTIK ANGGOTA\n'
      teks += `Total Member: ${totalMembers}\n`
      teks += `Total Admin: ${admins}\n\n`

      teks += 'PENGATURAN GRUP\n'
      teks += `Kirim Pesan: ${isAnnounce}\n`
      teks += `Edit Info: ${isRestrict}\n`
      teks += `Tambah Member: ${memberAddMode}\n`
      teks += `Persetujuan Masuk: ${approvalMode}\n`
      teks += `Pesan Sementara: ${isEphemeral}\n\n`

      teks += `DESKRIPSI:\n${desc}`

      return m.reply(teks.trim())
    } catch (err) {
      return m.reply('Gagal mengambil data grup: ' + (err.message || err))
    }
  }
}