import { filterEncNodes, extractReplayableAttrs } from '../../lib/rawMessageUtils.js'
import { getRawMessageById } from '../../db/rawMessage.js'
import { getGroupMetadata } from '../../db/groupCache.js'

export default {
  command: 'hidetag',
  alias: ['ht', 'h', 'tagall'],
  category: 'admin',
  description: 'Hidetag.',
  help: '(reply pesan atau ketik teks/media)',
  adminOnly: true, 
  groupOnly: true, 

  async execute(m, { sock, q }) {

    if (!m.quoted && !q && !m.type.includes('conversation') && !m.type.includes('extendedTextMessage') && !m.type.includes('image') && !m.type.includes('video') && !m.type.includes('document')) {
      return sock.message.send(m.chat, { 
        text: '❌ Reply pesan, atau ketik teks/kirim media dengan caption.' 
      }, { additionalAttributes: { type: "text" } })
    }

    try {

      let participants = []
      try {
        const groupMeta = await getGroupMetadata(m.chat, sock)
        if (groupMeta && groupMeta.participants) {
          participants = groupMeta.participants.map(p => p.id || p.jid)
        }
      } catch (e) {
        console.error('[HIDETAG] Gagal ngambil data grup', e)
      }

      if (participants.length === 0) {
        return m.reply('❌ Gagal mengambil daftar member grup.')
      }

      let rawMessage = {}
      let nodes = null
      let finalAttrs = {}

      let userText = q || ''
      if (!userText && m.text) {
        userText = m.text.replace(/^[^\s]+\s*/, '') 
      }

      if (m.quoted) {

        const quotedId = m.quoted?.id || m.quoted?.key?.id || m.raw?.message?.extendedTextMessage?.contextInfo?.stanzaId
        const stored = quotedId ? getRawMessageById(quotedId) : null
        
        let tempRaw = stored?.raw?.message 
          || m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage 
          || m.quoted?.message 
          || m.quoted?.full
        
        if (tempRaw?.message) tempRaw = tempRaw.message
        if (!tempRaw) return m.reply('❌ Gagal mengekstrak pesan.')

        const type = Object.keys(tempRaw).find(k => k !== 'messageContextInfo' && k !== 'senderKeyDistributionMessage')
        if (!type) return m.reply('❌ Tipe pesan tidak didukung.')
        
        rawMessage[type] = { ...tempRaw[type] }

        nodes = filterEncNodes(stored?.raw?.nodes || m.quoted?.nodes || null)
        const baseAttrs = extractReplayableAttrs(m.quoted?.json) || {}
        finalAttrs = { ...baseAttrs }
        if (Object.keys(finalAttrs).length === 0) finalAttrs.type = "text"

      } else {

        const tempRaw = m.raw?.message
        const type = Object.keys(tempRaw).find(k => k !== 'messageContextInfo' && k !== 'senderKeyDistributionMessage')
        
        if (!type) return m.reply('❌ Tipe pesan tidak didukung.')

        if (type === 'conversation' || type === 'extendedTextMessage') {
       
          rawMessage.extendedTextMessage = { text: userText }
          finalAttrs = { type: "text" }
        } else {
          rawMessage[type] = { ...tempRaw[type] }
          
          if (rawMessage[type].caption !== undefined || type === 'imageMessage' || type === 'videoMessage' || type === 'documentMessage') {
            rawMessage[type].caption = userText
          }

          const baseAttrs = extractReplayableAttrs(m.raw?.json) || {}
          finalAttrs = { ...baseAttrs }
        }
      }

      const msgKey = Object.keys(rawMessage)[0]
      
      if (!rawMessage[msgKey].contextInfo) {
        rawMessage[msgKey].contextInfo = {}
      }

      delete rawMessage[msgKey].contextInfo.stanzaId
      delete rawMessage[msgKey].contextInfo.participant
      delete rawMessage[msgKey].contextInfo.quotedMessage

      rawMessage[msgKey].contextInfo.mentionedJid = participants

      await sock.message.send(
        m.chat, 
        rawMessage, 
        {
          additionalAttributes: finalAttrs,
          ...(nodes && nodes.length > 0 ? { additionalNodes: nodes } : {})
        }
      )

    } catch (err) {
      console.error('[HIDETAG] Error:', err)
      return sock.message.send(m.chat, { 
        text: `Gagal mengirim hidetag:\n${err.message || err}` 
      }, { additionalAttributes: { type: "text" } })
    }
  }
}