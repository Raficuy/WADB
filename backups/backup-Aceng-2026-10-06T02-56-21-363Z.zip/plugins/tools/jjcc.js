import fs from 'fs'
import { spawn } from 'child_process'
import axios from 'axios'
import FormData from 'form-data'
import { downloadContentFromMessage } from 'baileys'

// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
// KELAS API JJ CAPCUT MUTLAK
// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
class JJCapcut {
    constructor() {
        this.baseUrl = 'https://cc.fgsi.dpdns.org'
        this.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Origin': this.baseUrl,
            'Referer': `${this.baseUrl}/`
        }
    }

    async getCookie(templateId = '') {
        try {
            const url = templateId ? `${this.baseUrl}/create/${templateId}` : `${this.baseUrl}/`
            const res = await axios.get(url, { headers: this.headers })
            const setCookie = res.headers['set-cookie']
            return setCookie ? setCookie[0].split(';')[0] : ''
        } catch {
            return ''
        }
    }

    async list() {
        try {
            const res = await axios.get(`${this.baseUrl}/list`, { headers: this.headers })
            return Object.entries(res.data).map(([key, val]) => ({
                index: Number(key),
                id: String(val.id),
                title: val.title || 'Untitled',
                mediaCount: Number(val.mediaCount || 1),
                resolusi: val.resolusi || '9:16'
            }))
        } catch {}

        try {
            const res = await axios.get(`${this.baseUrl}/`, { headers: this.headers })
            const match = res.data.match(/<script id="__NEXT_DATA__" type="application\/json">(.*?)<\/script>/)
            if (match) {
                const data = JSON.parse(match[1])
                const templates = data?.props?.pageProps?.templates || []
                return templates.map((val, idx) => ({
                    index: idx + 1,
                    id: String(val.id),
                    title: val.title || 'Untitled',
                    mediaCount: Number(val.mediaCount || 1),
                    resolusi: val.resolusi || '9:16'
                }))
            }
        } catch (e) {
            throw new Error(`Gagal narik daftar template mutlak.`)
        }
        return []
    }

    async search(query = '', limit = 10, offset = 0) {
        const cookie = await this.getCookie()
        const url = `${this.baseUrl}/search?q=${encodeURIComponent(query)}&limit=${limit}&offset=${offset}`
        const headers = { ...this.headers }
        if (cookie) headers['Cookie'] = cookie

        const res = await axios.get(url, { headers })
        return res.data
    }

    async create(templateId, images = []) {
        const cookie = await this.getCookie(templateId)
        const form = new FormData()
        form.append('id', String(templateId))

        for (let i = 0; i < images.length; i++) {
            form.append('files', images[i], { filename: `image_${i + 1}.jpg` })
        }

        const headers = {
            ...this.headers,
            'Referer': `${this.baseUrl}/create/${templateId}`,
            ...form.getHeaders()
        }
        if (cookie) headers['Cookie'] = cookie

        const res = await axios.post(`${this.baseUrl}/jj`, form, { headers })
        if (!res.data?.task_id) throw new Error(res.data?.error || 'Gagal dapet task_id mutlak.')

        return { taskId: res.data.task_id, cookie, templateId }
    }

    async checkTask(taskId, templateId = '', cookie = '') {
        const headers = {
            ...this.headers,
            'Referer': templateId ? `${this.baseUrl}/create/${templateId}` : `${this.baseUrl}/`
        }
        if (cookie) headers['Cookie'] = cookie

        const res = await axios.get(`${this.baseUrl}/task/${taskId}`, { headers })
        const json = res.data
        const videoUrl = json.video?.videoUrl || (typeof json.video === 'string' ? json.video : null) || json.result || json.url || null

        return {
            status: json.status,
            videoUrl,
            error: json.error || null,
            raw: json
        }
    }

    async render(templateId, images = [], options = {}) {
        const { interval = 5000, maxRetries = 50 } = options
        const task = await this.create(templateId, images)
        const { taskId, cookie } = task

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            await new Promise(r => setTimeout(r, interval))
            let result
            try {
                result = await this.checkTask(taskId, templateId, cookie)
            } catch {
                continue
            }

            if (result.videoUrl) {
                return { status: 'success', taskId, templateId, videoUrl: result.videoUrl }
            }

            if (result.status === 'error') {
                const err = result.error || 'Unknown error'
                if (err.includes('503')) throw new Error('Server CapCut lagi down mutlak (HTTP 503).')
                throw new Error(`Render meledak: ${err}`)
            }
        }
        throw new Error('Proses render timeout mutlak.')
    }
}

const jj = new JJCapcut()

// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
// FUNGSI KOMPRESI FFMPEG
// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
async function compressImageBuffer(buffer) {
    return new Promise((resolve, reject) => {
        const args = ['-i', 'pipe:0', '-vf', "scale='min(720,iw)':-1", '-q:v', '5', '-f', 'image2', '-c:v', 'mjpeg', 'pipe:1']
        const ffmpegProcess = spawn('ffmpeg', args)
        let chunks = []

        ffmpegProcess.stdout.on('data', chunk => chunks.push(chunk))
        ffmpegProcess.on('close', code => {
            if (code === 0) resolve(Buffer.concat(chunks))
            else reject(new Error(`FFmpeg image crash mutlak.`))
        })
        ffmpegProcess.on('error', reject)
        ffmpegProcess.stdin.write(buffer)
        ffmpegProcess.stdin.end()
    })
}

async function compressVideoBuffer(buffer) {
    return new Promise((resolve, reject) => {
        const args = ['-i', 'pipe:0', '-vcodec', 'libx264', '-crf', '28', '-preset', 'ultrafast', '-f', 'mp4', '-movflags', 'frag_keyframe+empty_moov', 'pipe:1']
        const ffmpegProcess = spawn('ffmpeg', args)
        let chunks = []

        ffmpegProcess.stdout.on('data', chunk => chunks.push(chunk))
        ffmpegProcess.on('close', code => {
            if (code === 0) resolve(Buffer.concat(chunks))
            else reject(new Error(`FFmpeg video crash mutlak.`))
        })
        ffmpegProcess.on('error', reject)
        ffmpegProcess.stdin.write(buffer)
        ffmpegProcess.stdin.end()
    })
}

// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
// PLUGIN ZAPO MUTLAK
// ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━
export default {
    command: 'jj',
    alias: ['jjcapcut', 'jjlist', 'jjsearch', 'jjrender'],
    category: 'tools',
    description: 'Render video CapCut otomatis pakai template JJ mutlak.',
    help: 'list | search <query> | render <nomor/id>',
    typing: true,
    wait: true,

    async execute(m, { args, sock }) {
        let action = m.command.toLowerCase()
        if (action === 'jj' || action === 'jjcapcut') {
            action = args[0] ? `jj${args[0].toLowerCase()}` : 'help'
        }
        
        const inputParams = args.slice(1).join(' ').trim() || args.join(' ').trim()

        try {
            // 1. FITUR LIST TEMPLATE
            if (action.includes('list')) {
                await m.reply('🔄 *Membongkar daftar template server...*')
                const templates = await jj.list()
                if (!templates.length) return m.reply('❌ Gagal ngambil daftar atau server lagi kosong mutlak.')

                let txt = `🎬 *DAFTAR TEMPLATE CAPCUT*\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n\n`
                templates.forEach((t) => {
                    txt += `*${t.index}.* ${t.title}\n`
                    txt += `↳ 🆔 ID: \`${t.id}\`\n`
                    txt += `↳ 📸 Butuh: ${t.mediaCount} Foto | 📐 Rasio: ${t.resolusi}\n\n`
                })
                txt += `💡 *Cara Pakai:* Reply gambar lu dengan perintah *.jj render <nomor/id>*`
                return m.reply(txt.trim())
            }

            // 2. FITUR SEARCH TEMPLATE
            if (action.includes('search')) {
                if (!inputParams) return m.reply(`❌ Masukin kata kuncinya cuy!\n*Contoh:* .jj search jedag jedug`)
                
                await m.reply(`🔍 *Mencari template untuk:* ${inputParams}...`)
                const results = await jj.search(inputParams, 5, 0)
                if (!results.length) return m.reply('❌ Template kaga ditemuin mutlak.')

                let txt = `🔍 *HASIL PENCARIAN TEMPLATE*\n━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n\n`
                results.forEach((item, i) => {
                    txt += `*${i + 1}.* ${item.title}\n`
                    txt += `↳ 🆔 ID: \`${item.id}\`\n`
                    txt += `↳ 👤 Author: ${item.author?.name || 'Unknown'}\n\n`
                })
                return m.reply(txt.trim())
            }

            // 3. FITUR RENDER TEMPLATE (MAIN CORE)
            if (action.includes('render')) {
                if (!inputParams) return m.reply(`❌ Masukin Nomor urut atau ID Template!\n*Contoh:* .jj render 1`)

                const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
                const imageMessage = rawQuoted?.imageMessage || m.quoted?.message?.imageMessage || m.quoted?.imageMessage || m.message?.imageMessage

                if (!imageMessage) return m.reply(`❌ Reply sebuah gambar dengan perintah *.jj render ${inputParams || '1'}* mutlak!`)

                let templateId = inputParams
                let mediaCount = 1

                // Cek apakah input berupa nomor urut (list)
                if (inputParams.length < 5 && !isNaN(inputParams)) {
                    const templates = await jj.list()
                    const found = templates.find(t => t.index === Number(inputParams))
                    if (!found) return m.reply('❌ Nomor template kaga ada di daftar *.jj list*.')
                    
                    templateId = found.id
                    mediaCount = found.mediaCount || 1
                } else {
                    const templates = await jj.list()
                    const found = templates.find(t => t.id === inputParams)
                    if (found) mediaCount = found.mediaCount || 1
                }

                await m.reply(`⏳ *Memproses template (Butuh ${mediaCount} klon foto).* \nBot sedang mengkompresi aset lu...`)
                
                // Sedot gambar pake engine Baileys mutlak
                const stream = await downloadContentFromMessage(imageMessage, 'image')
                let buffer = Buffer.from([])
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])

                // Kompres gambar biar kaga ngeberatin server
                try { buffer = await compressImageBuffer(buffer) } catch (err) { console.log('Skip kompresi gambar') }

                // Duplikat gambar sesuai kebutuhan template
                let imagesToRender = Array(mediaCount).fill(buffer)

                // Render ke server CapCut
                const result = await jj.render(templateId, imagesToRender, { interval: 5000, maxRetries: 100 })

                await m.reply(`✅ *Render Selesai!* Sedang memadatkan video sebelum dikirim...`)

                // Sedot hasil video dan kompres mutlak
                let videoBuffer
                try {
                    const vidRes = await axios.get(result.videoUrl, { responseType: 'arraybuffer' })
                    videoBuffer = Buffer.from(vidRes.data)
                    videoBuffer = await compressVideoBuffer(videoBuffer)
                } catch (err) {
                    console.log('Kompres video meledak, pake url asli')
                    videoBuffer = { url: result.videoUrl } 
                }

                // Tembak pake m.reply format video atau sock.send bawaan Zapo
                const sendPayload = Buffer.isBuffer(videoBuffer) 
                    ? { video: videoBuffer, caption: `✅ *Render & Kompresi Berhasil!*\n🆔 ID Template: ${templateId}` }
                    : { video: videoBuffer, caption: `✅ *Render Berhasil (Tanpa Kompresi)!*\n🆔 ID Template: ${templateId}` }

                return await sock.message.send(m.chat, sendPayload, { quoted: m })
            }

            // FALLBACK KALAU PERINTAHNYA NGACO
            return m.reply(
                `🛠️ *JJ CAPCUT MENU*\n\n` +
                `*.jj list* ➔ Lihat daftar template\n` +
                `*.jj search <nama>* ➔ Cari template\n` +
                `*.jj render <nomor/id>* ➔ (Sambil reply foto) Render video mutlak`
            )

        } catch (error) {
            return m.reply(`❌ *JJ Capcut Error:*\n${error.message}`)
        }
    }
}