import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'piano',
  alias: ['pianika'],
  category: 'fun',
  description: 'Bermain piano virtual interaktif dengan synthesizer.',
  typing: true,

  async execute(m, { sock }) {
    try {
      const rich = new AIRich(sock)
      
      // 1. Kirim pesan loading
      rich.addText('loading...', { id: 'loading_piano' })
      await rich.send(m.chat)
      
      await delay(1200)

      // 2. Kode HTML Neon Piano
      const htmlCode = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
  * { 
    box-sizing: border-box; 
    -webkit-tap-highlight-color: transparent; 
    user-select: none; 
    -webkit-user-select: none; 
    -webkit-touch-callout: none;
  }
  body, html { 
    margin: 0; 
    padding: 0; 
    width: 100%; 
    min-height: 100%; 
    background: transparent; 
    color: #fff; 
    font-family: Arial, sans-serif; 
    overflow: hidden; 
    touch-action: none; /* Mencegah layar kegeser pas main piano */
  }
  .wrap { 
    width: 100%; 
    max-width: 620px; 
    margin: auto; 
    padding: 10px; 
  }
  .card { 
    position: relative; 
    overflow: hidden; 
    border-radius: 20px; 
    background: linear-gradient(180deg, #171525 0%, #0b0a12 100%); 
    border: 1px solid rgba(255,255,255,0.1); 
    box-shadow: 0 15px 40px rgba(0,0,0,0.6); 
    padding: 20px 10px;
    text-align: center;
  }
  .glow { 
    position: absolute; 
    width: 200px; 
    height: 150px; 
    left: 50%; 
    top: 0; 
    transform: translateX(-50%); 
    background: rgba(105, 87, 229, 0.3); 
    filter: blur(60px); 
    pointer-events: none; 
  }
  .title { 
    font-size: 22px; 
    font-weight: 900; 
    letter-spacing: 2px;
    color: #fff;
    text-shadow: 0 0 10px rgba(105,87,229,0.8);
    margin-bottom: 5px;
    position: relative;
    z-index: 2;
  }
  .sub { 
    font-size: 10px; 
    color: #8a8798; 
    letter-spacing: 1px;
    margin-bottom: 20px;
    position: relative;
    z-index: 2;
  }
  
  /* PIANO LAYOUT */
  .piano-board {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    position: relative;
    z-index: 5;
    background: #000;
    padding: 10px 5px;
    border-radius: 12px;
    border: 3px solid #222;
    box-shadow: 0 10px 20px rgba(0,0,0,0.8);
  }
  .key {
    cursor: pointer;
    flex-shrink: 0;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    padding-bottom: 15px;
    font-size: 10px;
    font-weight: bold;
    color: #888;
    transition: background 0.1s;
  }
  
  /* White Keys */
  .white {
    width: 12vw;
    max-width: 42px;
    height: 180px;
    background: linear-gradient(180deg, #fff 0%, #e0e0e0 100%);
    border: 1px solid #ccc;
    border-radius: 0 0 6px 6px;
    box-shadow: 0 4px 5px rgba(0,0,0,0.3);
    z-index: 1;
  }
  .white.active {
    background: #d4d4d4;
    box-shadow: inset 0 4px 8px rgba(0,0,0,0.3);
    color: #555;
  }
  
  /* Black Keys (overlapping with negative margin) */
  .black {
    width: 8vw;
    max-width: 26px;
    height: 110px;
    background: linear-gradient(180deg, #333 0%, #000 100%);
    margin: 0 -4vw;
    z-index: 2;
    border-radius: 0 0 4px 4px;
    border: 1px solid #111;
    box-shadow: inset 0 -2px 3px rgba(255,255,255,0.2), 0 3px 5px rgba(0,0,0,0.6);
    color: #444;
    padding-bottom: 10px;
  }
  @media (min-width: 350px) {
    .black { margin: 0 -13px; }
  }
  .black.active {
    background: #1a1a1a;
    box-shadow: inset 0 3px 6px rgba(0,0,0,0.7);
    color: #888;
  }
  
  /* Info Screen */
  .screen {
    margin-top: 20px;
    height: 45px;
    background: rgba(0,0,0,0.4);
    border: 1px solid rgba(103,230,165,0.2);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    font-weight: bold;
    color: #8ef2bc;
    letter-spacing: 2px;
    position: relative;
    z-index: 2;
    box-shadow: inset 0 0 10px rgba(0,0,0,0.5);
  }
</style>
</head>
<body>

<div class="wrap">
  <div class="card">
    <div class="glow"></div>
    <div class="title">NEON PIANO</div>
    <div class="sub">VIRTUAL SYNTHESIZER</div>
    
    <div class="piano-board">
      <!-- 1 Octave (C4 to C5) -->
      <div class="key white" data-freq="261.63" data-note="C4">C</div>
      <div class="key black" data-freq="277.18" data-note="C#4"></div>
      <div class="key white" data-freq="293.66" data-note="D4">D</div>
      <div class="key black" data-freq="311.13" data-note="D#4"></div>
      <div class="key white" data-freq="329.63" data-note="E4">E</div>
      <div class="key white" data-freq="349.23" data-note="F4">F</div>
      <div class="key black" data-freq="369.99" data-note="F#4"></div>
      <div class="key white" data-freq="392.00" data-note="G4">G</div>
      <div class="key black" data-freq="415.30" data-note="G#4"></div>
      <div class="key white" data-freq="440.00" data-note="A4">A</div>
      <div class="key black" data-freq="466.16" data-note="A#4"></div>
      <div class="key white" data-freq="493.88" data-note="B4">B</div>
      <div class="key white" data-freq="523.25" data-note="C5">C</div>
    </div>
    
    <div class="screen" id="display">READY</div>
  </div>
</div>

<script>
  let actx = null;

  function initAudio() {
    if (!actx) {
      actx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (actx.state === 'suspended') {
      actx.resume();
    }
  }

  function playSynth(freq) {
    if (!actx) return;
    const now = actx.currentTime;
    
    // Osc 1 (Triangle - Body of sound)
    const osc1 = actx.createOscillator();
    const gain1 = actx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(freq, now);
    
    // Osc 2 (Sine - Harmonics / Overtone)
    const osc2 = actx.createOscillator();
    const gain2 = actx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(freq * 2, now);
    
    osc1.connect(gain1);
    osc2.connect(gain2);
    gain1.connect(actx.destination);
    gain2.connect(actx.destination);
    
    // Envelope 1
    gain1.gain.setValueAtTime(0, now);
    gain1.gain.linearRampToValueAtTime(0.6, now + 0.02);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
    
    // Envelope 2
    gain2.gain.setValueAtTime(0, now);
    gain2.gain.linearRampToValueAtTime(0.2, now + 0.02);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    
    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 1.3);
    osc2.stop(now + 0.6);
  }

  const keys = document.querySelectorAll('.key');
  const display = document.getElementById('display');

  keys.forEach(key => {
    // WAJIB: Pake pointerdown biar jalan di sandbox WA
    key.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      initAudio();
      
      const freq = parseFloat(key.getAttribute('data-freq'));
      const note = key.getAttribute('data-note');
      
      playSynth(freq);
      
      // Animasi UI
      key.classList.add('active');
      display.textContent = "NOTE: " + note;
      display.style.color = "#fff";
      display.style.textShadow = "0 0 10px #6957e5";
    });

    const releaseKey = (e) => {
      e.preventDefault();
      key.classList.remove('active');
      display.style.color = "#8ef2bc";
      display.style.textShadow = "none";
    };

    key.addEventListener('pointerup', releaseKey);
    key.addEventListener('pointerleave', releaseKey);
    key.addEventListener('pointercancel', releaseKey);
  });
</script>

</body>
</html>`

      // 3. Render payload lewat backdoor _addContent punya AIRich
      const customHtmlSection = AIRich.newLayout('Single', {
        __typename: "GenAIaeacdsnwHtmlPrimitive",
        payload: htmlCode,
        trusted_sources: ["cylic.dev"]
      })

      const customSubmessage = {
        messageType: 2,
        messageText: "NEON PIANO SYNTH"
      }

      rich._addContent(customHtmlSection, customSubmessage, { replace: 'loading_piano', id: 'piano_ready' })

      // 4. Update gelembung pesannya
      await rich.sendEdit()

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Gagal memuat Piano:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}