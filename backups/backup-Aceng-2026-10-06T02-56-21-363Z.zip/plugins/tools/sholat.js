import axios from 'axios'
import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'sholat',
  alias: ['jadwalsholat', 'jadwalsolat'],
  category: 'tools',
  description: 'Melihat jadwal sholat harian dengan tampilan tabel interaktif.',
  help: '[nama kota]',
  typing: true,

  async execute(m, { sock, args }) {
    try {
      const query = args.join(' ').trim() || 'jakarta'
      
      const rich = new AIRich(sock)
      rich.addText('🕌 Mencari data wilayah & jadwal sholat...', { id: 'status' })
      await rich.send(m.chat, { additionalAttributes: { type: "text" } })

      const cityRes = await axios.get(`https://api.myquran.com/v1/sholat/cities/s/${encodeURIComponent(query)}`)
      const cityData = cityRes.data?.data

      if (!cityData || !cityData.length) {
        rich.addText(`❌ Kota *${query}* tidak ditemukan.`, { replace: 'status' })
        return await rich.sendEdit()
      }

      const cityId = cityData[0].id
      const cityName = cityData[0].lokasi

      const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Jakarta' })
      const scheduleRes = await axios.get(`https://api.myquran.com/v1/sholat/jadwal/${cityId}/${today}`)
      const jadwal = scheduleRes.data?.data?.jadwal

      if (!jadwal) {
        rich.addText('❌ Gagal mengambil jadwal sholat.', { replace: 'status' })
        return await rich.sendEdit()
      }

      await delay(800)

      const tableContent = `📍 *WILDAYAH:* ${cityName.toUpperCase()}
📅 *TANGGAL:* ${jadwal.tanggal}

┌──────────────────┬──────────┐
│ *WAKTU SHOLAT*   │ *JAM*    │
├──────────────────┼──────────┤
│ 🌅 Imsak         │ ${jadwal.imsak}   │
│ 🌄 Subuh         │ ${jadwal.subuh}   │
│ 🏙️ Terbit        │ ${jadwal.terbit}  │
│ ☀️ Dhuha         │ ${jadwal.dhuha}   │
│ 🕛 Dzuhur        │ ${jadwal.dzuhur}  │
│  عصر Ashar        │ ${jadwal.ashar}   │
│ 🌇 Maghrib       │ ${jadwal.maghrib} │
│ 🌙 Isya          │ ${jadwal.isya}    │
└──────────────────┴──────────┘`

      rich.addText(tableContent, { replace: 'status' })
      rich.setFooter('© NIXCODE · Islamic Schedule')
      await rich.sendEdit()

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Gagal memuat jadwal sholat:\n${err.message || err}`
      }, { additionalAttributes: { type: "text" } })
    }
  }
}