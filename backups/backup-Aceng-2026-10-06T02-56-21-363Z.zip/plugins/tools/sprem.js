import { downloadContentFromMessage } from 'baileys'

function buildStickerExif(metadata) {
  const json = Buffer.from(JSON.stringify(metadata), "utf-8")
  const exif = Buffer.concat([
    Buffer.from([0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]),
    Buffer.alloc(4),
    Buffer.from([0x16, 0x00, 0x00, 0x00]),
    json,
  ])
  exif.writeUInt32LE(json.length, 14)
  return exif
}

function makeChunk(type, data) {
  const typeBuffer = Buffer.from(type)
  const sizeBuffer = Buffer.alloc(4)
  sizeBuffer.writeUInt32LE(data.length, 0)
  const padding = data.length % 2 === 1 ? Buffer.from([0x00]) : Buffer.alloc(0)
  return Buffer.concat([typeBuffer, sizeBuffer, data, padding])
}

function setWebpExif(webpBuffer, metadata) {
  if (webpBuffer.slice(0, 4).toString() !== "RIFF" || webpBuffer.slice(8, 12).toString() !== "WEBP") {
    throw new Error("File bukan WEBP valid.")
  }
  const chunks = []
  let offset = 12
  while (offset + 8 <= webpBuffer.length) {
    const type = webpBuffer.slice(offset, offset + 4).toString()
    const size = webpBuffer.readUInt32LE(offset + 4)
    const chunkStart = offset
    const chunkEnd = offset + 8 + size + (size % 2)
    if (chunkEnd > webpBuffer.length) break
    if (type !== "EXIF") {
      chunks.push(webpBuffer.slice(chunkStart, chunkEnd))
    }
    offset = chunkEnd
  }
  const exifPayload = buildStickerExif(metadata)
  const exifChunk = makeChunk("EXIF", exifPayload)
  const body = Buffer.concat([...chunks, exifChunk])
  const header = Buffer.alloc(12)
  header.write("RIFF", 0)
  header.writeUInt32LE(body.length + 4, 4)
  header.write("WEBP", 8)
  return Buffer.concat([header, body])
}

export default {
  command: 'sprem',
  alias: ['stickerprem', 'spremium', 'premiumsticker'],
  category: 'tools',
  description: 'Menginjeksi metadata AI/Avatar Premium ke sticker biasa.',
  help: '(reply sticker)',
  typing: true,

  async execute(m, { sock }) {
    if (!m.quoted || m.quoted.type !== 'stickerMessage') {
      return m.reply('❌ Reply pesan sticker WEBP biasa yang mau diinjeksi.')
    }

    try {
      const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
      const stickerMessage = rawQuoted?.stickerMessage

      if (!stickerMessage) {
        return m.reply('❌ Gagal mendapatkan data mentah (stickerMessage) dari pesan lu.')
      }

      if (stickerMessage.mimetype !== 'image/webp') {
        return m.reply('❌ Sticker ini bukan WEBP biasa (kemungkinan sticker Lottie/animasi khusus).')
      }

      const stream = await downloadContentFromMessage(stickerMessage, 'sticker')
      const chunks = []
      for await (const chunk of stream) {
        chunks.push(chunk)
      }
      const stickerBuffer = Buffer.concat(chunks)

      const metadata = {
        "sticker-pack-id": "2be7e369-b5ce-4706-a3d4-f78805a20328",
        "sticker-pack-name": "OMAK",
        "sticker-pack-publisher": "HAI",
        "accessibility-text": "MR ALOC",
        "android-app-store-link": "https://whatsapp.com",
        "ios-app-store-link": "https://whatsapp.com/ios",
        emojis: ["🦸", "😴", "😌"],
        "is-from-sticker-maker": 0,
        "is-avatar-sticker": 1,
        "avatar-sticker-template-id": "whatsapp",
        "is-ai-sticker": 1,
        "is-avatar-country-sticker": 1,
        "is-avatar-instant-sticker": 1,
        "sticker-maker-source-type": 4,
        "is-avatar-social-sticker": 1,
        "avatar-sticker-style": "whatsapp",
        "avatar-sticker-revision-id": "2026",
        "is-from-user-created-pack": 1,
        "origin-pack-id": "whatsapp",
        "is-text-sticker": 1,
        "premium": 1,
      }

      const finalStickerBuffer = setWebpExif(stickerBuffer, metadata)

      await sock.message.send(m.chat, {
        type: 'sticker',
        media: finalStickerBuffer,
        mimetype: 'image/webp',
        isAvatar: true,
        isAiSticker: true,
        messageContextInfo: {
          limitSharingV2: {
            sharingLimited: true,
            trigger: "CHAT_SETTING",
            limitSharingSettingTimestamp: Date.now().toString(),
            initiatedByMe: true,
          }
        }
      })

    } catch (err) {
      return m.reply(`❌ Gagal eksekusi:\n${err.message || err}`)
    }
  }
}