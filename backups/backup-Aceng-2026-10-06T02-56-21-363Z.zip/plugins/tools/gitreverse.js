import axios from 'axios'

const BASE_URL = "https://www.gitreverse.com"
const ENDPOINT = BASE_URL + "/api/reverse-website"
const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36"

function createSlug(targetUrl) {
  try {
    const { hostname } = new URL(targetUrl)
    return hostname
      .replace(/^www\./i, "")
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .toLowerCase()
  } catch {
    throw new Error("URL target tidak valid. Pastikan menyertakan http:// atau https://")
  }
}

function reverseWebsite(targetUrl) {
  return new Promise(async (resolve, reject) => {
    try {
      const siteSlug = createSlug(targetUrl)
      console.log("[GitReverse] Target :", targetUrl)
      console.log("[GitReverse] Slug :", siteSlug)
      console.log("[GitReverse] Starting...\n")

      const response = await axios.post(
        ENDPOINT,
        { siteSlug, targetUrl, stream: true },
        {
          responseType: "stream",
          timeout: 300000, // Timeout 5 Menit
          headers: {
            "User-Agent": UA,
            "Accept": "*/*",
            "Content-Type": "application/json",
            "Origin": BASE_URL,
            "Referer": BASE_URL + "/website/" + siteSlug + "?url=" + encodeURIComponent(targetUrl),
            "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
          },
          validateStatus: () => true
        }
      )

      if (response.status >= 400) {
        let body = ""
        for await (const chunk of response.data) {
          body += chunk.toString("utf8")
        }
        return reject(new Error(`HTTP ${response.status}: ${body || response.statusText}`))
      }

      let buffer = ""
      let currentEvent = null
      let finalResult = null

      function processLine(line) {
        line = line.replace(/\r$/, "")
        if (!line.trim()) {
          currentEvent = null
          return
        }
        if (line.startsWith("event:")) {
          currentEvent = line.slice(6).trim()
          return
        }
        if (!line.startsWith("data:")) {
          return
        }
        
        const rawData = line.slice(5).trim()
        if (!rawData) return
        
        let data
        try {
          data = JSON.parse(rawData)
        } catch {
          data = rawData
        }
        
        if (currentEvent === "status") {
          const message = typeof data === "object" ? data.message : data
          console.log("[GitReverse] " + (message || "Processing..."))
          return
        }
        
        if (currentEvent === "done") {
          finalResult = data
          return
        }
        
        if (currentEvent === "error") {
          const message = typeof data === "object" ? data.message || JSON.stringify(data) : data
          reject(new Error(message))
        }
      }

      response.data.on("data", chunk => {
        buffer += chunk.toString("utf8")
        const lines = buffer.split("\n")
        buffer = lines.pop()
        for (const line of lines) {
          processLine(line)
        }
      })

      response.data.on("end", () => {
        if (buffer) {
          processLine(buffer)
        }
        if (!finalResult) {
          return reject(new Error("Stream selesai tetapi event 'done' tidak ditemukan dari server"))
        }
        
        resolve({
          status: true,
          data: {
            targetUrl,
            siteSlug,
            prompt: finalResult.prompt || null,
            designPath: finalResult.designPath || null,
            designUrl: finalResult.designPath ? BASE_URL + finalResult.designPath : null,
            fromCache: finalResult.fromCache ?? null
          }
        })
      })

      response.data.on("error", reject)

    } catch (e) {
      reject(e)
    }
  })
}

export default {
  command: 'gitreverse',
  alias: ['reverseweb', 'cloneui'],
  category: 'tools',
  typing: true,
  description: 'Reverse engineering UI website menjadi prompt/design menggunakan GitReverse.',
  help: '<url_target>',
  wait: true,

  async execute(m, { args }) {
    const targetUrl = args[0]
    
    if (!targetUrl) {
      return m.reply('❌ Masukkan URL target!\n\nContoh:\n`.gitreverse https://example.com`')
    }
    try {
      const result = await reverseWebsite(targetUrl)
      const resData = result.data
      const caption = `*GITREVERSE*\n\n` +
                      `* *Target:* ${resData.targetUrl}\n` +
                      `* *Slug:* ${resData.siteSlug}\n` +
                      `* *Ambil dari Cache:* ${resData.fromCache ? 'Ya' : 'Tidak'}\n\n` +
                      `* *Design URL:*\n${resData.designUrl || 'Tidak ada URL'}\n\n` +
                      `* *Prompt Result:*\n${resData.prompt || 'Tidak ada prompt'}`

      return m.reply(caption)
    } catch (err) {
      console.error('[GITREVERSE ERROR]', err)
      return m.reply(`❌ *Gagal memproses URL:*\n${err.message || err}`)
    }
  }
}