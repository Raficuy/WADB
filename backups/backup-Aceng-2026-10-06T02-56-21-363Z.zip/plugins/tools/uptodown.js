import { gotScraping } from 'got-scraping'
import * as cheerio from 'cheerio'

function cleanText(text) {
    if (!text) return ''
    return text.replace(/\s+/g, ' ').trim()
}

export default {
    command: 'uptodown',
    alias: ['upto'],
    category: 'tools',
    description: 'Scraper & Downloader APK khusus dari Uptodown mutlak.',
    help: '<nama aplikasi/game>',
    typing: true,
    wait: true,

    async execute(m, { args, sock }) {
        const query = args.join(' ').trim()
        
        if (!query) {
            return m.reply('❌ Kasih nama aplikasi atau gamenya cuy!\n\n*Contoh:* .uptodown whatsapp')
        }


        try {
            const BASE_URL = 'https://id.uptodown.com/android'
            const searchUrl = `${BASE_URL}/search?query=${encodeURIComponent(query)}`
            
            const searchRes = await gotScraping({ url: searchUrl, timeout: { request: 15000 } })
            const $search = cheerio.load(searchRes.body)

            const firstItem = $search('.item').first()
            if (firstItem.length === 0) {
                return m.reply(`❌ Kaga nemu aplikasi *${query}* di Uptodown. Coba kata kunci lain.`)
            }

            const targetUrl = firstItem.find('a').attr('href')
            if (!targetUrl) throw new Error('Gagal ngekstrak link Uptodown')

            const detailRes = await gotScraping({ url: targetUrl, timeout: { request: 15000 } })
            const $dl = cheerio.load(detailRes.body)

            const title = cleanText($dl('h1').first().text()) || query.toUpperCase()
            const developer = cleanText($dl('#author-link, .author').first().text()) || 'Developer Unknown'
            
            let fileSize = 'Unknown Size'
            $dl('#technical-information tr').each((_, el) => {
                const rowText = cleanText($dl(el).text())
                if (rowText.includes('Ukuran')) {
                    fileSize = cleanText($dl(el).find('td').last().text())
                }
            })

            
            const directUrl = targetUrl.endsWith('/') ? `${targetUrl}dw` : `${targetUrl}/dw`

            let caption = `*UPTODOWN DOWNLOADER*\n`
            caption += `* *Nama:* ${title}\n`
            caption += `* *Dev:* ${developer}\n`
            caption += `* *Ukuran:* ${fileSize}\n`
            caption += `_Pencet tombol di bawah buat langsung download filenya!_`

            const payload = {
                interactiveMessage: {
                    header: { 
                        title: "✅ APK Ditemukan",
                        hasMediaAttachment: false
                    },
                    body: { text: caption },
                    footer: { text: "uptodwon" },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "⬇️ Download Sekarang",
                                    url: directUrl
                                })
                            }
                        ]
                    }
                }
            }

            const extraOpts = {
                additionalNodes: [
                    {
                        tag: "biz",
                        attrs: {},
                        content: [
                            {
                                tag: "interactive",
                                attrs: { type: "native_flow", v: "1" },
                                content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                            }
                        ]
                    }
                ]
            }

            return await sock.message.send(m.chat, payload, extraOpts)

        } catch (err) {
            return m.reply(`❌ *Uptodown Scraper Error:*\n${err.message || err}`)
        }
    }
}