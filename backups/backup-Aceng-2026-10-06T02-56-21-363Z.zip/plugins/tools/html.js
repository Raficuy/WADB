import crypto from 'crypto'

export default {
  command: 'render',
  alias: ['html', 'runhtml'],
  category: 'tools',
  description: 'Merender kode HTML/CSS/JS langsung di dalam chat WA.',
  help: '<kirim/reply kode HTML>',
  typing: true,

  async execute(m, { sock, args }) {
    try {
      let inputCode = m.quoted?.text || args.join(' ')

      if (!inputCode) {
        return sock.message.send(m.chat, {
          text: '❌ Kirim atau reply kode HTML/CSS/JS yang mau di-render.'
        }, {
          additionalAttributes: { type: "text" }
        })
      }

      let htmlCode = ""
      const fullHtml = inputCode.match(/(?:<!DOCTYPE html>\s*)?<html[\s\S]*<\/html>/i)
      const inBackticks = inputCode.match(/`([\s\S]*?(?:<style|<div|<script|<canvas)[\s\S]*?)`/i)
      const rawBlocks = inputCode.match(/(<(?:style|div|script|canvas|svg)[\s\S]*<\/(?:style|div|script|canvas|svg)>)/i)

      if (fullHtml) {
        htmlCode = fullHtml[0]
      } else if (inBackticks) {
        htmlCode = inBackticks[1]
      } else if (rawBlocks) {
        htmlCode = rawBlocks[0]
      } else {
        return sock.message.send(m.chat, {
          text: '❌ Kaga nemu tag HTML/CSS/JS yang valid di pesan lu.'
        }, {
          additionalAttributes: { type: "text" }
        })
      }

      if (!/<html/i.test(htmlCode)) {
        htmlCode = `<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">\n</head>\n<body style="margin:0;padding:0;background:transparent;">\n${htmlCode}\n</body>\n</html>`
      }

      const payloadJson = {
        response_id: crypto.randomUUID(),
        sections: [
          {
            view_model: {
              primitive: {
                __typename: "GenAIaeacdsnwHtmlPrimitive",
                payload: htmlCode,
                trusted_sources: ["nixel.dev"]
              },
              __typename: "GenAISingleLayoutViewModel"
            }
          }
        ]
      }

      const unifiedResponseData = Buffer.from(JSON.stringify(payloadJson)).toString('base64')

      await sock.message.send(m.chat, {
        botForwardedMessage: {
          message: {
            richResponseMessage: {
              messageType: 1,
              submessages: [
                {
                  messageType: 2,
                  messageText: "View Code"
                }
              ],
              unifiedResponse: {
                data: unifiedResponseData
              },
              contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedAiBotMessageInfo: {
                  botJid: "867051314767696@bot"
                },
                forwardOrigin: 4
              }
            }
          }
        }
      }, {
        additionalAttributes: { type: "text" }
      })

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Gagal merender HTML:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}