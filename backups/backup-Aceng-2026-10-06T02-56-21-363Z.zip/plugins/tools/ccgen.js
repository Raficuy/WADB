import { exec } from 'child_process'
import path from 'path'
import { existsSync } from 'fs'

const CC_SCRIPT_PATH = path.join(process.cwd(), 'capcut-generator', 'main.js')

const runCapcutCLI = (cmdArgs) => {
    return new Promise((resolve, reject) => {
        exec(`node "${CC_SCRIPT_PATH}" ${cmdArgs}`, (error, stdout, stderr) => {
            try {
                const jsonMatch = stdout.match(/\{[\s\S]*\}/)
                if (jsonMatch) {
                    resolve(JSON.parse(jsonMatch[0]))
                } else {
                    resolve({ status: 'error', raw: stdout || stderr })
                }
            } catch (e) {
                resolve({ status: 'error', raw: stdout || stderr, error: e.message })
            }
        })
    })
}

async function sendResultWithCopyButtons(sock, m, textBody, copyItems) {
    const buttons = copyItems.map((item, index) => ({
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
            display_text: item.label,
            id: `copy_${index}`,
            copy_code: item.textToCopy
        })
    }))

    const payload = {
        interactiveMessage: {
            header: { title: "CAPCUT GENERATOR" },
            body: { text: textBody },
            footer: { text: "Capcut Pro" },
            nativeFlowMessage: { buttons: buttons }
         
        }
    }

    const extraOpts = {
        additionalNodes: [
            {
                tag: "biz",
                attrs: {},
                content: [
                    {
                        tag: "interactive",
                        attrs: { type: "native_flow", v: "1" },
                        content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                    }
                ]
            }
        ]
    }

    try {
        await sock.message.send(m.chat, payload, extraOpts)
    } catch (err) {
        console.error("[TOMBOL ERROR]", err)

        await m.reply(`${textBody}\n\n_UI Tombol gagal dimuat, silakan copy manual._`)
    }
}

export default {
    command: 'ccgen',
    alias: ['capcutpro', 'ccpro', 'cctrial'],
    category: 'tools',
    description: 'CapCut Auto Generator (Bypass Pro 7 Hari & Akun).',
    help: 'create | trial | check <cookie>',
    typing: true,
    wait: true,
    onlyOwner: true,

    async execute(m, { args, sock }) {
        if (!existsSync(CC_SCRIPT_PATH)) {
            return m.reply('❌ *Script Induk Kaga Nemu!*\n\nPastikan lu udah ngekstrak folder `capcut-generator` di panel.')
        }

        const action = args[0]?.toLowerCase()

        if (!action || !['create', 'trial', 'check'].includes(action)) {
            return m.reply(
                `🔥 *CAPCUT GENERATOR*\n\n` +
                `*Command Tersedia:*\n` +
                `*.ccgen create* ➔ Bikin akun baru otomatis\n` +
                `*.ccgen trial* ➔ Bikin akun + klaim Pro 7 Hari\n` +
                `*.ccgen check <cookie>* ➔ Cek info akun & exp Pro`
            )
        }

        try {
 
            if (action === 'create') {
               
                const result = await runCapcutCLI('--create-account')

                if (result.status === 'success' || result.account) {
                    const acc = result.account || result
                    const storage = acc.storage || {}
                    const ref = acc.referral || {}
                    const cookieStr = acc.cookieString || result.cookie || 'Gagal ekstrak teks cookie'

                    let text = `*AKUN CAPCUT BERHASIL DIBUAT*\n`
                    text += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`
                    text += `*Username:* ${acc.screenName || '-'}\n`
                    text += `*Email:* ${acc.email || 'Disposable'}\n`
                    text += `*Password:* ${acc.password || '-'}\n`
                    text += `*User ID:* ${acc.userId || '-'}\n`
                    text += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`
                    text += ` *Storage:* ${storage.usageFormatted || '0 GB'} / ${storage.quotaFormatted || '5 GB'}\n`
                    text += ` *Pro Status:* ${acc.isPro ? '✅ AKTIF' : '❌ FREE'}\n`
                    text += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`
                    text += ` *Referral Link:* ${ref.referralLink || '-'}\n`
                    text += ` *Space Invite:* ${ref.spaceInviteLink || '-'}\n`
                    
                    
                    const buttons = [
                        { label: '📋 Salin Cookie', textToCopy: cookieStr },
                        { label: '📋 Salin Email', textToCopy: acc.email || '' },
                        { label: '📋 Salin Password', textToCopy: acc.password || '' }
                    ]

                    return await sendResultWithCopyButtons(sock, m, text, buttons)
                } else {
                    return m.reply(`❌ *Gagal Bikin Akun:*\n${result.raw || JSON.stringify(result)}`)
                }
            }

            if (action === 'trial') {
                const result = await runCapcutCLI('--get-trial')

                if (result.status === 'success' || result.account || result.profile) {
                    const acc = result.account || result.profile || result
                    const pro = acc.pro || {}
                    const cookieStr = acc.cookieString || result.cookie || 'Gagal ekstrak teks cookie'

                    let text = `*CAPCUT PRO 7 HARI!*\n`
                   
                    text += `👤 *Username:* ${acc.screenName || '-'}\n`
                    text += `📧 *Email:* ${acc.email || '-'}\n`
                    text += `🔑 *Password:* ${acc.password || '-'}\n`
                    text += `⏳ *Expired:* ${pro.expireTimeFormatted || '7 Hari dari sekarang'}\n`
                  
                    
                    const buttons = [
                        { label: '📋 Salin Cookie', textToCopy: cookieStr },
                        { label: '📋 Salin Email', textToCopy: acc.email || '' },
                        { label: '📋 Salin Password', textToCopy: acc.password || '' }
                    ]

                    return await sendResultWithCopyButtons(sock, m, text, buttons)
                } else {
                    return m.reply(`❌ *Exploit Trial Gagal:*\n${result.raw || JSON.stringify(result)}`)
                }
            }

            if (action === 'check') {
                const cookie = args.slice(1).join(' ').trim()
                if (!cookie) return m.reply('❌ Masukin cookie-nya cuy!\n\n*Contoh:* .ccgen check sessionid=xxx; sessionid_ss=xxx;')

                const result = await runCapcutCLI(`--check "${cookie}"`)

                if (result.status === 'success' && result.profile) {
                    const p = result.profile
                    let text = `*CAPCUT ACCOUNT INFO*\n`
                   
                    text += `*Username:* ${p.screenName}\n`
                    text += `*Email:* ${p.email}\n`
                    text += `*Status Pro:* ${p.isPro ? '✅ AKTIF' : '❌ KAGA PRO'}\n`
                    
                    if (p.isPro && p.pro) {
                        text += `*Expired:* ${p.pro.expireTimeFormatted}\n`
                    }
                    
                    text += `*Storage:* ${p.storage?.usageFormatted} / ${p.storage?.quotaFormatted}\n`
                    text += `*Role:* ${p.role}\n`
                    return m.reply(text)
                } else {
                    return m.reply(`❌ *Cookie Invalid / Error:*\n${result.raw || JSON.stringify(result)}`)
                }
            }

        } catch (err) {
            return m.reply(`❌ *CLI Exec Error:*\n${err.message || err}`)
        }
    }
}