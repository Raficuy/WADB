import { getRawMessageById } from '../../db/rawMessage.js'

export default {
  command: 'togif',
  alias: ['gif', 'videotogif'],
  category: 'tools',
  typing: true,
  description: 'Ubah video jadi GIF looping instan (Clone Payload).',
  help: '(reply video)',

  async execute(m, { sock }) {
    if (!m.quoted) {
      return sock.message.send(m.chat, { 
        text: '❌ Reply video yang mau dijadiin GIF.' 
      }, { additionalAttributes: { type: "text" } })
    }

    try {
      const quotedId = m.quoted?.id || m.quoted?.key?.id || m.raw?.message?.extendedTextMessage?.contextInfo?.stanzaId
      const stored = quotedId ? getRawMessageById(quotedId) : null
      
      let rawMessage = stored?.raw?.message 
        || m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage 
        || m.quoted?.message 
        || m.quoted?.full 

      if (rawMessage?.message) {
        rawMessage = rawMessage.message
      }

      if (!rawMessage || !rawMessage.videoMessage) {
        return sock.message.send(m.chat, { 
          text: '❌ Ini bukan video! Pastikan kamu reply pesan video.' 
        }, { additionalAttributes: { type: "text" } })
      }

      const msgKey = Object.keys(rawMessage)[0]
      
      rawMessage[msgKey].gifPlayback = true

      if (rawMessage[msgKey].caption) {
        delete rawMessage[msgKey].caption
      }

      if (rawMessage[msgKey].contextInfo) {
        delete rawMessage[msgKey].contextInfo.stanzaId
        delete rawMessage[msgKey].contextInfo.participant
        delete rawMessage[msgKey].contextInfo.quotedMessage
      }

      await sock.message.send(
        m.chat, 
        rawMessage, 
        { 
          additionalAttributes: { type: "text" } 
        }
      )

    } catch (err) {
      console.error('[TOGIF] Error:', err)
      return sock.message.send(m.chat, { 
        text: `❌ Gagal mengubah video ke GIF:\n${err.message || err}` 
      }, { additionalAttributes: { type: "text" } })
    }
  }
}