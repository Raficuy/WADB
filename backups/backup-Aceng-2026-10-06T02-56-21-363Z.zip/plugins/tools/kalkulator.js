import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'kalkulator',
  alias: ['hitung', 'calc'],
  category: 'tools',
  description: 'Bermain gitar virtual interaktif.',
  typing: true,

  async execute(m, { sock }) {
    try {
      const rich = new AIRich(sock)
      
      rich.addText('Loading...', { id: 'loading_gitar' })
      await rich.send(m.chat)
      
      await delay(1200)

      const htmlCode = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Kalkulator</title>
<style>
    * {
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
    font-family: Arial, sans-serif;
  }
  body {
    margin: 0;
    padding: 12px;
    background: #0d0d1a;
  }
  .calc {
    width: 100%;
    max-width: 280px;
    margin: 0 auto;
    background: #1a1a2e;
    border-radius: 16px;
    padding: 12px;
    box-shadow: 0 0 15px rgba(0,245,255,0.15);
  }
  .screen {
    width: 100%;
    height: 55px;
    background: #000;
    border-radius: 10px;
    padding: 8px;
    margin-bottom: 10px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: flex-end;
  }
  .prev {
    color: #555;
    font-size: 11px;
    height: 14px;
    overflow: hidden;
  }
  .curr {
    color: #00f5ff;
    font-size: 22px;
    font-weight: bold;
    overflow: hidden;
  }
  .buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
  }
  .btn {
    height: 42px;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    background: #2a2a4a;
    color: #fff;
    transition: transform 0.08s;
  }
  .btn:active {
    background: #00f5ff;
    color: #000;
    transform: scale(0.95);
  }
  .operator { background: #ff00aa; }
  .operator:active { background: #ff00ff; }
  .equal { 
    background: #00ff88; 
    grid-column: span 2;
  }
  .equal:active { background: #00ffaa; }
  .clear { background: #ff4444; }
  .clear:active { background: #ff6666; }
</style>
</head>

<body>
  <div class="calc">
    <div class="screen">
      <div class="prev" id="prev"></div>
      <div class="curr" id="curr">0</div>
    </div>
    <div class="buttons">
      <button class="btn clear" data-action="clear">C</button>
      <button class="btn" data-action="delete">⌫</button>
      <button class="btn operator" data-op="/">÷</button>
      <button class="btn operator" data-op="*">×</button>
      
      <button class="btn" data-num="7">7</button>
      <button class="btn" data-num="8">8</button>
      <button class="btn" data-num="9">9</button>
      <button class="btn operator" data-op="-">-</button>
      
      <button class="btn" data-num="4">4</button>
      <button class="btn" data-num="5">5</button>
      <button class="btn" data-num="6">6</button>
      <button class="btn operator" data-op="+">+</button>
      
      <button class="btn" data-num="1">1</button>
      <button class="btn" data-num="2">2</button>
      <button class="btn" data-num="3">3</button>
      <button class="btn equal" data-action="equals">=</button>
      
      <button class="btn" data-num="0" style="grid-column: span 2;">0</button>
      <button class="btn" data-num=".">.</button>
    </div>
  </div>

<script>
  let current = '0';
  let previous = '';
  let operation = null;
  let resetNext = false;

  const currEl = document.getElementById('curr');
  const prevEl = document.getElementById('prev');

  function updateScreen() {
    currEl.textContent = current;
    prevEl.textContent = previous + (operation ? ' ' + operation : '');
  }

  function inputNumber(num) {
    if (resetNext) { current = ''; resetNext = false; }
    if (num === '.' && current.indexOf('.') !== -1) return;
    if (current === '0' && num !== '.') current = '';
    current = current + num;
  }

  function inputOperation(op) {
    if (operation !== null) calculate();
    previous = current;
    operation = op;
    resetNext = true;
  }

  function calculate() {
    if (operation === null || resetNext) return;
    const prev = parseFloat(previous);
    const curr = parseFloat(current);
    if (isNaN(prev) || isNaN(curr)) return;
    
    let result;
    if (operation === '+') result = prev + curr;
    else if (operation === '-') result = prev - curr;
    else if (operation === '*') result = prev * curr;
    else if (operation === '/') result = curr === 0 ? 'Error' : prev / curr;
    
    current = result.toString();
    operation = null;
    previous = '';
    resetNext = true;
  }

  function clearAll() {
    current = '0';
    previous = '';
    operation = null;
  }

  function deleteNum() {
    current = current.length === 1 ? '0' : current.slice(0, -1);
  }

  document.querySelectorAll('.btn').forEach(function(btn) {
    btn.addEventListener('pointerdown', function() {
      if (btn.getAttribute('data-num')) inputNumber(btn.getAttribute('data-num'));
      if (btn.getAttribute('data-op')) inputOperation(btn.getAttribute('data-op'));
      if (btn.getAttribute('data-action') === 'clear') clearAll();
      if (btn.getAttribute('data-action') === 'delete') deleteNum();
      if (btn.dataset.action === 'equals') calculate();
      updateScreen();
    });
  });
</script>
</body>
</html>`

      const customHtmlSection = AIRich.newLayout('Single', {
        __typename: "GenAIaeacdsnwHtmlPrimitive",
        payload: htmlCode,
        trusted_sources: ["nixel.dev"]
      })

      const customSubmessage = {
        messageType: 2,
        messageText: "Guitar"
      }

      rich._addContent(customHtmlSection, customSubmessage, { replace: 'loading_gitar', id: 'gitar_ready' })

      await rich.sendEdit()

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Gagal:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}