import { downloadContentFromMessage } from 'baileys'
import sharp from 'sharp'

export default {
    command: 'toimg',
    alias: ['toimage', 'stikertoimg'],
    category: 'tools',
    description: 'Convert stiker menjadi gambar mutlak tanpa FFmpeg.',
    help: 'Reply stiker dengan perintah .toimg',
    typing: true,
    wait: true,

    async execute(m, { sock }) {
        const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
        const stickerMessage = rawQuoted?.stickerMessage || m.quoted?.message?.stickerMessage || m.quoted?.stickerMessage

        if (!stickerMessage) {
            return m.reply('❌ Reply stikernya cuy!\n\n*Contoh:* Reply stiker pake .toimg')
        }

        try {
            // 1. Sedot Buffer Stiker (.webp) langsung ke RAM
            const stream = await downloadContentFromMessage(stickerMessage, 'sticker')
            let webpBuffer = Buffer.from([])
            for await (const chunk of stream) webpBuffer = Buffer.concat([webpBuffer, chunk])

            // 2. Convert mutlak pake Sharp (Bypass semua error FFmpeg)
            const pngBuffer = await sharp(webpBuffer)
                .toFormat('png')
                .toBuffer()

            // 3. Tembak ke grup pake format media Zapo
            await m.reply({
                type: 'image',
                media: pngBuffer,
                mimetype: 'image/png',
                caption: `✅ *Sukses Convert Stiker*`
            })

        } catch (err) {
            return m.reply(`❌ *Gagal Convert:*\n${err.message || err}\n\n_Pastikan lu udah ngetik 'npm install sharp' di terminal._`)
        }
    }
}