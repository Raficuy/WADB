import { createCanvas, GlobalFonts } from '@napi-rs/canvas'
import { writeFileSync, mkdtempSync, rmSync, readFileSync, existsSync } from 'fs'
import path from 'path'
import os from 'os'
import { exec } from 'child_process'
import { promisify } from 'util'
import { Sticker } from 'wa-sticker-formatter'
import { config } from '../../settings.js'

const execAsync = promisify(exec)

// Lokasi Font Kustom
const FONT_URL = 'https://cdn.jsdelivr.net/gh/Napoleon-Fibonacci/assets@main/font/impact.ttf'
const FONT_PATH = path.join(process.cwd(), 'impact.ttf')

// Fungsi pantulan (Bouncing)
function easeOutBack(x) {
  const c1 = 1.70158
  const c3 = c1 + 1
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2)
}

export default {
  command: 'brat2',
  alias: ['bratvid2'],
  category: 'tools',
  description: 'Membuat stiker Brat animasi mental-mentul (Custom Font + Anti-Crash).',
  help: '<teks> atau (reply pesan)',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const textArgs = args.join(' ').trim()
    const text = textArgs || m.quoted?.text || ''

    if (!text) {
      return m.reply("❌ Masukkan teksnya cuy!\n*Contoh:* .bratvid Info mabar")
    }


    let tmpDir
    try {
      // 1. Sedot dan Daftarin Font Mutlak
      if (!existsSync(FONT_PATH)) {
        const res = await fetch(FONT_URL)
        if (!res.ok) throw new Error("Gagal download font dari GitHub")
        const buf = Buffer.from(await res.arrayBuffer())
        writeFileSync(FONT_PATH, buf)
      }
      GlobalFonts.registerFromPath(FONT_PATH, 'Impact')

      // 2. Persiapan Kanvas & Teks (Ukuran 512x512 standar stiker WA)
      const size = 512
      const margin = 40
      const maxWidth = size - (margin * 2)
      
      const canvas = createCanvas(size, size)
      const ctx = canvas.getContext('2d')
      
      let fontSize = 100
      let lines = []
      let lineHeight = 0

      // Logika Word Wrap & Auto Font Size pake Font Impact
      while (fontSize > 15) {
        ctx.font = `${fontSize}px Impact`
        lineHeight = fontSize * 1.1
        lines = []
        let currentLine = ''
        let words = text.split(' ')
        let fits = true

        for (const word of words) {
          const testLine = currentLine ? `${currentLine} ${word}` : word
          if (ctx.measureText(testLine).width > maxWidth) {
            if (currentLine) {
              lines.push(currentLine)
              currentLine = word
              if (ctx.measureText(word).width > maxWidth) { fits = false; break }
            } else { fits = false; break }
          } else {
            currentLine = testLine
          }
        }
        if (currentLine) lines.push(currentLine)
        
        if (fits && (lines.length * lineHeight) <= (size - margin * 2)) break
        fontSize -= 5
      }

      // 3. Ekstrak Posisi Tiap Kata buat Animasi
      const wordsData = []
      const startY = (size - (lines.length * lineHeight)) / 2
      
      lines.forEach((line, lineIndex) => {
        let currentX = margin
        const words = line.split(' ')
        words.forEach(word => {
          wordsData.push({
            text: word,
            x: currentX,
            y: startY + (lineIndex * lineHeight),
            width: ctx.measureText(word).width
          })
          currentX += ctx.measureText(word).width + ctx.measureText(' ').width
        })
      })

      // 4. Setup Direktori Temp & Frame Logika
      tmpDir = mkdtempSync(path.join(os.tmpdir(), 'brat-'))
      const totalWords = wordsData.length
      const fps = 30 // FPS aman kaga bikin OOM
      const delayPerWord = 3 // Jarak antar kata (frame)
      const bounceDuration = 12 // Durasi animasi per kata (frame)
      const holdFrames = 30 // Durasi diam di akhir (1 detik)
      
      const totalFrames = (totalWords * delayPerWord) + bounceDuration + holdFrames

      // 5. Render Frame (Berurutan biar RAM aman)
      for (let f = 0; f < totalFrames; f++) {
        ctx.fillStyle = '#ffffff' // Tema Brat (Putih)
        ctx.fillRect(0, 0, size, size)
        
        ctx.textBaseline = 'top'
        ctx.textAlign = 'left'
        ctx.fillStyle = '#000000'
        ctx.font = `${fontSize}px Impact`

        for (let i = 0; i < totalWords; i++) {
          const w = wordsData[i]
          const startFrame = i * delayPerWord
          const currentFrame = f - startFrame

          if (currentFrame < 0) continue // Belum waktunya muncul

          let scale = 1
          let alpha = 1

          if (currentFrame < bounceDuration) {
            const progress = currentFrame / bounceDuration
            scale = 0.3 + (0.7 * easeOutBack(progress))
            alpha = Math.min(1, progress * 2)
          }

          const centerX = w.x + (w.width / 2)
          const centerY = w.y + (fontSize / 2)

          ctx.save()
          ctx.globalAlpha = Math.max(0, Math.min(1, alpha))
          
          if (scale !== 1) {
            ctx.translate(centerX, centerY)
            ctx.scale(scale, scale)
            ctx.translate(-centerX, -centerY)
          }
          
          ctx.fillText(w.text, w.x, w.y)
          ctx.restore()
        }

        const buffer = await canvas.encode('png')
        const frameName = `frame-${String(f + 1).padStart(4, '0')}.png`
        writeFileSync(path.join(tmpDir, frameName), buffer)
      }

      // 6. Jahit Frame jadi Video pake FFMPEG
      const videoPath = path.join(tmpDir, 'output.mp4')
      const ffmpegCmd = `ffmpeg -y -framerate ${fps} -i "${path.join(tmpDir, 'frame-%04d.png')}" -c:v libx264 -preset ultrafast -pix_fmt yuv420p "${videoPath}"`
      
      await execAsync(ffmpegCmd)

      // 7. Convert MP4 ke Stiker
      const videoBuffer = readFileSync(videoPath)
      
      const sticker = new Sticker(videoBuffer, {
        pack: m.pushName || "User",
        author: `Generated By ${config?.botName || 'Zapo Bot'}`,
        type: "full",
        quality: 50 // Quality 50 biar sizenya kaga meledak di WA
      })

      const stickerBuffer = await sticker.toBuffer()

      // 8. Kirim Mutlak ke WA
      await m.reply({
        type: 'sticker',
        media: stickerBuffer,
        mimetype: 'image/webp'
      })

    } catch (e) {
      if (e.message && e.message.includes('ffmpeg')) {
        return m.reply("❌ *Error:* FFMPEG belum di-install di panel/VPS lu. Lu harus install ffmpeg dulu biar bisa bikin stiker video.")
      }
      return m.reply("❌ *Gagal merender animasi:*\n" + (e.message || e))
    } finally {
      // 9. Bersihin Sampah Mutlak
      if (tmpDir) {
        try {
          rmSync(tmpDir, { recursive: true, force: true })
        } catch (err) {
          console.error("Gagal hapus temp:", err)
        }
      }
    }
  }
}