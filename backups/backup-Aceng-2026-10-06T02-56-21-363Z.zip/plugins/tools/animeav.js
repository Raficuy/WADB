const BASE_URL = 'https://animeav1.com'
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8'
}

async function fetchPage(path) {
  const url = path.startsWith('http') ? path : `${BASE_URL}${path.startsWith('/') ? '' : '/'}${path}`
  const res = await fetch(url, { headers: HEADERS })
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return await res.text()
}

function extractSvelteData(html) {
  const regex = /data:\s*\[[\s\S]*?form:\s*null/
  const match = html.match(regex)
  if (!match) throw new Error('Data payload tidak ditemukan')
  const raw = match[0].replace(/^data:\s*/, '').replace(/,\s*form:\s*null$/, '')
  const evaluated = eval('(' + raw + ')')
  for (let i = evaluated.length - 1; i >= 0; i--) {
    if (evaluated[i] && evaluated[i].data && Object.keys(evaluated[i].data).length > 0) {
      return evaluated[i].data
    }
  }
  return null
}

function cleanInput(input) {
  let cleaned = input.trim().replace(/^https?:\/\/[^\/]+/i, '').replace(/^\/media\//i, '').replace(/^\/+|\/+$/g, '')
  const parts = cleaned.split(/[\/\s]+/)
  return { slug: parts[0] || '', ep: parts[1] || '' }
}

export default {
  command: 'anime',
  alias: ['av1', 'animeav'],
  category: 'tools',
  description: 'Scraper AnimeAV1',
  help: '<search|detail|ep> <query/slug>',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    try {
      const action = args[0]?.toLowerCase()
      const query = args.slice(1).join(' ').trim()

      if (!action || !['search', 'detail', 'ep'].includes(action)) {
        return m.reply('Format: .animeav1 <perintah> <query>\n\nPerintah:\n- search <judul>\n- detail <slug>\n- ep <slug> <episode>')
      }

      if (action === 'search') {
        if (!query) return m.reply('Masukkan judul anime.')
        
        const html = await fetchPage(`/catalogo?search=${encodeURIComponent(query)}`)
        const data = extractSvelteData(html)
        const results = data?.results || []
        
        if (results.length === 0) return m.reply('Anime tidak ditemukan.')

        let text = 'Hasil Pencarian AnimeAV1:\n\n'
        results.slice(0, 10).forEach((item, i) => {
          text += `${i + 1}. ${item.title}\n`
          text += `Slug: ${item.slug}\n\n`
        })

        return m.reply(text.trim())
      }

      if (action === 'detail') {
        if (!query) return m.reply('Masukkan slug anime.')
        
        const { slug } = cleanInput(query)
        if (!slug) return m.reply('Slug tidak valid.')

        const html = await fetchPage(`/media/${slug}`)
        const data = extractSvelteData(html)
        const media = data?.media
        
        if (!media) return m.reply('Detail anime tidak ditemukan.')

        let text = `Detail Anime:\n\n`
        text += `Judul: ${media.title || '-'}\n`
        text += `Tipe: ${media.type || '-'}\n`
        text += `Status: ${media.status || '-'}\n`
        text += `Tahun: ${media.year || '-'}\n\n`
        text += `Sinopsis:\n${media.overview ? media.overview.slice(0, 300) : '-'}\n\n`
        
        const eps = media.episodes || []
        text += `Total Episode: ${eps.length}`

        return m.reply(text.trim())
      }

      if (action === 'ep') {
        if (!query) return m.reply('Masukkan slug dan nomor episode. Contoh: .animeav1 ep naruto 1')
        
        const { slug, ep } = cleanInput(query)
        if (!slug || !ep) return m.reply('Format salah. Pastikan menyertakan slug dan episode.')

        const html = await fetchPage(`/media/${slug}/${ep}`)
        const data = extractSvelteData(html)
        
        if (!data) return m.reply('Data episode tidak ditemukan.')

        let text = `Link Episode ${ep}:\n`
        
        const embeds = data.embeds || {}
        if (Object.keys(embeds).length > 0) {
          text += `\nStreaming:\n`
          for (const lang in embeds) {
            text += `\n[${lang}]\n`
            if (Array.isArray(embeds[lang])) {
              embeds[lang].forEach(item => {
                const name = item.server || item.name || item.provider || 'Server'
                const url = item.url || item.link || item.iframe || ''
                if (url) text += `- ${name}: ${url}\n`
              })
            }
          }
        }
        
        const downloads = data.downloads || {}
        if (Object.keys(downloads).length > 0) {
          text += `\nDownload:\n`
          for (const lang in downloads) {
            text += `\n[${lang}]\n`
            if (Array.isArray(downloads[lang])) {
              downloads[lang].forEach(item => {
                const name = item.server || item.name || item.provider || item.resolution || 'Link'
                const url = item.url || item.link || ''
                if (url) text += `- ${name}: ${url}\n`
              })
            }
          }
        }

        if (Object.keys(embeds).length === 0 && Object.keys(downloads).length === 0) {
          text += 'Tidak ada link yang tersedia.'
        }

        return m.reply(text.trim())
      }

    } catch (err) {
      return m.reply(`Error:\n${err.message || err}`)
    }
  }
}