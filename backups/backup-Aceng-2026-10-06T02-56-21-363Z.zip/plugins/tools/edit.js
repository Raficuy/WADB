import axios from 'axios'
import FormData from 'form-data'
import { SocksProxyAgent } from 'socks-proxy-agent'
import { downloadContentFromMessage } from 'baileys'

const PROXY_API = 'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=protocolipport&format=text&protocol=socks5&timeout=5000'
const BANANA_API = 'https://ibbo.ai/api/nano-banana-lite-image-to-image'

// Simpen proxy di memori
let cachedProxies = []

async function fetchProxies() {
    if (cachedProxies.length > 0) return cachedProxies
    
    try {
        const res = await axios.get(PROXY_API, { timeout: 10000 })
        const lines = res.data.split('\n').map(l => l.trim()).filter(Boolean)
        
        cachedProxies = lines.map(l => {
            const m = l.match(/([\d.]+):(\d+)/)
            return m ? `socks5://${m[1]}:${m[2]}` : null
        }).filter(Boolean)
        
        return cachedProxies
    } catch (err) {
        return [] 
    }
}

export default {
    command: 'editimg',
    alias: ['aiimage', 'nanobanana', 'editgambar'],
    category: 'ai',
    description: 'Edit gambar pakai AI NanoBanana (Auto Bypass Limit mutlak).',
    help: 'Reply gambar + <prompt>',
    typing: true,
    wait: true,

    async execute(m, { args }) {
        const prompt = args.join(' ').trim()
        
        const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
        const imageMessage = rawQuoted?.imageMessage || m.quoted?.message?.imageMessage || m.quoted?.imageMessage || m.message?.imageMessage

        if (!prompt || !imageMessage) {
            return m.reply('❌ Reply gambarnya dan kasih prompt cuy!\n\n*Contoh:* .editimg kasih kacamata hitam')
        }

        await m.reply('⏳ *AI sedang melukis gambar lu, tunggu bentar mutlak...*')

        try {
            // 1. Sedot gambar fisik dari pesan WhatsApp ke RAM
            const stream = await downloadContentFromMessage(imageMessage, 'image')
            let imageBuffer = Buffer.from([])
            for await (const chunk of stream) imageBuffer = Buffer.concat([imageBuffer, chunk])

            // 2. Susun form data
            const form = new FormData()
            form.append('file', imageBuffer, { filename: 'image.jpg', contentType: 'image/jpeg' })
            form.append('prompt', prompt)
            form.append('output_format', 'jpg')
            form.append('generator_slug', 'ai-image-editor')

            const HEADERS = {
                'Accept': '*/*',
                'Origin': 'https://banana-nano.ai',
                'Referer': 'https://banana-nano.ai/ai-image-editor',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
                ...form.getHeaders()
            }

            const proxies = await fetchProxies()
            let resultData = null
            let usedProxy = 'Direct (Tanpa Proxy)'

            // 3. Eksekusi pakai Proxy SOCKS5
            if (proxies.length > 0) {
                for (let i = 0; i < 3; i++) {
                    const proxyUrl = proxies[Math.floor(Math.random() * proxies.length)]
                    try {
                        const agent = new SocksProxyAgent(proxyUrl)
                        const res = await axios.post(BANANA_API, form, {
                            headers: HEADERS,
                            httpAgent: agent,
                            httpsAgent: agent,
                            timeout: 45000
                        })
                        
                        if (res.data?.success) {
                            resultData = res.data
                            usedProxy = proxyUrl
                            break
                        }
                    } catch (e) {
                        continue
                    }
                }
            }

            // 4. Fallback IP Direct
            if (!resultData) {
                try {
                    const res = await axios.post(BANANA_API, form, { 
                        headers: HEADERS, 
                        timeout: 45000 
                    })
                    if (res.data?.success) resultData = res.data
                } catch (e) {
                    throw new Error(e.response?.data?.message || 'Server AI menolak koneksi mutlak.')
                }
            }

            if (!resultData || !resultData.success) {
                throw new Error('Gagal nge-generate gambar dari AI.')
            }

            // 5. Unduh hasil foto dari URL AI jadi Buffer fisik
            const imageUrl = resultData.data.image_url
            const imgRes = await axios.get(imageUrl, { responseType: 'arraybuffer' })
            const finalBuffer = Buffer.from(imgRes.data)

            let caption = `🎨 *NANO BANANA AI*\n`
            caption += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`
            caption += `🗣️ *Prompt:* ${prompt}\n`
            caption += `🌐 *Proxy:* ${usedProxy}\n`
            caption += `⚙️ *Model:* ${resultData.data.model}\n`
            caption += `━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━\n`

            // 6. Tembak pake format media Zapo Mutlak biar kaga meledak contextInfo-nya
            return m.reply({
                type: 'image',
                media: finalBuffer,
                mimetype: 'image/jpeg',
                caption: caption
            })

        } catch (err) {
            return m.reply(`❌ *Edit Image Error:*\n${err.message || err}`)
        }
    }
}