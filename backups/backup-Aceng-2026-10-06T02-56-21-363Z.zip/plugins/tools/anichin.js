import https from 'https'

const BASE_URL = 'https://anichin.cafe'
const defaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Referer': 'https://anichin.cafe/'
}

function fetchHtml(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: defaultHeaders }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let redirectUrl = res.headers.location
        if (!redirectUrl.startsWith('http')) {
          redirectUrl = new URL(redirectUrl, url).href
        }
        return resolve(fetchHtml(redirectUrl))
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`Failed ${url}: HTTP ${res.statusCode}`))
      }
      let data = ''
      res.on('data', chunk => data += chunk)
      res.on('end', () => resolve(data))
    }).on('error', reject)
  })
}

function cleanText(text) {
  if (!text) return ''
  return text
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&#8217;/g, "'")
    .replace(/&#8211;/g, "-")
    .replace(/&#038;/g, "&")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, ' ')
    .trim()
}

function parseSeriesList(html) {
  const series = []
  const regex = /<article[^>]*class="[^"]*bs[^"]*"[^>]*>([\s\S]*?)<\/article>/gi
  let match
  while ((match = regex.exec(html)) !== null) {
    const block = match[1]
    const linkMatch = block.match(/<a\s+href="([^"]+)"[^>]*title="([^"]*)"/i) || block.match(/<a\s+href="([^"]+)"/i)
    const titleMatch = block.match(/<div class="tt">([\s\S]*?)<\/div>/i) || block.match(/<h2[^>]*class="entry-title"[^>]*>([\s\S]*?)<\/h2>/i)
    const epMatch = block.match(/<span\s+class="epx">([\s\S]*?)<\/span>/i)
    if (linkMatch) {
      const url = linkMatch[1]
      const title = titleMatch ? cleanText(titleMatch[1]) : (linkMatch[2] ? cleanText(linkMatch[2]) : '')
      series.push({
        title,
        slug: url.replace(BASE_URL, '').replace(/^\/seri\//, '').replace(/^\//, '').replace(/\/$/, ''),
        latestEpisode: epMatch ? cleanText(epMatch[1]) : null
      })
    }
  }
  return series
}

function parseSeriesDetail(html, url) {
  const titleMatch = html.match(/<h1[^>]*class="entry-title"[^>]*>([\s\S]*?)<\/h1>/i)
  const synMatch = html.match(/<div[^>]*class="synp"[^>]*>([\s\S]*?)<\/div>/i) || html.match(/<div[^>]*class="entry-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i)
  let rating = null
  const ratingWidthMatch = html.match(/<div class="rtb"><span style="width:([0-9.]+)%"><\/span><\/div>/i)
  if (ratingWidthMatch) {
    rating = (parseFloat(ratingWidthMatch[1]) / 10).toFixed(1)
  } else {
    const ratingTextMatch = html.match(/<div[^>]*class="rating"[^>]*>[\s\S]*?([0-9.]+)/i)
    if (ratingTextMatch) rating = ratingTextMatch[1]
  }
  const episodes = []
  const epRegex = /<li[^>]*data-index="[^"]*"[^>]*>[\s\S]*?<a href="([^"]+)"[^>]*>[\s\S]*?<div class="epl-num">([^<]+)<\/div>[\s\S]*?<div class="epl-title">([^<]+)<\/div>[\s\S]*?<div class="epl-date">([^<]+)<\/div>/gi
  let epMatch
  while ((epMatch = epRegex.exec(html)) !== null) {
    const epUrl = epMatch[1]
    episodes.push({
      episodeNumber: cleanText(epMatch[2]),
      title: cleanText(epMatch[3]),
      slug: epUrl.replace(BASE_URL, '').replace(/^\//, '').replace(/\/$/, '')
    })
  }
  return {
    title: titleMatch ? cleanText(titleMatch[1]) : '',
    rating: rating ? `${rating} / 10` : null,
    synopsis: synMatch ? cleanText(synMatch[1]) : '',
    totalEpisodes: episodes.length,
    episodes
  }
}

function parseEpisodeDetail(html) {
  const titleMatch = html.match(/<h1[^>]*class="entry-title"[^>]*>([\s\S]*?)<\/h1>/i)
  const defaultEmbedMatch = html.match(/<div class="player-embed"[^>]*>[\s\S]*?<iframe[^>]*src="([^"]+)"/i)
  const defaultEmbed = defaultEmbedMatch ? defaultEmbedMatch[1] : null
  const streamingServers = []
  const serverOptions = [...html.matchAll(/<option[^>]*value=["']([^"']*)["'][^>]*data-index=["']?([^"'>]*)["']?[^>]*>([\s\S]*?)<\/option>/gi)]
  
  for (const opt of serverOptions) {
    const base64Value = opt[1]
    const serverName = cleanText(opt[3])
    let streamUrl = null
    if (base64Value) {
      try {
        const decoded = Buffer.from(base64Value, 'base64').toString('utf-8')
        const srcMatch = decoded.match(/src=["']([^"']+)["']/i)
        if (srcMatch) streamUrl = srcMatch[1]
      } catch (err) {}
    }
    streamingServers.push({ serverName, streamUrl: streamUrl || defaultEmbed })
  }

  const downloads = []
  const dlBlocks = [...html.matchAll(/<div[^>]*class="soraurlx"[^>]*>([\s\S]*?)<\/div>/gi)]
  dlBlocks.forEach(block => {
    const qMatch = block[1].match(/<strong>([\s\S]*?)<\/strong>/i)
    const links = [...block[1].matchAll(/<a\s+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)].map(l => ({ provider: cleanText(l[2]), link: l[1] }))
    if (links.length > 0) {
      downloads.push({ resolution: qMatch ? cleanText(qMatch[1]) : 'Direct', links })
    }
  })

  return {
    episodeTitle: titleMatch ? cleanText(titleMatch[1]) : 'Episode',
    streamingServers,
    downloads
  }
}

export default {
  command: 'anichin',
  alias: ['ani', 'donghua'],
  category: 'tools',
  description: 'Scraper Donghua Anichin',
  help: '<search|ongoing|detail|ep> <query/slug>',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    try {
      const action = args[0]?.toLowerCase()
      const query = args.slice(1).join(' ').trim()

      if (!action || !['search', 'ongoing', 'detail', 'ep'].includes(action)) {
        return m.reply('Format: .anichin <perintah> <query>\n\nPerintah tersedia:\n- search <judul>\n- ongoing\n- detail <slug_seri>\n- ep <slug_episode>')
      }

      if (action === 'search') {
        if (!query) {
          return m.reply('Masukkan judul anime/donghua.')
        }
        
        const html = await fetchHtml(`${BASE_URL}/?s=${encodeURIComponent(query)}`)
        const list = parseSeriesList(html)
        
        if (list.length === 0) {
          return m.reply('Data tidak ditemukan.')
        }

        let text = `Hasil Pencarian:\n\n`
        list.slice(0, 10).forEach((item, i) => {
          text += `${i + 1}. ${item.title}\n`
          text += `Slug: ${item.slug}\n`
          if (item.latestEpisode) text += `Ep Terbaru: ${item.latestEpisode}\n`
          text += `\n`
        })

        return m.reply(text.trim())
      }

      if (action === 'ongoing') {
        const html = await fetchHtml(`${BASE_URL}/ongoing/`)
        const list = parseSeriesList(html)
        
        let text = `Donghua Ongoing:\n\n`
        list.slice(0, 10).forEach((item, i) => {
          text += `${i + 1}. ${item.title}\n`
          text += `Slug: ${item.slug}\n`
          if (item.latestEpisode) text += `Ep Terbaru: ${item.latestEpisode}\n`
          text += `\n`
        })

        return m.reply(text.trim())
      }

      if (action === 'detail') {
        if (!query) {
          return m.reply('Masukkan slug seri.')
        }
        
        let targetUrl = `${BASE_URL}/seri/${query.replace(/^\/seri\/|^\/|\/$/g, '')}/`
        const html = await fetchHtml(targetUrl)
        const detail = parseSeriesDetail(html, targetUrl)
        
        let text = `Detail Seri:\n\n`
        text += `Judul: ${detail.title}\n`
        if (detail.rating) text += `Rating: ${detail.rating}\n`
        text += `Total Episode: ${detail.totalEpisodes}\n\n`
        text += `Sinopsis:\n${detail.synopsis.slice(0, 300)}...\n\n`
        text += `Daftar Episode (5 Terbaru):\n`
        
        detail.episodes.slice(0, 5).forEach(ep => {
          text += `- ${ep.episodeNumber}: ${ep.slug}\n`
        })

        return m.reply(text.trim())
      }

      if (action === 'ep') {
        if (!query) {
          return m.reply('Masukkan slug episode.')
        }

        let targetUrl = `${BASE_URL}/${query.replace(/^\/seri\/|^\/|\/$/g, '')}/`
        const html = await fetchHtml(targetUrl)
        const epData = parseEpisodeDetail(html)
        
        let text = `Episode Detail:\n\n`
        text += `Judul: ${epData.episodeTitle}\n\n`
        text += `Streaming Link:\n`
        epData.streamingServers.slice(0, 3).forEach(s => {
          if (s.streamUrl) text += `- ${s.serverName}: ${s.streamUrl}\n`
        })
        
        text += `\nDownload Link:\n`
        epData.downloads.forEach(d => {
          text += `[${d.resolution}]\n`
          d.links.forEach(l => {
            text += `- ${l.provider}: ${l.link}\n`
          })
        })

        return m.reply(text.trim())
      }

    } catch (err) {
      return m.reply(`Error:\n${err.message || err}`)
    }
  }
}