async function getBld(hero) {
  const sb = 'https://bfnagdegsgqrrhlurlpc.supabase.co/rest/v1'
  const k = 'sb_publishable_YSny9E2TJNUVcxTP_B0YOw_K40Uo8A1'
  const hdr = {
    'Content-Type': 'application/json',
    apikey: k,
    Authorization: 'Bearer ' + k,
    Referer: 'https://molebuild.com/builds',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36'
  }

  const req = async (u, o = {}) => {
    const r = await fetch(u, { headers: hdr, ...o })
    const t = await r.text()
    if (!r.ok) throw new Error(r.status + ' ' + u + '\n' + t)
    return t ? JSON.parse(t) : null
  }

  // 1. Cari Hero
  const t1 = await req(sb + '/rpc/get_relevant_builds', {
    method: 'POST',
    body: JSON.stringify({ p_hero_id: null, p_search: hero, p_limit: 20, p_offset: 0 })
  })

  if (!t1 || t1.length === 0) return null

  // 2. Ambil ID Build
  const idBld = t1.map(x => x.build_id)
  const prmBld = 'id,title,user_id,hero_id,items,likes_count,created_at,is_public,is_verified,patch_id,retribution_types,emblem_id,selected_emblem_attributes,patches(id,version,name,is_active),heroes(id,name,roles,image_url),emblems(id,name,image_url),battle_spells(id,name,image_url)'
  const bld = await req(sb + '/builds?select=' + encodeURIComponent(prmBld) + '&id=in.(' + idBld.join(',') + ')')

  if (!bld || bld.length === 0) return null

  // 3. Ambil Detail (Item, User, Patch)
  const idItm = [...new Set(bld.flatMap(b => b.items || []))]
  const idUsr = [...new Set(bld.map(b => b.user_id).filter(Boolean))]
  const idPtc = [...new Set(bld.map(b => b.patch_id).filter(Boolean))]

  const [itm, prf, ...emb] = await Promise.all([
    idItm.length ? req(sb + '/items?select=id,image_url,name,stats,price&id=in.(' + idItm.join(',') + ')') : [],
    idUsr.length ? req(sb + '/profiles?select=user_id,username,is_verified,mpl&user_id=in.(' + idUsr.join(',') + ')') : [],
    ...idPtc.map(id => req(sb + '/emblem_versions?select=' + encodeURIComponent('*,emblems:emblem_id(id,name,image_url,attributes)') + '&patch_id=eq.' + id))
  ])

  const mapItm = Object.fromEntries(itm.map(i => [i.id, i]))
  const mapUsr = Object.fromEntries(prf.map(p => [p.user_id, p]))

  return {
    hero: bld[0]?.heroes || null,
    builds: bld.map(b => ({
      title: b.title,
      username: mapUsr[b.user_id]?.username || 'Unknown Player',
      likes_count: b.likes_count,
      emblem: b.emblems ? b.emblems.name : null,
      battle_spell: b.battle_spells ? b.battle_spells.name : null,
      items: (b.items || []).map(id => mapItm[id]).filter(Boolean)
    }))
  }
}

export default {
  command: 'mlbuild',
  alias: ['buildml', 'itemml', 'setml'],
  category: 'tools',
  description: 'Cari rekomendasi build item hero Mobile Legends.',
  typing: true,
  wait: true,

  async execute(m, { args, sock }) {
    const heroName = args.join(' ')
    if (!heroName) {
      return m.reply('❌ Masukin nama heronya bos!\nContoh: `.mlbuild fanny` atau `.mlbuild lancelot`')
    }

      const data = await getBld(heroName)

      if (!data || !data.hero) {
        return m.reply(`❌ Build untuk hero *${heroName}* kaga ketemu. Coba cek ejaan namanya.`)
      }

      let text = `⚔️ *BUILD MLBB: ${data.hero.name.toUpperCase()}* ⚔️\n`
      text += `* *Role:* ${data.hero.roles ? data.hero.roles.join(', ') : '-'}\n\n`

      // Urutkan berdasarkan like terbanyak dan ambil 2 teratas
      const topBuilds = data.builds
        .sort((a, b) => b.likes_count - a.likes_count)
        .slice(0, 2)

      topBuilds.forEach((b, i) => {
        text += `*${i + 1}. ${b.title || 'Rekomendasi Build'}*\n`
        text += `* *Oleh:* ${b.username} (❤️ ${b.likes_count} Likes)\n`
        text += `* *Emblem:* ${b.emblem || '-'}\n`
        text += `* *Spell:* ${b.battle_spell || '-'}\n`
        text += `* *Items:*\n`
        
        if (b.items.length > 0) {
          b.items.forEach(item => {
            text += `   - ${item.name}\n`
          })
        } else {
          text += `   - (Tidak ada item)\n`
        }
        text += `\n`
      })


    
    
    try {
      return await sock.sendThumbnail(m.chat, {
        url: 'https://github.com/',
        title: 'MOBIL LEJEN',
        body: 'Lihat Aja Dibawaj',
        text: `${text.trim()}`,
        thumbnail: 'https://d.tmpfile.link/public/2026-09-27/96928d7b-78b9-420c-b955-da560e02c887/file_1790521570684.jpeg',
        quote: m
      })
    } catch (err) {
      console.error('[shop sendThumbnail]', err)
      return m.reply(text.trim()) 
    }
  }
}