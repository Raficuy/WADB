// plugins/tools/ghupload.js
// Upload file .zip (reply/kirim langsung) ke GitHub sebagai Release asset.
// Butuh env GITHUB_TOKEN & GITHUB_UPLOAD_REPO ("owner/repo") di .env.

import { buildQuoteContext } from '../../lib/utils.js'
import { config } from '../../settings.js'

const GITHUB_API = 'https://api.github.com'

function resolveMediaTarget(m, sock) {
  if (m.quoted?.isMedia) {
    return {
      mime: m.quoted.mime,
      fileName: m.quoted.full?.[m.quoted.type]?.fileName || null,
      download: () => m.quoted.download()
    }
  }
  if (m.isMedia) {
    const raw = m.raw?.message?.[m.type]
    return {
      mime: raw?.mimetype || '',
      fileName: raw?.fileName || null,
      download: () => sock.message.downloadBytes(m.raw.message)
    }
  }
  return null
}

function isZipFile(target) {
  const zipMimes = ['application/zip', 'application/x-zip-compressed', 'application/x-zip']
  if (target.mime && zipMimes.includes(target.mime)) return true
  if (target.fileName && /\.zip$/i.test(target.fileName)) return true
  return false
}

async function ghFetch(url, token, opts = {}) {
  const res = await fetch(url, {
    ...opts,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': config.botName || 'wa-bot',
      ...(opts.headers || {})
    }
  })
  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new Error(`HTTP ${res.status} ${res.statusText}${body ? ` — ${body.slice(0, 300)}` : ''}`)
  }
  return res.json()
}

export default {
  command: 'ghupload',
  alias: ['gh', 'uploadgh', 'ghzip'],
  category: 'tools',
  description: `> Upload file .zip ke GitHub Release repo yang udah disetel di .env (GITHUB_TOKEN & GITHUB_UPLOAD_REPO).

*Keterangan Format:*
> \`.ghupload\` (reply file .zip)
> \`.ghupload\` (kirim file .zip dengan caption command)`,
  help: '(reply/kirim file .zip)',
  onlyOwner: true,
  typing: true,
  wait: true,

  async execute(m, { sock }) {
    const token = process.env.GITHUB_TOKEN
    const repoEnv = process.env.GITHUB_UPLOAD_REPO

    if (!token || !repoEnv) {
      return m.reply(
        '❌ Belum disetel. Tambahin di `.env`:\n\n' +
        '```\nGITHUB_TOKEN=ghp_xxxxxxxxxxxx\nGITHUB_UPLOAD_REPO=username/nama-repo\n```\n\n' +
        '_Token butuh scope `repo` (buat bikin release & upload asset). Buat di: https://github.com/settings/tokens_'
      )
    }

    const [owner, repo] = repoEnv.split('/')
    if (!owner || !repo) {
      return m.reply('❌ Format `GITHUB_UPLOAD_REPO` di .env salah. Harusnya `username/nama-repo`.')
    }

    const target = resolveMediaTarget(m, sock)
    if (!target) return m.reply('❌ Reply file .zip atau kirim file .zip dengan caption `.ghupload`!')
    if (!isZipFile(target)) return m.reply('❌ Cuma nerima file .zip. Cek lagi file yang di-reply.')

    let buffer
    try {
      buffer = await target.download()
    } catch (err) {
      return m.reply(`❌ Gagal download file: ${err?.message || 'file tidak tersedia.'}`)
    }
    if (!buffer?.length) return m.reply('❌ File kosong atau gagal didownload.')

    const sizeMB = (buffer.length / 1024 / 1024).toFixed(2)
    if (buffer.length > 2 * 1024 * 1024 * 1024) {
      return m.reply('❌ File kelewat gede (>2GB), batas maksimal GitHub Release asset.')
    }

    const fileName = target.fileName || `upload-${Date.now()}.zip`
    const tag = `upload-${Date.now()}`

    let release
    try {
      release = await ghFetch(`${GITHUB_API}/repos/${owner}/${repo}/releases`, token, {
        method: 'POST',
        body: JSON.stringify({
          tag_name: tag,
          name: fileName,
          body: `Diupload otomatis lewat .ghupload oleh ${m.pushName || 'owner'} pada ${new Date().toLocaleString('id-ID')}`,
          draft: false,
          prerelease: false
        })
      })
    } catch (err) {
      console.error('[GHUPLOAD] gagal bikin release:', err?.message || err)
      return m.reply(`❌ Gagal bikin release di GitHub: ${err?.message || err}`)
    }

    const uploadUrl = release.upload_url.replace(/\{.*\}$/, '')

    let asset
    try {
      asset = await ghFetch(`${uploadUrl}?name=${encodeURIComponent(fileName)}`, token, {
        method: 'POST',
        headers: { 'Content-Type': 'application/zip' },
        body: buffer
      })
    } catch (err) {
      console.error('[GHUPLOAD] gagal upload asset, cleanup release:', err?.message || err)
      // Bersihin release kosong kalo asset-nya gagal kekirim, biar kaga nyampah di GitHub.
      try {
        await fetch(`${GITHUB_API}/repos/${owner}/${repo}/releases/${release.id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}`, 'User-Agent': config.botName || 'wa-bot' }
        })
      } catch { /* cleanup gagal, bukan masalah besar */ }
      return m.reply(`❌ Gagal upload file ke GitHub: ${err?.message || err}`)
    }

    const caption =
      `*UPLOAD KE GITHUB BERHASIL*\n\n` +
      ` File: ${fileName}\n` +
      ` Ukuran: ${sizeMB} MB\n` +
      ` Repo: ${owner}/${repo}\n` +
      ` Release: ${release.html_url}`

    return m.reply({
      interactiveMessage: {
        header: { title: 'Upload ke GitHub', hasMediaAttachment: false },
        body: { text: caption },
        footer: { text: fileName },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({
                display_text: ' Buka Link Download',
                url: asset.browser_download_url
              })
            },
            {
              name: 'cta_copy',
              buttonParamsJson: JSON.stringify({
                display_text: ' Salin Link Download',
                copy_code: asset.browser_download_url
              })
            }
          ],
          messageVersion: 1
        },
        contextInfo: buildQuoteContext(m)
      }
    })
  }
}