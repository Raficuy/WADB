// plugins/tools/sdm.js


const MAX_SECONDS = 300 
export default {
  command: 'sdm',
  alias: ['selfdestruct', 'vot'],
  category: 'tools',
  description: `> Kirim pesan yang otomatis ke-hapus (delete for everyone/view once) setelah N detik.

*Keterangan Format:*
> \`<detik>\` = 1-${MAX_SECONDS}, lama sebelum pesan dihapus.
> \`<pesan>\` = isi pesannya.

contoh penggunaan:
> \`.sdm 5 pesan ini bakal ilang 5 detik lagi\``,
  help: '<detik> <pesan>',

  async execute(m, { sock, args }) {
    const seconds = Number(args[0])
    const text = args.slice(1).join(' ')

    if (!Number.isFinite(seconds) || seconds < 1 || seconds > MAX_SECONDS) {
      return m.reply(`Detik harus angka 1-${MAX_SECONDS}.\nContoh: .sdm 5 pesan rahasia`)
    }
    if (!text) {
      return m.reply('Kasih isi pesannya.\nContoh: .sdm 5 pesan rahasia')
    }

    let sent
    try {
      sent =
      await sock.message.send(
  m.chat,
  {
    extendedTextMessage: {
      text: `${text}\n\n_pesan ini bakal ilang ${seconds} detik lagi_`,
      previewType: 0,
      contextInfo: {
        expiration: 0,
        ephemeralSettingTimestamp: Date.now(),
        disappearingMode: {
          initiator: 0,
          trigger: 1
        },
        afterReadDuration: seconds //seconds
      },
      inviteLinkGroupTypeV2: 0
    }
  },
  {additionalAttributes: {
    type: "text"
  }}
)
       
        
         
          
           
    } catch (err) {
      return m.reply(`Gagal kirim pesan: ${err?.message || err}`)
    }

    const sentId = sent?.id || sent?.key?.id
    if (!sentId) {
      return 
    }

    setTimeout(async () => {
      try {
        
      } catch (err) {
        console.error('[SDM] Gagal revoke pesan:', err?.message || err)
      }
    }, seconds * 1000)
  }
}