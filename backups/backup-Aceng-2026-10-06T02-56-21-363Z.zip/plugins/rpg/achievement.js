import { checkAchievements, achievementConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'achievement',
  alias: ['pencapaian'],
  category: 'rpg',
  description: 'Liat pencapaian yang udah/belum lu buka.',

  async execute(m) {
    const res = checkAchievements(m.sender)

    let text = `🏆 *PENCAPAIAN LU*\n\n`
    for (const ach of achievementConfig) {
      const unlocked = res.unlocked.includes(ach.id)
      text += `${unlocked ? '✅' : '🔒'} ${ach.name}\n`
    }

    if (res.newlyUnlocked.length > 0) {
      text += `\n🎉 *BARU DIBUKA:* ${res.newlyUnlocked.map(a => a.name).join(', ')}`
    }

    return m.reply(text)
  }
}
