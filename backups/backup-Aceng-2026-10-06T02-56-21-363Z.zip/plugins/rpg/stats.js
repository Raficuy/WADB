// plugins/game/stats.js
import {
  getProfile,
  getLeaderboard,
  getRankLeaderboard,
  getGuildInfo,
  cekHutang,
  checkAchievements,
  getAvailableTitles,
  itemsConfig,
  petConfig,
  mapConfig,
  jobConfig,
  bisnisConfig,
  cropConfig,
  titleConfig,
  achievementConfig,
  fmtTime
} from '../../lib/rpgDatabase.js'
import { createStatCard, fetchAvatar } from '../../lib/statCard.js'

const TARGET_URL = 'https://chat.whatsapp.com'

const rp = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID')

const bar = (cur, max, len = 10) => {
  const ratio = max > 0 ? Math.min(1, Math.max(0, cur / max)) : 0
  const filled = Math.round(ratio * len)
  return '█'.repeat(filled) + '░'.repeat(len - filled)
}

const pct = (a, b) => (b > 0 ? Math.floor((a / b) * 100) : 0)

const getRankTier = (rating) => {
  if (rating < 1000) return 'Bronze 🥉'
  if (rating < 1300) return 'Silver 🥈'
  if (rating < 1600) return 'Gold 🥇'
  if (rating < 2000) return 'Platinum 💠'
  return 'Mythic 🔥'
}

const todayStr = () => new Date().toISOString().slice(0, 10)

const cd = (last, duration) => {
  const left = duration - (Date.now() - (last || 0))
  return left > 0 ? `⏳ ${fmtTime(left)} lagi` : 'Siap ✅'
}

const describeItem = (key) => {
  if (!key) return null
  const it = itemsConfig[key]
  if (!it) return key
  const s = []
  if (it.power != null) s.push(`ATK +${it.power}`)
  if (it.crit != null) s.push(`Crit ${it.crit}%`)
  if (it.defense != null) s.push(`DEF +${it.defense}`)
  if (it.evasion != null) s.push(`Evasi ${it.evasion}%`)
  if (it.tier != null) s.push(`Tier ${it.tier}`)
  return s.length ? `${it.name} (${s.join(', ')})` : it.name
}

const PET_SPECIALTY = { mancing: 'Mancing', combat: 'Tempur', gather: 'Gathering' }

const TYPE_LABEL = {
  weapon: '⚔️ Senjata',
  armor: '🛡️ Armor',
  tool: '🛠️ Alat Kerja',
  potion: '🧪 Potion',
  food: '🍜 Makanan',
  buff: '✨ Buff',
  petfood: '🍖 Makanan Pet',
  material: '🪨 Bahan & Hasil Gathering',
  special: '🎫 Spesial',
  other: '❓ Lainnya'
}

const COOLDOWN = {
  daily: 24 * 60 * 60 * 1000,
  rampok: 60 * 60 * 1000,
  bounty: 3 * 60 * 60 * 1000,
  mancing: 15 * 60 * 1000,
  tambang: 20 * 60 * 1000,
  nebang: 12 * 60 * 1000
}

export default {
  command: 'stat',
  alias: ['me', 'stats', 'profil', 'profile'],
  category: 'rpg',
  description: 'Cek profil RPG lengkap: level, saldo, combat, item, guild, dll.',

  async execute(m, { sock }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
    const num = target.split('@')[0]

    const ach = checkAchievements(target)
    const u = getProfile(target)
    const now = Date.now()

    let name = num
    if (target === m.sender) name = m.pushName || num
    else if (m.quoted?.sender === target) name = m.quoted.pushName || num

    const mentions = [target]
    const L = []

    const title = titleConfig.find(t => t.id === u.activeTitle)
    const job = jobConfig.find(j => j.key === u.job)
    let statusNikah = 'Jomblo 💔'
    if (u.married) {
      statusNikah = `Menikah dengan @${u.married.split('@')[0]} 💍`
      mentions.push(u.married)
    }

    L.push(`📊 *PROFIL RPG LENGKAP*`)
    L.push('')
    L.push(`👤 *IDENTITAS*`)
    L.push(`* *User:* ${name}`)
    L.push(`* *Nomor:* ${num}`)
    L.push(`* *Title:* ${title?.name || u.activeTitle}`)
    L.push(`* *Prestige:* ${u.prestige > 0 ? '⭐'.repeat(Math.min(u.prestige, 10)) + ` (${u.prestige}x)` : 'Belum pernah'}`)
    L.push(`* *Pekerjaan:* ${job?.name || 'Belum punya'}`)
    L.push(`* *Status:* ${statusNikah}`)

    const currentMap = mapConfig[u.currentMap] || mapConfig.kota
    L.push(`* *Lokasi:* ${currentMap.name}`)

    L.push('')
    L.push(`📈 *PROGRESS*`)
    L.push(`* *Level:* ${u.level}`)
    L.push(`* *XP:* ${u.xp.toLocaleString('id-ID')}/${u.xpNeeded.toLocaleString('id-ID')} [${bar(u.xp, u.xpNeeded)}] ${pct(u.xp, u.xpNeeded)}%`)
    L.push(`* *HP:* ${u.hp}/${u.maxHp} [${bar(u.hp, u.maxHp)}]`)

    const board = getLeaderboard(Infinity)
    const posKaya = board.findIndex(x => x.jid === target) + 1

    L.push('')
    L.push(`💰 *KEKAYAAN*`)
    L.push(`* *Saldo:* ${rp(u.balance)}`)
    L.push(`* *Bank:* ${rp(u.bank)}`)
    L.push(`* *Total Aset:* ${rp(u.balance + u.bank)}`)
    if (posKaya > 0) L.push(`* *Peringkat Kekayaan:* #${posKaya} dari ${board.length} pemain`)

    const hutang = cekHutang(target)
    if (hutang.status) {
      L.push(`* *Hutang:* ${rp(hutang.totalHutang)} (pokok ${rp(hutang.hutangAwal)}, ${hutang.hariBerlalu} hari berbunga) ⚠️`)
    } else {
      L.push(`* *Hutang:* Tidak ada ✅`)
    }

    const tier = bisnisConfig[u.bisnisLvl]
    L.push(`* *Bisnis:* ${tier.name} (Lv ${u.bisnisLvl}/${bisnisConfig.length - 1})`)
    if (tier.incomePerJam > 0) {
      const pending = Math.floor(((now - u.lastPanen) / 60000) * (tier.incomePerJam / 60))
      L.push(`* *Income Bisnis:* ${rp(tier.incomePerJam)}/jam | Belum dipanen: ${rp(Math.max(0, pending))}`)
    }
    if (u.bountyPool > 0) L.push(`* *Bounty di Kepala (Buronan):* ${rp(u.bountyPool)} 🎯`)

    const p = u.power
    L.push('')
    L.push(`⚔️ *COMBAT*`)
    L.push(`* *Attack:* ${p.attack}`)
    L.push(`* *Defense:* ${p.defense}`)
    L.push(`* *Crit Chance:* ${p.critChance}%`)
    L.push(`* *Evasi:* ${p.evasion}%`)

    const buffs = []
    if (u.buffs?.attack > 0) buffs.push(`💪 Attack +${u.buffs.attack}`)
    if (u.buffs?.defense > 0) buffs.push(`🛡️ Defense +${u.buffs.defense}`)
    if (u.buffs?.xpMultiplier > 1) buffs.push(`📜 XP x${u.buffs.xpMultiplier}`)
    if (u.buffs?.luckPercent > 0) buffs.push(`🍀 Hoki +${u.buffs.luckPercent}%`)
    L.push(`* *Buff Aktif:* ${buffs.length ? buffs.join(', ') : 'Tidak ada'}`)

    const eq = u.equipped || {}
    L.push('')
    L.push(`🎽 *EQUIPMENT*`)
    L.push(`* *Senjata:* ${describeItem(eq.weapon) || '(kosong)'}`)
    L.push(`* *Armor:* ${describeItem(eq.armor) || '(kosong)'}`)
    L.push(`* *Pancingan:* ${describeItem(eq.rod) || '(kosong)'}`)
    L.push(`* *Beliung:* ${describeItem(eq.pickaxe) || '(kosong)'}`)
    L.push(`* *Kapak:* ${describeItem(eq.axe) || '(kosong)'}`)

    const st = u.stats || {}
    const win = st.totalDuelWin || 0
    const lose = st.totalDuelLose || 0
    const rating = u.rating ?? 1000
    const rankBoard = getRankLeaderboard(Infinity)
    const posRank = rankBoard.findIndex(x => x.jid === target) + 1

    L.push('')
    L.push(`📊 *STATISTIK*`)
    L.push(`* *Duel:* ${win} menang / ${lose} kalah (${win + lose > 0 ? pct(win, win + lose) : 0}% winrate)`)
    L.push(`* *Monster Diburu:* ${st.totalHunt || 0}`)
    L.push(`* *Rampok Sukses:* ${st.totalRampokSukses || 0}`)
    L.push(`* *Ranked:* ${rating} poin - ${getRankTier(rating)}${posRank > 0 ? ` (#${posRank} dari ${rankBoard.length})` : ''}`)

    L.push('')
    L.push(`🐾 *PET*`)
    const pet = u.pet ? petConfig[u.pet] : null
    if (pet) {
      L.push(`* *Pet:* ${pet.name}`)
      L.push(`* *Spesialisasi:* ${PET_SPECIALTY[pet.specialty] || pet.specialty} (bonus +${pet.bonus})`)
      L.push(`* *Info:* ${pet.desc}`)
    } else {
      L.push(`* Belum punya pet`)
    }

    L.push('')
    L.push(`🌱 *KEBUN*`)
    const crop = u.kebun?.cropKey ? cropConfig[u.kebun.cropKey] : null
    if (crop) {
      const left = crop.growMs - (now - u.kebun.plantedAt)
      L.push(`* *Tanaman:* ${crop.name}`)
      L.push(`* *Status:* ${left > 0 ? `Tumbuh, siap panen ${fmtTime(left)} lagi ⏳` : 'Siap panen! 🌾'}`)
      L.push(`* *Hasil Panen:* ${rp(crop.harvestValue)}`)
    } else {
      L.push(`* Kebun kosong`)
    }
-
    L.push('')
    L.push(`🏰 *GUILD*`)
    if (u.guildId) {
      const g = getGuildInfo(u.guildId)
      if (g) {
        L.push(`* *Guild:* ${g.name} (Lv ${g.level})`)
        L.push(`* *Jabatan:* ${g.leader === target ? 'Leader 👑' : 'Member'}`)
        L.push(`* *Anggota:* ${g.members.length}/20`)
        L.push(`* *Bank Guild:* ${rp(g.bank)}`)
        L.push(`* *Kontribusi Guild:* ${rp(u.kontribusiGuild)}`)
        if (g.raidBoss && g.raidBoss.hp > 0) {
          const dmg = g.raidBoss.contributors?.[target] || 0
          L.push(`* *Raid Boss:* ${g.raidBoss.name} - HP ${g.raidBoss.hp.toLocaleString('id-ID')}/${g.raidBoss.maxHp.toLocaleString('id-ID')} (damage dia: ${dmg.toLocaleString('id-ID')})`)
        }
      } else {
        L.push(`* Guild (${u.guildId}) udah bubar`)
      }
    } else {
      L.push(`* Belum gabung guild`)
    }

    L.push('')
    L.push(`📜 *QUEST HARIAN*`)
    const quests = u.quests?.date === todayStr() ? u.quests.list : []
    if (quests.length) {
      for (const q of quests) {
        const icon = q.claimed ? '✅' : q.progress >= q.target ? '🎁' : '⏳'
        L.push(`* ${icon} ${q.desc} (${q.progress}/${q.target})${q.claimed ? ' - sudah diklaim' : q.progress >= q.target ? ' - siap diklaim!' : ''}`)
      }
    } else {
      L.push(`* Belum ada quest hari ini`)
    }

    L.push('')
    L.push(`🏆 *PENCAPAIAN* (${ach.unlocked.length}/${achievementConfig.length})`)
    for (const a of achievementConfig) {
      L.push(`* ${ach.unlocked.includes(a.id) ? '✅' : '🔒'} ${a.name}`)
    }

    const titles = getAvailableTitles(target)
    L.push('')
    L.push(`🎖️ *TITLE TERBUKA* (${titles.length}/${titleConfig.length})`)
    L.push(`* ${titles.map(t => t.name).join(', ')}`)

    const lastJob = job || null
    L.push('')
    L.push(`⏱️ *COOLDOWN*`)
    L.push(`* *Daily:* ${cd(u.lastDaily, COOLDOWN.daily)}`)
    L.push(`* *Kerja:* ${lastJob ? cd(u.lastKerja, lastJob.cooldown) : 'Siap ✅'}`)
    L.push(`* *Rampok:* ${cd(u.lastRampok, COOLDOWN.rampok)}`)
    L.push(`* *Bounty:* ${cd(u.lastBounty, COOLDOWN.bounty)}`)
    L.push(`* *Mancing:* ${cd(u.lastMancing, COOLDOWN.mancing)}`)
    L.push(`* *Tambang:* ${cd(u.lastTambang, COOLDOWN.tambang)}`)
    L.push(`* *Nebang:* ${cd(u.lastNebang, COOLDOWN.nebang)}`)

    const equippedKeys = Object.values(eq).filter(Boolean)
    const entries = Object.entries(u.inventory || {}).filter(([, qty]) => qty > 0)

    const grouped = {}
    let totalQty = 0
    let totalValue = 0
    for (const [key, qty] of entries) {
      const it = itemsConfig[key]
      const type = it && TYPE_LABEL[it.type] ? it.type : 'other'
      ;(grouped[type] ||= []).push({ key, qty, it })
      totalQty += qty
      totalValue += (it?.sellPrice || 0) * qty
    }

    L.push('')
    L.push(`🎒 *INVENTORY* (${entries.length} jenis, ${totalQty} item)`)
    if (entries.length === 0) {
      L.push(`* Kosong melompong`)
    } else {
      for (const type of Object.keys(TYPE_LABEL)) {
        const list = grouped[type]
        if (!list) continue
        L.push(`*${TYPE_LABEL[type]}*`)
        for (const { key, qty, it } of list) {
          const used = equippedKeys.includes(key) ? ' _[dipakai]_' : ''
          L.push(`* ${it?.name || key} x${qty} _(${key})_${used}`)
        }
      }
      L.push(`* *Estimasi Nilai Jual:* ${rp(totalValue)}`)
    }

    try {
      const guildName = u.guildId ? getGuildInfo(u.guildId)?.name : null
      const avatarBuffer = await fetchAvatar(sock, target)
      const card = await createStatCard({
        name,
        title: title?.name || u.activeTitle,
        level: u.level,
        prestige: u.prestige,
        xp: u.xp,
        xpNeeded: u.xpNeeded,
        hp: u.hp,
        maxHp: u.maxHp,
        attack: p.attack,
        defense: p.defense,
        crit: p.critChance,
        evasion: p.evasion,
        balance: u.balance,
        bank: u.bank,
        job: job?.name,
        guild: guildName,
        pet: pet?.name,
        tier: getRankTier(rating),
        rating,
        avatarBuffer
      })
      const meta = await sock.uploadThumbnail(card)

      await sock.message.send(m.chat, {
        extendedTextMessage: {
          title: `Profil RPG • ${name}`,
          description: `Lv ${u.level} • Total aset ${rp(u.balance + u.bank)}`,
          text: `${TARGET_URL}\n\n${L.join('\n')}`,
          matchedText: TARGET_URL,
          previewType: 0,
          inviteLinkGroupTypeV2: 0,
          ...meta
        }
      }, { mentions })
    } catch (err) {
      console.error('[STATS] gagal bikin kartu, kirim teks biasa:', err?.message || err)
      await sock.message.send(m.chat, {
        conversation: L.join('\n'),
        mentionedJid: mentions
      }, { additionalAttributes: { type: "text" } })
    }
  }
}