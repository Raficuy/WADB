import { cekHutang } from '../../lib/rpgDatabase.js'

export default {
  command: 'tagihan',
  alias: ['cekhutang'],
  category: 'rpg',
  description: 'Cek jumlah tagihan hutang lu ke rentenir.',

  async execute(m) {
    const info = cekHutang(m.sender)
    
    if (!info.status) {
      return m.reply(` *RENTENIR*\n\nLu bersih, kaga punya hutang sama sekali.\nKetik *.pinjam [nominal]* kalo lagi butuh modal cepat.`)
    }
    
    let text = `*TAGIHAN HUTANG LU*\n\n`
    text += `Pinjaman Awal: Rp${info.hutangAwal.toLocaleString('id-ID')}\n`
    text += `Lama Nunggak: ${info.hariBerlalu} Hari (Bunga 5%/hari)\n\n`
    text += `💸 *Total Tagihan: Rp${info.totalHutang.toLocaleString('id-ID')}*\n\n`
    text += `Buruan lunasin pake *.bayarhutang [nominal]* sebelum *debt collector* nyamper!`
    
    return m.reply(text)
  }
}