import { getDailyQuests, claimQuest } from '../../lib/rpgDatabase.js'

export default {
  command: 'quest',
  alias: ['misi'],
  category: 'rpg',
  description: 'Liat & klaim quest harian.',

  async execute(m, { args }) {
    if (args[0] === 'klaim' || args[0] === 'claim') {
      const questId = args[1]
      if (!questId) return m.reply('❌ Sebutin id quest-nya. Ketik `.quest` buat liat list.')

      const res = claimQuest(m.sender, questId)
      if (!res.status) {
        if (res.reason === 'quest_tidak_ada') return m.reply('❌ Quest itu kaga ada di list lu hari ini.')
        if (res.reason === 'sudah_diklaim') return m.reply('❌ Udah lu klaim sebelumnya.')
        if (res.reason === 'belum_selesai') return m.reply('❌ Progress quest itu belum kelar.')
      }

      return m.reply(`🎉 *QUEST SELESAI!*\n\n${res.quest.desc}\n💰 +Rp${res.quest.reward.toLocaleString('id-ID')}\n✨ +XP ${res.quest.rewardXp}${res.xpResult.levelUps.length > 0 ? ' (🎉 NAIK LEVEL!)' : ''}`)
    }

    const quests = getDailyQuests(m.sender)
    let text = `📋 *QUEST HARIAN*\n_Reset tiap hari. Ketik .quest klaim [id] kalo udah selesai._\n\n`
    for (const q of quests) {
      const status = q.claimed ? '✅ Diklaim' : q.progress >= q.target ? '🎁 Siap diklaim!' : `⏳ ${q.progress}/${q.target}`
      text += `🔹 *${q.id}* - ${q.desc}\n   ${status} | Reward: Rp${q.reward.toLocaleString('id-ID')} + ${q.rewardXp}xp\n\n`
    }

    return m.reply(text)
  }
}
