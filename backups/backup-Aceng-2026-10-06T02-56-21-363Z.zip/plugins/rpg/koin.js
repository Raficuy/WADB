import { coinFlip } from '../../lib/rpgDatabase.js'

export default {
  command: 'koin',
  alias: ['coinflip', 'sut'],
  category: 'rpg',
  description: 'Judi lempar koin. Tebak angka/gambar.',

  async execute(m, { args }) {
    const guess = args[0]?.toLowerCase()
    const amount = parseInt(args[1])

    if (!['angka', 'gambar'].includes(guess) || !amount) {
      return m.reply('❌ Contoh: `.koin angka 10000` atau `.koin gambar 5000`')
    }

    const res = coinFlip(m.sender, amount, guess)
    if (!res.status) return m.reply('❌ Saldo lu kurang buat taruhan segitu.')

    if (res.win) {
      return m.reply(`🪙 Koinnya jatuh *${res.result}*!\n🎉 Tebakan lu bener! +Rp${res.amount.toLocaleString('id-ID')}\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    } else {
      return m.reply(`🪙 Koinnya jatuh *${res.result}*!\n😭 Meleset. -Rp${res.amount.toLocaleString('id-ID')}\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }
  }
}
