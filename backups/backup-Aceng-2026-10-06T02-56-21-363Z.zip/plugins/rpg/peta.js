import { getUser, mapConfig, travelTo, fmtTime } from '../../lib/rpgDatabase.js'

const SPECIALTY_LABEL = {
  tambang: '⛏️ Tambang',
  nebang: '🪓 Nebang',
  mancing: '🎣 Mancing',
  hunt: '⚔️ Hunt',
  all: '🌟 Semua Gathering & Hunt'
}

function statLine(map) {
  const parts = []
  if (map.gatherBonus > 0) parts.push(`+${map.gatherBonus}% peluang rare buat ${SPECIALTY_LABEL[map.specialty] || map.specialty}`)
  if (map.gatherLocked.length > 0) parts.push(`🚫 kaga bisa: ${map.gatherLocked.join(', ')}`)
  if (map.statMod.attack !== 0) parts.push(`${map.statMod.attack > 0 ? '+' : ''}${map.statMod.attack} Attack`)
  if (map.statMod.defense !== 0) parts.push(`${map.statMod.defense > 0 ? '+' : ''}${map.statMod.defense} Defense`)
  if (map.statMod.evasion !== 0) parts.push(`${map.statMod.evasion > 0 ? '+' : ''}${map.statMod.evasion}% Evasi`)
  if (map.hpCostMult !== 1) parts.push(`HP kepake x${map.hpCostMult} pas nambang`)
  if (map.huntLootMult !== 1) parts.push(`Loot hunt x${map.huntLootMult}`)
  if (map.huntXpMult !== 1) parts.push(`XP hunt x${map.huntXpMult}`)
  return parts.length ? parts.join(' | ') : 'Zona netral, kaga ada efek apa-apa.'
}

export default {
  command: 'peta',
  alias: ['map', 'travel', 'pergi'],
  category: 'rpg',
  description: 'Liat & pindah lokasi. Tiap peta punya spesialisasi gathering beda + tradeoff stat.',

  async execute(m, { args }) {
    const sub = args[0]?.toLowerCase()

    if (sub === 'pergi' || sub === 'go' || sub === 'travel') {
      const mapId = args[1]?.toLowerCase()
      if (!mapId) return m.reply('❌ Mau pergi kemana? Contoh: `.peta pergi gunung`')

      const res = travelTo(m.sender, mapId)
      if (!res.status) {
        if (res.reason === 'map_invalid') return m.reply(`❌ Lokasi *${mapId}* kaga ada. Ketik *.peta* buat liat daftar.`)
        if (res.reason === 'sudah_di_sini') return m.reply(`❌ Lu udah ada di *${res.map.name}*.`)
        if (res.reason === 'level_kurang') return m.reply(`❌ Level lu kurang! Butuh level *${res.butuh}* buat masuk *${res.map.name}*.`)
        if (res.reason === 'cooldown') return m.reply(`⏳ Masih capek jalan! Tunggu *${fmtTime(res.timeLeft)}*.`)
      }

      return m.reply(
        `🗺️ *BERANGKAT!*\n\n` +
        `Dari *${res.from.name}* ➜ *${res.to.name}*\n\n` +
        `${res.to.desc}\n\n` +
        `📋 *Efek di sini:* ${statLine(res.to)}`
      )
    }

    const user = getUser(m.sender)
    const current = mapConfig[user.currentMap] || mapConfig.kota

    let text = `🗺️ *PETA DUNIA*\n_Ketik .peta pergi [lokasi] buat pindah._\n\n`
    text += `📍 *Lokasi lu sekarang:* ${current.name}\n\n`

    for (const map of Object.values(mapConfig)) {
      const here = map.id === user.currentMap ? ' 👈 di sini' : ''
      const locked = user.level < map.minLevel ? ` 🔒 (butuh level ${map.minLevel})` : ''
      text += `*${map.name}*${here}${locked}\n`
      text += `   ${map.desc}\n`
      text += `   ${statLine(map)}\n\n`
    }

    text += `_Travel ada cooldown 3 menit tiap pindah lokasi._`
    return m.reply(text)
  }
}
