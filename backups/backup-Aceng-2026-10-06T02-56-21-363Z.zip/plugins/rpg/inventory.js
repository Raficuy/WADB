import { getUser, getInventory, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'inventory',
  alias: ['inv', 'tas'],
  category: 'rpg',
  description: 'Liat isi tas/inventory lu.',

  async execute(m) {
    const user = getUser(m.sender)
    const items = getInventory(m.sender)

    let text = `🎒 *INVENTORY LU*\n\n`

    if (items.length === 0) {
      text += `_Kosong melompong. Coba .tambang / .nebang / .mancing, atau beli di *.shop*._\n\n`
    } else {
      for (const it of items) {
        text += `🔹 *${it.key}* - ${it.name} x${it.qty}\n`
      }
      text += '\n'
    }

    text += `*Alat Terpasang:*\n`
    text += `⚔️ Senjata: ${user.equipped.weapon ? itemsConfig[user.equipped.weapon]?.name : '(kosong)'}\n`
    text += `🛡️ Armor: ${user.equipped.armor ? itemsConfig[user.equipped.armor]?.name : '(kosong)'}\n`
    text += `🎣 Pancingan: ${user.equipped.rod ? itemsConfig[user.equipped.rod]?.name : '(kosong)'}\n`
    text += `⛏️ Beliung: ${user.equipped.pickaxe ? itemsConfig[user.equipped.pickaxe]?.name : '(kosong, bisa tambang tangan kosong tapi terbatas)'}\n`
    text += `🪓 Kapak: ${user.equipped.axe ? itemsConfig[user.equipped.axe]?.name : '(kosong, bisa nebang tangan kosong)'}\n`
    text += `❤️ HP: ${user.hp}/${user.maxHp}\n\n`
    text += `_Ketik *.pakai [nama_item]* buat makan/minum/equip/pasang alat._`

    return m.reply(text)
  }
}
