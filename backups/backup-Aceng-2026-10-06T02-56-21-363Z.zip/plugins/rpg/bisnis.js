import { getUser, bisnisConfig, upgradeBisnis } from '../../lib/rpgDatabase.js'

export default {
  command: 'bisnis',
  alias: ['tycoon', 'usaha', 'toko'],
  category: 'rpg',
  description: 'Beli dan kelola bisnismu untuk passive income.',

  async execute(m, { sock, args }) {
    const user = getUser(m.sender)
    const currentTier = bisnisConfig[user.bisnisLvl]
    const nextTier = bisnisConfig[user.bisnisLvl + 1]

    if (args[0] === 'upgrade' || args[0] === 'beli') {
      const proses = upgradeBisnis(m.sender)
      
      if (!proses.status) {
        if (proses.reason === 'max') return m.reply('Sultan! Bisnis lu udah mentok di level paling tinggi.')
        if (proses.reason === 'miskin') return m.reply(`Saldo lu kurang *Rp${proses.kurang.toLocaleString('id-ID')}* buat beli bisnis level selanjutnya. Ngumpulin duit dulu sana!`)
      }

      await sock.sendReact(m.chat, '📈', m.key).catch(() => {})
      return m.reply(` *UPGRADE BERHASIL!* 🎉\n\nSelamat! Lu baru aja ngebuka usaha *${proses.newTier.name}*.\nSekarang lu bakal dapet passive income *Rp${proses.newTier.incomePerJam.toLocaleString('id-ID')}* setiap jamnya.\n\nKetik *.panen* buat ngambil duit lu nanti.`)
    }

    // Nampilin Status Bisnis saat ini (Kalo cuma ngetik .bisnis)
    let info = `* *PAPAN KONTROL BISNIS*\n\n`
    info += `* Pemilik: @${m.sender.split('@')[0]}\n`
    info += `* Bisnis Saat Ini: *${currentTier.name}*\n`
    info += `* Pendapatan: *Rp${currentTier.incomePerJam.toLocaleString('id-ID')} / Jam*\n\n`
    info += `_Ketik *.panen* untuk mengambil pendapatan usahamu._\n`
    info += `━━━━━━━━━━━━━━━━━━\n`

    if (nextTier) {
      info += `\n🚀 *UPGRADE BERIKUTNYA*\n`
      info += `Nama: ${nextTier.name}\n`
      info += `Harga: Rp${nextTier.cost.toLocaleString('id-ID')}\n`
      info += `Pendapatan: Rp${nextTier.incomePerJam.toLocaleString('id-ID')} / Jam\n\n`
      info += `_Ketik *.bisnis upgrade* untuk membeli._`
    } else {
      info += `\n👑 Lu udah menguasai seluruh rantai bisnis di kota ini.`
    }

    await sock.message.send(m.chat, { conversation: info, mentions: [m.sender] }, { additionalAttributes: { type: "text" } })
  }
}