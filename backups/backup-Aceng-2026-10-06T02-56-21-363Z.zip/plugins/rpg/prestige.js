import { prestigeUser } from '../../lib/rpgDatabase.js'

export default {
  command: 'prestige',
  alias: ['naiktahta'],
  category: 'rpg',
  description: 'Reset level demi bonus permanen kalo udah level 50+.',

  async execute(m) {
    const res = prestigeUser(m.sender)

    if (!res.status) {
      if (res.reason === 'level_kurang') return m.reply(`❌ Level lu masih ${res.level}. Butuh minimal level *${res.butuh}* buat prestige.`)
    }

    return m.reply(`🌟 *PRESTIGE!* 🌟\n\nLevel lu direset, tapi lu sekarang *Prestige ${res.prestige}*!\nHP maksimal lu naik permanen. Title "Legenda" udah kebuka.`)
  }
}
