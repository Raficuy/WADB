import { nebang, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'nebang',
  alias: ['chop', 'tebangpohon'],
  category: 'rpg',
  description: 'Nebang pohon buat dapetin kayu, selalu bisa tangan kosong.',

  async execute(m) {
    const res = nebang(m.sender)

    if (!res.status) {
      if (res.reason === 'cooldown') return m.reply(`⏳ Tangan lu masih pegel! Tunggu *${fmtTime(res.timeLeft)}*.`)
      if (res.reason === 'map_terlarang') return m.reply(`❌ Kaga bisa nebang di *${res.map.name}*, medannya kaga cocok. Balik ke hutan/kota dulu pake \`.peta pergi\`.`)
    }

    let text = `🪓 *NEBANG BERHASIL!*${res.hasAxe ? '' : ' (tangan kosong)'}\n\nLu dapet *${res.qty}x ${res.wood.name}* (${res.rarity})!`
    if (res.mapBonusActive) text += `\n🌳 *${res.map.name}* nambah peluang kayu langka!`
    if (!res.hasAxe) {
      text += `\n\n_Kumpulin dulu kayu_biasa & batu (dari .tambang tangan kosong), terus .craft kapak_kayu biar nebang lebih efisien._`
    } else {
      text += `\n\n_Ketik *.jual ${res.woodKey}* buat dijual, atau simpen buat crafting alat/senjata._`
    }

    return m.reply(text)
  }
}
