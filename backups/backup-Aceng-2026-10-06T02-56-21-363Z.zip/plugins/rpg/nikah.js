import { getUser, marryUser, divorceUser } from '../../lib/rpgDatabase.js'

export default {
  command: 'nikah',
  alias: ['marry', 'cerai'],
  category: 'rpg',
  description: 'Nikahin member lain (butuh cincin_nikah) atau cerai.',
  groupOnly: true,

  async execute(m, { sock }) {
    if (m.command === 'cerai') {
      const res = divorceUser(m.sender)
      if (!res.status) return m.reply('❌ Lu masih single, kaga ada yang bisa diceraiin.')
      const text = `💔 @${m.sender.split('@')[0]} resmi cerai sama @${res.mantan.split('@')[0]}.`
      return sock.message.send(m.chat, { text, mentions: [m.sender, res.mantan] }, { additionalAttributes: { type: 'text' } })
    }

    const target = m.mentionedJid?.[0] || m.quoted?.sender
    if (!target) return m.reply('❌ Tag calon pasangan lu!\nContoh: `.nikah @orangnya` (butuh item `cincin_nikah`, beli di `.shop`)')
    if (target === m.sender) return m.reply('❌ Lu mau nikah sama diri sendiri?')

    const res = marryUser(m.sender, target)
    if (!res.status) {
      if (res.reason === 'salah_satu_sudah_menikah') return m.reply('❌ Salah satu dari kalian udah punya pasangan.')
      if (res.reason === 'butuh_cincin_nikah') return m.reply('❌ Lu butuh item `cincin_nikah`! Beli dulu di `.shop beli cincin_nikah`.')
    }

    const text = `💍 *PERNIKAHAN SAH!* 💍\n\n@${m.sender.split('@')[0]} resmi menikah sama @${target.split('@')[0]}.\nSelamat menempuh hidup baru! 🎉`
    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
