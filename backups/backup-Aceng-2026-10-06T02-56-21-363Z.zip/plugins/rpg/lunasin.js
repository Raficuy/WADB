import { bayarHutang } from '../../lib/rpgDatabase.js'

export default {
  command: 'bayarhutang',
  alias: ['lunasin'],
  category: 'rpg',
  description: 'Bayar hutang rentenir.',

  async execute(m, { args }) {
    const jumlah = parseInt(args[0])

    if (isNaN(jumlah)) {
      return m.reply('❌ Masukin nominal yang mau dibayar!\nContoh: `.bayarhutang 10000`')
    }

    const res = bayarHutang(m.sender, jumlah)
      
    if (!res.status) {
      if (res.reason === 'tidak_ada_hutang') return m.reply('❌ Lu sehat? Kaga punya hutang ngapain bayar.')
      if (res.reason === 'jumlah_invalid') return m.reply('❌ Nominal kaga valid. Masukin angka bulat positif.')
      if (res.reason === 'saldo_kurang') return m.reply('❌ Duit di kantong lu kurang buat bayar segitu! Kerja dulu sana.')
    }
      
    let text = `✅ *PEMBAYARAN DITERIMA*\n\nLu bayar hutang sebesar Rp${res.dibayar.toLocaleString('id-ID')}.\n`
    
    if (res.sisaHutang === 0) {
      text += `🎉 *HUTANG LU LUNAS!* Lu bisa tidur nyenyak malam ini.`
    } else {
      text += `Sisa hutang lu tinggal: Rp${res.sisaHutang.toLocaleString('id-ID')}`
    }
      
    return m.reply(text)
  }
}