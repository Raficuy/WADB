import { huntMonster } from '../../lib/rpgDatabase.js'

export default {
  command: 'hunt',
  alias: ['buru', 'berburu'],
  category: 'rpg',
  description: 'Berburu monster buat loot & xp. Hati-hati HP lu abis.',

  async execute(m, { sock }) {
    const res = huntMonster(m.sender)

    if (!res.status) {
      if (res.reason === 'hp_kurang') return m.reply(`❌ HP lu kritis (${res.hp})! Makan/minum dulu sebelum berburu lagi.`)
    }

    if (res.win) {
      await sock.sendReact(m.chat, res.isCrit ? '💥' : '⚔️', m.key).catch(() => {})
      let text = `⚔️ *MENANG!*${res.isCrit ? ' 💥 CRITICAL HIT!' : ''} Lu ngalahin *${res.monster.name}*!\n💰 Loot: +Rp${res.loot.toLocaleString('id-ID')}\n✨ +XP ${res.monster.xp}${res.xpResult.levelUps.length > 0 ? ' (🎉 NAIK LEVEL!)' : ''}`
      if (res.materialDrop) {
        text += `\n🎁 Bonus drop: *${res.materialDrop.item.name}* x1!`
      }
      if (res.map?.huntLootMult > 1) text += `\n🏛️ Loot & XP digandain *${res.map.name}* (x${res.map.huntLootMult})!`
      return m.reply(text)
    } else {
      await sock.sendReact(m.chat, res.isEvade ? '💨' : '💥', m.key).catch(() => {})
      if (res.isEvade) {
        return m.reply(`💨 *NYARIS!* Lu kalah lawan *${res.monster.name}*, tapi armor lu berhasil ngindarin semua damage!`)
      }
      return m.reply(`💥 *KALAH!* Lu ketemu *${res.monster.name}* tapi kalah kuat.\n❤️ HP: -${res.damageTaken} (sekarang ${res.hp})\n\n_Ketik .pakai buat heal dulu._`)
    }
  }
}
