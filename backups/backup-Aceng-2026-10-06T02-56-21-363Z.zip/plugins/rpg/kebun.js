import { getUser, tanam, panenKebun, cropConfig, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'kebun',
  alias: ['tanam', 'panenkebun', 'berkebun'],
  category: 'rpg',
  description: 'Tanam benih & panen hasil kebun.',

  async execute(m, { args }) {
    if (m.command === 'tanam') {
      const cropKey = args[0]?.toLowerCase()
      if (!cropKey) {
        let text = `🌱 *DAFTAR BENIH*\n_Ketik .tanam [nama]_\n\n`
        for (const [key, c] of Object.entries(cropConfig)) {
          text += `🔹 *${key}* - ${c.name}\n   Harga: Rp${c.seedPrice.toLocaleString('id-ID')} | Waktu tumbuh: ${fmtTime(c.growMs)} | Hasil: Rp${c.harvestValue.toLocaleString('id-ID')}\n\n`
        }
        return m.reply(text)
      }

      const res = tanam(m.sender, cropKey)
      if (!res.status) {
        if (res.reason === 'benih_invalid') return m.reply(`❌ Benih *${cropKey}* kaga ada.`)
        if (res.reason === 'sudah_ada_tanaman') return m.reply('❌ Kebun lu masih ada tanamannya. Panen dulu sana.')
        if (res.reason === 'saldo_kurang') return m.reply('❌ Saldo lu kurang buat beli benih ini.')
      }

      return m.reply(`🌱 Lu tanam *${res.crop.name}*!\n⏳ Siap panen dalam *${fmtTime(res.crop.growMs)}*.\n\n_Ketik *.panenkebun* nanti kalo udah waktunya._`)
    }

    if (m.command === 'panenkebun') {
      const res = panenKebun(m.sender)
      if (!res.status) {
        if (res.reason === 'belum_tanam') return m.reply('❌ Lu belum nanam apa-apa. Ketik `.tanam` buat mulai.')
        if (res.reason === 'belum_siap') return m.reply(`⏳ Belum siap panen! Tunggu *${fmtTime(res.timeLeft)}* lagi.`)
      }

      return m.reply(`🌾 *PANEN BERHASIL!*\n\nLu panen *${res.crop.name}* dan dapet Rp${res.dapet.toLocaleString('id-ID')}.\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }

    const user = getUser(m.sender)
    if (!user.kebun) return m.reply('🌱 Kebun lu masih kosong. Ketik `.tanam` buat mulai berkebun.')

    const crop = cropConfig[user.kebun.cropKey]
    const elapsed = Date.now() - user.kebun.plantedAt
    const sisa = crop.growMs - elapsed

    return m.reply(`🌱 *KEBUN LU*\n\nTanaman: ${crop.name}\nStatus: ${sisa <= 0 ? '✅ Siap dipanen! Ketik .panenkebun' : `⏳ Siap dalam ${fmtTime(sisa)}`}`)
  }
}
