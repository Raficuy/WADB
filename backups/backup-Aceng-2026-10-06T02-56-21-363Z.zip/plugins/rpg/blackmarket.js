import { getBlackMarket, buyBlackMarket, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'blackmarket',
  alias: ['bm', 'pasargelap'],
  category: 'rpg',
  description: 'Pasar gelap, stok terbatas & diskon, reset tiap hari.',

  async execute(m, { args }) {
    if (args[0] === 'beli' || args[0] === 'buy') {
      const itemKey = args[1]?.toLowerCase()
      if (!itemKey) return m.reply('❌ Contoh: `.blackmarket beli pedang_naga`')

      const res = buyBlackMarket(m.sender, itemKey)
      if (!res.status) {
        if (res.reason === 'item_tidak_tersedia') return m.reply('❌ Item itu kaga ada di pasar gelap hari ini.')
        if (res.reason === 'stok_habis') return m.reply('❌ Stok item itu udah abis hari ini.')
        if (res.reason === 'saldo_kurang') return m.reply('❌ Saldo lu kurang buat beli itu.')
      }

      return m.reply(`🕶️ *DEAL!*\n\nLu dapet *${res.item.name}* seharga Rp${res.price.toLocaleString('id-ID')} (diskon dari pasar gelap).\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }

    const stock = getBlackMarket()
    let text = `🕶️ *PASAR GELAP* 🕶️\n_Stok terbatas, reset tiap hari!_\n_Ketik .blackmarket beli [nama_item]_\n\n`
    for (const entry of stock) {
      const item = itemsConfig[entry.key]
      text += `🔹 *${entry.key}* - ${item.name}\n   Harga Diskon: Rp${entry.price.toLocaleString('id-ID')} ~~Rp${item.price.toLocaleString('id-ID')}~~ | Stok: ${entry.limit}\n\n`
    }

    return m.reply(text)
  }
}
