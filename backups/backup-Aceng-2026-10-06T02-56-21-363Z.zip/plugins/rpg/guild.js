import {
  getUser,
  createGuild,
  joinGuild,
  leaveGuild,
  contributeGuild,
  getGuildInfo
} from '../../lib/rpgDatabase.js'

export default {
  command: 'guild',
  alias: ['klan'],
  category: 'rpg',
  description: 'Bikin/gabung guild, kontribusi bank guild bareng-bareng.',

  async execute(m, { sock, args }) {
    const sub = args[0]?.toLowerCase()

    if (sub === 'create' || sub === 'buat') {
      const nama = args.slice(1).join(' ')
      if (!nama) return m.reply('❌ Contoh: `.guild create Naga Sakti` (biaya Rp50.000)')

      const res = createGuild(m.sender, nama)
      if (!res.status) {
        if (res.reason === 'sudah_punya_guild') return m.reply('❌ Lu udah gabung guild. Keluar dulu kalo mau bikin baru.')
        if (res.reason === 'nama_dipakai') return m.reply('❌ Nama guild itu udah dipake, cari nama lain.')
        if (res.reason === 'saldo_kurang') return m.reply(`❌ Saldo lu kurang. Butuh Rp${res.butuh.toLocaleString('id-ID')}.`)
      }

      return m.reply(`🏰 *GUILD TERBENTUK!*\n\nGuild *${res.guild.name}* (id: \`${res.guildId}\`) berhasil dibikin!\nAjak temen gabung pake: \`.guild join ${res.guildId}\``)
    }

    if (sub === 'join' || sub === 'gabung') {
      const guildId = args[1]?.toLowerCase()
      if (!guildId) return m.reply('❌ Contoh: `.guild join naga_sakti`')

      const res = joinGuild(m.sender, guildId)
      if (!res.status) {
        if (res.reason === 'sudah_punya_guild') return m.reply('❌ Lu udah gabung guild lain.')
        if (res.reason === 'guild_tidak_ada') return m.reply('❌ Guild itu kaga ketemu.')
        if (res.reason === 'guild_penuh') return m.reply('❌ Guild itu udah penuh (max 20 member).')
      }

      return m.reply(`🎉 Lu resmi gabung guild *${res.guild.name}*!`)
    }

    if (sub === 'leave' || sub === 'keluar') {
      const res = leaveGuild(m.sender)
      if (!res.status) return m.reply('❌ Lu belum gabung guild manapun.')
      return m.reply('👋 Lu keluar dari guild.')
    }

    if (sub === 'kontribusi' || sub === 'sumbang') {
      const amount = parseInt(args[1])
      if (!amount) return m.reply('❌ Contoh: `.guild kontribusi 20000`')

      const res = contributeGuild(m.sender, amount)
      if (!res.status) {
        if (res.reason === 'tidak_punya_guild') return m.reply('❌ Lu belum gabung guild.')
        if (res.reason === 'saldo_kurang') return m.reply('❌ Saldo lu kurang buat nyumbang segitu.')
      }

      return m.reply(`🏰 Kontribusi diterima!\n💰 Bank Guild: Rp${res.guildBank.toLocaleString('id-ID')}\n📈 Level Guild: ${res.guildLevel}`)
    }

    // Info guild sendiri
    const user = getUser(m.sender)
    if (!user.guildId) {
      return m.reply('🏰 Lu belum gabung guild manapun.\n\n_Ketik *.guild create [nama]* buat bikin, atau *.guild join [id]* buat gabung._')
    }

    const guild = getGuildInfo(user.guildId)
    if (!guild) return m.reply('❌ Data guild lu kaga ketemu (mungkin udah dibubarin).')

    let text = `🏰 *${guild.name}*\n\n`
    text += `👑 Ketua: @${guild.leader.split('@')[0]}\n`
    text += `👥 Member: ${guild.members.length}/20\n`
    text += `💰 Bank Guild: Rp${guild.bank.toLocaleString('id-ID')}\n`
    text += `📈 Level: ${guild.level}\n`
    if (guild.raidBoss && guild.raidBoss.hp > 0) {
      text += `\n🐉 *Raid Boss Aktif:* ${guild.raidBoss.name} (HP: ${guild.raidBoss.hp}/${guild.raidBoss.maxHp})\n_Ketik *.raidboss attack* buat nyerang!_`
    }

    return sock.message.send(m.chat, { text, mentions: [guild.leader] }, { additionalAttributes: { type: 'text' } })
  }
}
