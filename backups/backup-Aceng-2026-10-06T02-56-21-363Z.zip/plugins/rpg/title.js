import { getUser, getAvailableTitles, setTitle, titleConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'title',
  alias: ['gelar'],
  category: 'rpg',
  description: 'Liat & pasang title/gelar yang udah lu buka.',

  async execute(m, { args }) {
    if (args[0] === 'set' || args[0] === 'pasang') {
      const titleId = args[1]?.toLowerCase()
      if (!titleId) return m.reply('❌ Contoh: `.title set ksatria`')

      const res = setTitle(m.sender, titleId)
      if (!res.status) {
        if (res.reason === 'title_invalid') return m.reply(`❌ Title *${titleId}* kaga ada.`)
        if (res.reason === 'belum_memenuhi_syarat') return m.reply('❌ Lu belum memenuhi syarat buat title ini.')
      }

      return m.reply(`✅ Title lu sekarang: *${res.title.name}*`)
    }

    const user = getUser(m.sender)
    const available = getAvailableTitles(m.sender)
    const availableIds = available.map(t => t.id)

    let text = `🎖️ *DAFTAR TITLE*\n_Ketik .title set [id]_\n\n`
    for (const t of titleConfig) {
      const unlocked = availableIds.includes(t.id)
      const active = user.activeTitle === t.id ? ' (aktif)' : ''
      text += `${unlocked ? '✅' : '🔒'} *${t.id}* - ${t.name}${active}\n`
    }

    return m.reply(text)
  }
}
