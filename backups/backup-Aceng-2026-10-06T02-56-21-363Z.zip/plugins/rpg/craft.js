import { craftItem, craftingRecipes, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'craft',
  alias: ['rakit'],
  category: 'rpg',
  description: 'Rakit item dari bahan-bahan di inventory.',

  async execute(m, { args }) {
    const recipeKey = args[0]?.toLowerCase()

    if (!recipeKey) {
      let text = `🛠️ *DAFTAR RESEP CRAFT*\n_Ketik .craft [nama_resep]_\n\n`
      for (const [key, r] of Object.entries(craftingRecipes)) {
        const materials = Object.entries(r.materials).map(([m, q]) => `${q}x ${itemsConfig[m]?.name || m}`).join(' + ')
        text += `🔹 *${key}*\n   Bahan: ${materials}\n   Hasil: ${itemsConfig[r.result]?.name}\n\n`
      }
      return m.reply(text)
    }

    const res = craftItem(m.sender, recipeKey)
    if (!res.status) {
      if (res.reason === 'resep_invalid') return m.reply(`❌ Resep *${recipeKey}* kaga ada. Ketik *.craft* buat liat daftar.`)
      if (res.reason === 'bahan_kurang') return m.reply(`❌ Bahan lu kurang: *${itemsConfig[res.kurang]?.name || res.kurang}*.`)
    }

    return m.reply(`🛠️ *CRAFTING BERHASIL!*\n\nLu berhasil bikin *${res.qty}x ${res.item.name}*.${res.autoEquipped ? `\n✅ Otomatis kepasang di slot *${res.autoEquipped}*!` : ''}`)
  }
}
