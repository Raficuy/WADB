import { sellItem, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'jual',
  alias: ['sell'],
  category: 'rpg',
  description: 'Jual item dari inventory ke toko.',

  async execute(m, { args }) {
    const itemKey = args[0]?.toLowerCase()
    const qty = parseInt(args[1]) || 1

    if (!itemKey) return m.reply('❌ Mau jual apa? Contoh: `.jual ramen 2`')

    const item = itemsConfig[itemKey]
    if (!item) return m.reply(`❌ Item *${itemKey}* kaga dikenal.`)

    const res = sellItem(m.sender, itemKey, qty)
    if (!res.status) {
      if (res.reason === 'stok_kurang') return m.reply(`❌ Stok *${item.name}* lu kurang.`)
    }

    return m.reply(`💵 Lu jual *${res.qty}x ${item.name}* seharga Rp${res.dapet.toLocaleString('id-ID')}.\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
  }
}
