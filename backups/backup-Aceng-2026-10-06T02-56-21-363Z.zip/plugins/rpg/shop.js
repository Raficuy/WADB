import { getUser, itemsConfig, buyItem } from '../../lib/rpgDatabase.js'

const TYPE_LABEL = {
  food: '🍜 Makanan',
  potion: '🧪 Potion',
  weapon: '⚔️ Senjata',
  armor: '🛡️ Armor',
  special: '✨ Spesial',
  petfood: '🍖 Makanan Pet',
  buff: '✨ Ramuan/Buff'
}

export default {
  command: 'shop',
  alias: ['store', 'pasar'],
  category: 'rpg',
  description: 'Liat & beli barang di toko (alat & bahan mentah kaga dijual, harus di-craft).',

  async execute(m, { args, sock }) {
    if (args[0] === 'beli' || args[0] === 'buy') {
      const itemKey = args[1]?.toLowerCase()
      const qty = parseInt(args[2]) || 1

      if (!itemKey) return m.reply('❌ Mau beli apa? Contoh: `.shop beli ramen 2`')

      const res = buyItem(m.sender, itemKey, qty)
      if (!res.status) {
        if (res.reason === 'item_invalid') return m.reply(`❌ Item *${itemKey}* kaga ada di toko. Ketik *.shop* buat liat daftarnya.`)
        if (res.reason === 'tidak_dijual') return m.reply(`❌ Item *${itemKey}* kaga dijual di toko. Item ini cuma bisa didapet lewat *.tambang*/*.nebang*/*.mancing* atau di-*.craft*.`)
        if (res.reason === 'jumlah_invalid') return m.reply('❌ Jumlah kaga valid.')
        if (res.reason === 'saldo_kurang') return m.reply(`❌ Saldo lu kurang *Rp${res.kurang.toLocaleString('id-ID')}* buat beli itu.`)
      }

      return m.reply(`✅ *PEMBELIAN BERHASIL*\n\nLu beli *${res.qty}x ${res.item.name}*.\n💳 Sisa saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }

    const user = getUser(m.sender)
    let grouped = {}
    for (const [key, item] of Object.entries(itemsConfig)) {
      if (item.price === undefined) continue // craft-only / gather-only, kaga ditampilin di toko
      const label = TYPE_LABEL[item.type] || item.type
      if (!grouped[label]) grouped[label] = []
      grouped[label].push({ key, ...item })
    }

    let text = `🛒 *TOKO SERBA ADA*\n_Ketik .shop beli [nama_item] [jumlah]_\n\n`
    for (const [label, items] of Object.entries(grouped)) {
      text += `*${label}*\n`
      for (const it of items) {
        text += `🔹 *${it.key}* - ${it.name}\n   Harga: Rp${it.price.toLocaleString('id-ID')}\n`
      }
      text += '\n'
    }
    text += `_Alat (pancingan/beliung/kapak) & bahan mentah (kayu/batu/bijih/ikan) kaga dijual di sini — cari lewat .tambang/.nebang/.mancing, terus .craft._\n\n`
    text += `💳 Saldo lu: Rp${user.balance.toLocaleString('id-ID')}`

    try {
      return await sock.sendThumbnail(m.chat, {
        url: 'https://github.com/',
        title: 'RPG SHOP',
        body: 'Lihat item di bawah',
        text,
        thumbnail: 'https://d.tmpfile.link/public/2026-09-27/7a62103e-51b1-4498-958a-9580bcb43927/file_1790518583894.jpeg',
        quote: m
      })
    } catch (err) {
      console.error('[shop sendThumbnail]', err)
      return m.reply(text) // fallback teks biasa kalo thumbnail-nya gagal (link mati, dll)
    }
  }
}