import { pinjamUang } from '../../lib/rpgDatabase.js'

export default {
  command: 'pinjam',
  alias: ['utang'],
  category: 'rpg',
  description: 'Pinjam uang rentenir (Bunga 5% per hari).',

  async execute(m, { args }) {
    const jumlah = parseInt(args[0])

    if (isNaN(jumlah)) {
      return m.reply('❌ Masukin nominal yang mau dipinjem!\nContoh: `.pinjam 50000`')
    }

    const res = pinjamUang(m.sender, jumlah)
      
    if (!res.status) {
      if (res.reason === 'masih_ada_hutang') return m.reply(`❌ Lunasin dulu hutang lu sebelumnya yang sisa Rp${res.sisaHutang.toLocaleString('id-ID')}!`)
      if (res.reason === 'jumlah_invalid') return m.reply(`❌ Batas maksimal pinjaman cuma Rp${res.max.toLocaleString('id-ID')}.`)
    }
    
    return m.reply(`🤝 *CAIR BOS!*\n\nLu berhasil pinjam duit *Rp${jumlah.toLocaleString('id-ID')}*.\nInget, bunganya 5% per hari!\n\n💳 Total uang lu sekarang: Rp${res.balance.toLocaleString('id-ID')}`)
  }
}