import { getUser, startRaidBoss, attackRaidBoss } from '../../lib/rpgDatabase.js'

export default {
  command: 'raidboss',
  alias: ['raid'],
  category: 'rpg',
  description: 'Panggil & serang raid boss bareng-bareng guild.',

  async execute(m, { sock, args }) {
    const user = getUser(m.sender)
    if (!user.guildId) return m.reply('❌ Lu harus gabung guild dulu. Ketik `.guild create/join`.')

    const sub = args[0]?.toLowerCase()

    if (sub === 'start' || sub === 'panggil') {
      const res = startRaidBoss(user.guildId)
      if (!res.status) {
        if (res.reason === 'boss_masih_hidup') return m.reply(`❌ Raid boss lagi guild lu masih hidup (HP: ${res.raidBoss.hp}). Kalahin dulu!`)
      }
      return m.reply(`🐉🔥 *${res.raidBoss.name} MUNCUL!* 🔥🐉\n\nHP: ${res.raidBoss.hp}\nAjak member guild lain buat nyerang: \`.raidboss attack\``)
    }

    // default & 'attack'
    const res = attackRaidBoss(m.sender)
    if (!res.status) {
      if (res.reason === 'tidak_ada_boss') return m.reply('❌ Guild lu belum manggil raid boss. Ketik `.raidboss start`.')
    }

    if (res.bossDefeated) {
      await sock.sendReact(m.chat, '🏆', m.key).catch(() => {})
      let text = `🏆 *RAID BOSS TUMBANG!* 🏆\n\nSerangan terakhir @${m.sender.split('@')[0]} (-${res.damage} dmg) berhasil ngalahin boss!\n\n💰 *Reward dibagi ke kontributor:*\n`
      const mentions = []
      for (const [jid, share] of Object.entries(res.rewards)) {
        text += `• @${jid.split('@')[0]}: Rp${share.toLocaleString('id-ID')}\n`
        mentions.push(jid)
      }
      return sock.message.send(m.chat, { text, mentions }, { additionalAttributes: { type: 'text' } })
    }

    return m.reply(`⚔️ Lu nyerang boss sebesar *${res.damage}* damage!\n🐉 Sisa HP Boss: *${res.bossHp}*`)
  }
}
