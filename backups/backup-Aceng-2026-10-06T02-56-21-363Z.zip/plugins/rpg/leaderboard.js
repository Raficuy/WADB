import { getLeaderboard, getRankLeaderboard, getGuildLeaderboard } from '../../lib/rpgDatabase.js'

export default {
  command: 'leaderboard',
  alias: ['top', 'toprank', 'topguild'],
  category: 'rpg',
  description: 'Liat papan peringkat saldo, rank arena, atau guild.',

  async execute(m, { sock }) {
    if (m.command === 'toprank') {
      const list = getRankLeaderboard(10)
      let text = `🏅 *TOP ARENA RANK*\n\n`
      list.forEach((u, i) => {
        text += `${i + 1}. @${u.jid.split('@')[0]} - ${u.rating} (${u.tier})\n`
      })
      return sock.message.send(m.chat, { text, mentions: list.map(u => u.jid) }, { additionalAttributes: { type: 'text' } })
    }

    if (m.command === 'topguild') {
      const list = getGuildLeaderboard(10)
      if (list.length === 0) return m.reply('❌ Belum ada guild yang kebentuk.')
      let text = `🏰 *TOP GUILD*\n\n`
      list.forEach((g, i) => {
        text += `${i + 1}. ${g.name} - Bank: Rp${g.bank.toLocaleString('id-ID')} (Lv.${g.level}, ${g.members} member)\n`
      })
      return m.reply(text)
    }

    const list = getLeaderboard(10)
    let text = `💰 *TOP SULTAN GRUP*\n\n`
    list.forEach((u, i) => {
      text += `${i + 1}. @${u.jid.split('@')[0]} - Rp${u.total.toLocaleString('id-ID')} (Lv.${u.level})\n`
    })

    return sock.message.send(m.chat, { conversation: text, mentions: list.map(u => u.jid) }, { additionalAttributes: { type: 'text' } })
  }
}