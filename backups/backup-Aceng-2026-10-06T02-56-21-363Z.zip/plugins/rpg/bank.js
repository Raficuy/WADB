import { getUser, depositBank, withdrawBank } from '../../lib/rpgDatabase.js'

export default {
  command: 'bank',
  alias: ['nabung', 'tarik'],
  category: 'rpg',
  description: 'Simpen duit di bank biar aman dari rampokan.',

  async execute(m, { args }) {
    const typed = m.command
    const action = typed === 'nabung' ? 'nabung' : typed === 'tarik' ? 'tarik' : args[0]
    const amountArg = typed === 'bank' ? args[1] : args[0]
    const amount = parseInt(amountArg)

    if (action === 'nabung' || action === 'deposit') {
      if (!amount) return m.reply('❌ Contoh: `.nabung 20000`')
      const res = depositBank(m.sender, amount)
      if (!res.status) return m.reply('❌ Saldo lu kurang buat ditabung segitu.')
      return m.reply(`🏦 *NABUNG BERHASIL*\n\n💰 Saldo: Rp${res.balance.toLocaleString('id-ID')}\n🏦 Bank: Rp${res.bank.toLocaleString('id-ID')}`)
    }

    if (action === 'tarik' || action === 'withdraw') {
      if (!amount) return m.reply('❌ Contoh: `.tarik 20000`')
      const res = withdrawBank(m.sender, amount)
      if (!res.status) return m.reply('❌ Saldo bank lu kurang buat ditarik segitu.')
      return m.reply(`🏦 *TARIK BERHASIL*\n\n💰 Saldo: Rp${res.balance.toLocaleString('id-ID')}\n🏦 Bank: Rp${res.bank.toLocaleString('id-ID')}`)
    }

    const user = getUser(m.sender)
    return m.reply(`🏦 *REKENING BANK LU*\n\n💰 Saldo Tunai: Rp${user.balance.toLocaleString('id-ID')}\n🏦 Saldo Bank: Rp${user.bank.toLocaleString('id-ID')}\n\n_Uang di bank aman dari rampokan._\n_Ketik *.nabung [jumlah]* atau *.tarik [jumlah]*._`)
  }
}
