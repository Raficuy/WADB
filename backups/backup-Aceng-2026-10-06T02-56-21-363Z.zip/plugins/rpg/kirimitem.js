import { tradeItem, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'kirimitem',
  alias: ['giveitem'],
  category: 'rpg',
  description: 'Kirim item dari tas lu ke member lain.',
  groupOnly: true,

  async execute(m, { sock, args }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender
    const itemKey = args.find(a => !a.startsWith('@') && itemsConfig[a?.toLowerCase()])?.toLowerCase()
    const qtyArg = args.find(a => /^\d+$/.test(a))
    const qty = qtyArg ? parseInt(qtyArg) : 1

    if (!target) return m.reply('❌ Tag orang yang mau lu kasih item!\nContoh: `.kirimitem @orangnya ramen 2`')
    if (!itemKey) return m.reply('❌ Sebutin nama itemnya, contoh: `.kirimitem @orangnya ramen 2`')

    const res = tradeItem(m.sender, target, itemKey, qty)
    if (!res.status) {
      if (res.reason === 'item_invalid') return m.reply(`❌ Item *${itemKey}* kaga dikenal.`)
      if (res.reason === 'stok_kurang') return m.reply(`❌ Stok *${res.item?.name || itemKey}* lu kurang.`)
    }

    const text = `🎁 @${m.sender.split('@')[0]} ngasih *${res.qty}x ${res.item.name}* ke @${target.split('@')[0]}.`
    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
