import { useItem, itemsConfig } from '../../lib/rpgDatabase.js'

export default {
  command: 'pakai',
  alias: ['use', 'equip'],
  category: 'rpg',
  description: 'Pakai/makan/equip item dari inventory.',

  async execute(m, { args }) {
    const itemKey = args[0]?.toLowerCase()
    if (!itemKey) return m.reply('❌ Mau pakai apa? Contoh: `.pakai ramen`')

    const item = itemsConfig[itemKey]
    if (!item) return m.reply(`❌ Item *${itemKey}* kaga dikenal.`)

    const res = useItem(m.sender, itemKey)
    if (!res.status) {
      if (res.reason === 'stok_kurang') return m.reply(`❌ Lu kaga punya *${item.name}* di tas.`)
      if (res.reason === 'tidak_bisa_dipakai') return m.reply(`❌ *${item.name}* kaga bisa dipakai kayak gitu.`)
    }

    if (res.effect === 'heal') {
      return m.reply(`🍽️ Lu makan/minum *${item.name}*.\n❤️ HP: +${res.heal} (sekarang ${res.hp})`)
    }
    if (res.effect === 'equip_weapon') {
      return m.reply(`⚔️ *${item.name}* terpasang sebagai senjata lu!`)
    }
    if (res.effect === 'equip_armor') {
      return m.reply(`🛡️ *${item.name}* terpasang sebagai armor lu!`)
    }
    if (res.effect === 'equip_tool') {
      const label = res.slot === 'rod' ? 'pancingan' : 'beliung'
      return m.reply(`🔧 *${item.name}* terpasang jadi ${label} lu!\n\n_Wajib dipasang buat bisa .mancing / .tambang, makin tinggi tier makin gede hasilnya._`)
    }
    if (res.effect === 'buff') {
      const labelMap = {
        attack: `💪 Attack lu naik +${item.value} buat pertarungan berikutnya (hunt/duel).`,
        defense: `🛡️ Defense lu naik +${item.value} buat pertarungan berikutnya (hunt/duel).`,
        xp2x: `📜 XP dari aktivitas berikutnya bakal dikali 2!`,
        luck: `🍀 Peluang menang judi berikutnya naik +${item.value}%.`
      }
      return m.reply(`✨ Lu minum *${item.name}*!\n\n${labelMap[res.buffEffect] || 'Efek diterapkan.'}`)
    }

    return m.reply(`✅ Berhasil pakai *${item.name}*.`)
  }
}
