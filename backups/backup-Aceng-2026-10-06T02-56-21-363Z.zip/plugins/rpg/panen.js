import { panenBisnis } from '../../lib/rpgDatabase.js'

export default {
  command: 'panen',
  alias: ['collect'],
  category: 'rpg',
  description: 'Ambil hasil pendapatan dari bisnismu.',

  async execute(m, { sock }) {
    const hasil = panenBisnis(m.sender)

    if (!hasil.status) {
      if (hasil.reason === 'gembel') {
        return m.reply('❌ Lu mau panen apaan? Bisnis aja kaga punya.\nKetik *.bisnis upgrade* buat buka usaha pake modal pertama lu!')
      }
      if (hasil.reason === 'cepet_banget') {
        return m.reply('belum ada.')
      }
    }

    await sock.sendReact(m.chat, '🤑', m.key).catch(() => {})
    
    await sock.message.send(m.chat, {
      conversation: `*PANEN CUWAN!* \n\nDari usaha *${hasil.tierName}*, lu berhasil narik duit sebesar:\n*+Rp${hasil.dapet.toLocaleString('id-ID')}* \n\n *Total Saldo Lu Sekarang: *Rp${hasil.total.toLocaleString('id-ID')}*`,
      mentions: [m.sender]
    }, { additionalAttributes: { type: "text" } })
  }
}