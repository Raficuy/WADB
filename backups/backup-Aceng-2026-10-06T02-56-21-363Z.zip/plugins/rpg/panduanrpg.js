const SECTIONS = {
  mulai: {
    title: '🚀 MULAI DARI SINI (Alur Bootstrap)',
    body: `RPG di bot ini jalannya berurutan, ikutin aja step ini:

1️⃣ *.tambang* — tangan kosong masih bisa, dapet 2x \`batu\` tiap panen, HP kepotong dikit (regen otomatis 1 HP/1.5 menit)
2️⃣ *.nebang* — selalu bisa tangan kosong, dapet 2x \`kayu_biasa\` tiap panen, cooldown cuma 6 menit
3️⃣ Udah punya cukup \`batu\` + \`kayu_biasa\`? Craft alat pertama lu (murah, cuma butuh 1-2x gathering):
   • *.craft beliung_kayu* (butuh 3 kayu_biasa + 2 batu) → buat tambang lebih efisien
   • *.craft kapak_kayu* (butuh 3 kayu_biasa + 1 batu) → buat nebang lebih efisien
   • *.craft pancingan_kayu* (butuh 3 kayu_biasa + 1 batu) → biar mancing dapet lebih dari ikan teri
   Alat otomatis kepasang begitu jadi, kaga perlu *.pakai* lagi.
4️⃣ Sekarang tambang/nebang/mancing lu jauh lebih hasil. Kumpulin bahan lebih bagus (\`bijih_besi\`, \`kayu_jati\`, dll) buat upgrade alat ke tier 2 & 3.
5️⃣ Sambil ngumpulin bahan, jangan lupa *.kerja* & *.daily* buat modal awal, sama *.bisnis* buat cuan pasif.

_Ketik *.panduanrpg gather* buat detail lengkap sistem tambang/nebang/mancing/craft._`
  },

  gather: {
    title: '⛏️ GATHERING & CRAFTING',
    body: `*.tambang* (alias: .nambang)
> Tanpa \`beliung\` (pickaxe): dapet 2x \`batu\`, HP kepotong dikit (4-6, makin gede di map berisiko). Cooldown 10 menit.
> Dengan \`beliung\`: bisa dapet bijih_besi/bijih_emas/berlian_mentah/meteorit_pecahan, makin tinggi tier makin bagus peluangnya, HP kepotong makin kecil.

*.nebang* (alias: .chop)
> Selalu bisa tangan kosong, dapet 2x kayu_biasa. Cooldown 6 menit.
> Dengan \`kapak\`, bisa dapet kayu_jati/kayu_pohon_tua & jumlah lebih banyak (3x).

*.mancing* (alias: .pancing)
> Tangan kosong tetep bisa, dapet ikan_teri. Cooldown 8 menit.
> Dengan \`pancingan\`, hasil: ikan_teri → ikan_lele → ikan_salmon → ikan_tuna → harta_karun (makin langka makin mahal).

*.craft [nama_resep]*
> Ketik *.craft* tanpa argumen buat liat semua resep yang tersedia.
> Alat tier 1 (kayu) sekarang murah banget, cuma butuh 1-2x hasil gathering buat masing-masing.
> Hasil craft alat/senjata/armor otomatis ke-equip.

*.jual [item] [jumlah]*
> Semua hasil gathering bisa dijual ke toko kalo kaga kepake buat crafting.

💡 *Tips:* pet 🐲 Naga nambahin hasil tambang & nebang. Pet 🐱 Kucing nambahin peluang ikan bagus pas mancing. Cek *.panduanrpg pet* & *.panduanrpg peta*.`
  },

  peta: {
    title: '🗺️ PETA / LOKASI',
    body: `Dunia dibagi jadi beberapa lokasi, tiap lokasi punya spesialisasi gathering yang OP di situ, tapi ada tradeoff stat combat selama lu di sana.

*.peta* — Liat semua lokasi, efeknya, & posisi lu sekarang.
*.peta pergi [lokasi]* — Pindah ke lokasi lain (cooldown 3 menit).

🏙️ *kota* — Base aman, kaga ada bonus/penalti. Default spawn.
⛰️ *gunung* — +22% peluang bijih langka pas *.tambang*, tapi Defense -12 & HP kepake x1.4 pas nambang.
🌳 *hutan* — +22% peluang kayu langka pas *.nebang*, tapi Attack -10.
🌊 *pesisir* (min level 5) — +22% peluang ikan langka pas *.mancing*, tapi Defense -8 & Evasi -10.
🏛️ *reruntuhan* (min level 15) — Loot & XP hunt x1.5, Attack +15, tapi *KAGA BISA* tambang/nebang/mancing sama sekali.
🌋 *puncak_naga* (min level 40) — Zona elite, bonus gathering +35% & loot/XP hunt x2, tapi Defense -35, Evasi -15, & HP kepake x2 pas nambang.

💡 *Tips:* selalu cek *.peta* dulu sebelum gathering/hunt biar dapet lokasi yang paling cocok sama aktivitas lu. Efek stat map kepake juga pas *.duel*/*.rankedduel*/*.raidboss*, jadi mikir dulu sebelum berantem di zona penalti gede kayak puncak_naga.`
  },

  combat: {
    title: '⚔️ COMBAT (PvE & PvP)',
    body: `*.hunt* (alias: .buru)
> Lawan monster random (Slime → Naga Merah). Menang dapet duit + xp, kalah HP berkurang.
> Senjata nambah \`power\` & peluang *crit* (1.5x damage/loot). Armor nambah \`defense\` & peluang *evasion* (ngindarin damage total).
> Monster tier atas kadang drop bahan crafting langka.

*.duel @user [taruhan]*
> Duel biasa, bisa pake taruhan saldo. Skor dihitung dari attack + elemen acak + crit.

*.rankedduel @user* (alias: .arena)
> Duel yang mempengaruhi rating (ELO). Tier: Bronze → Silver → Gold → Platinum → Mythic.
> Cek peringkat: *.leaderboard toprank*.

*.bounty @user [jumlah]*
> Pasang harga kepala orang. Siapapun bisa coba klaim: *.bounty klaim @target* (60% peluang sukses, cooldown 3 jam).

*.raidboss start* / *.raidboss attack*
> Bareng-bareng 1 guild ngelawan boss raksasa (HP 50.000). Reward dibagi sesuai kontribusi damage. Wajib gabung guild dulu.

💡 *Tips:* pakai *.pakai ramuan_kuat* / *ramuan_tahan* sebelum hunt/duel buat buff sekali pakai. Pet 🐶 Anjing nambah attack pas combat. Lokasi lu (*.peta*) juga ngaruh ke Attack/Defense/Evasi pas combat — misal Attack lu naik pas di reruntuhan, tapi Defense ancur pas di puncak_naga.`
  },

  ekonomi: {
    title: '💰 EKONOMI',
    body: `*.daily* — Klaim bonus harian (24 jam sekali).
*.kerja* — Kerja beberapa profesi (ojol/kasir/programmer/nelayan/youtuber), cooldown beda-beda.
*.bisnis* — Upgrade bisnis pasif (level 0-5), makin tinggi makin gede income/jam-nya.
*.panen* — Panen income dari bisnis lu (dihitung dari waktu terakhir panen).
*.bank* / *.nabung [jumlah]* / *.tarik [jumlah]* — Simpen duit di bank, AMAN dari *.rampok*.
*.pinjam [jumlah]* (alias: .utang) — Pinjam ke rentenir, bunga 5%/hari, maks Rp200.000.
*.tagihan* — Cek total hutang + bunga berjalan.
*.bayarhutang [jumlah]* (alias: .lunasin) — Bayar hutang.
*.rampok @user* — Coba rampok saldo tunai orang lain (uang di bank aman). Cooldown 1 jam.
*.transfer @user [jumlah]* — Kirim saldo ke member lain.

💡 *Tips:* selalu nabung ke bank kalo saldo lu udah gede, biar kaga abis dirampok.`
  },

  item: {
    title: '🎒 ITEM, SHOP & INVENTORY',
    body: `*.shop* / *.pasar* — Liat & beli barang. Ketik *.shop beli [item] [jumlah]*.
> Item craft-only (alat) & gather-only (bahan mentah) *KAGA MUNCUL* di shop — cari sendiri lewat gathering/crafting.

*.inventory* (alias: .inv, .tas) — Liat isi tas & alat yang lagi kepasang.
*.pakai [item]* — Makan/minum potion, equip senjata/armor/alat, atau pakai buff.
*.jual [item] [jumlah]* — Jual item ke toko.
*.kirimitem @user [item] [jumlah]* — Kasih item ke member lain.
*.craft [resep]* — Rakit item dari bahan (lihat *.panduanrpg gather*).
*.blackmarket* (alias: .bm) — Pasar gelap, stok & diskon acak, reset tiap hari.

*Jenis Buff (sekali pakai, dari .pakai):*
> ramuan_kuat/ramuan_tahan — buff attack/defense buat pertarungan berikutnya.
> scroll_xp — XP aktivitas berikutnya dikali 2.
> jimat_hoki — nambah peluang menang judi berikutnya.`
  },

  sosial: {
    title: '🤝 SOSIAL & GUILD',
    body: `*.nikah @user* — Nikah (butuh item \`cincin_nikah\`, beli di shop). *.cerai* buat pisah.
*.guild create [nama]* — Bikin guild (biaya Rp50.000).
*.guild join [id]* — Gabung guild.
*.guild leave* — Keluar guild.
*.guild kontribusi [jumlah]* — Nyumbang ke bank guild (nambah level guild).
*.guild* (tanpa argumen) — Liat info guild lu.
*.raidboss* — Raid boss bareng guild (lihat *.panduanrpg combat*).
*.leaderboard topguild* — Peringkat guild terkaya.`
  },

  lain: {
    title: '✨ LAIN-LAIN',
    body: `*.quest* — Quest harian (reset tiap hari, 3 quest random).
*.quest klaim [id]* — Klaim reward quest yang udah kelar.
*.achievement* (alias: .pencapaian) — Cek pencapaian yang udah/belum kebuka.
*.title* (alias: .gelar) — Liat & pasang title/gelar (*.title set [id]*).
*.prestige* — Reset level demi bonus permanen (butuh level 50+).
*.pet* — Adopsi & rawat pet (lihat *.panduanrpg gather* & *.panduanrpg combat*).
*.kebun* / *.tanam [benih]* / *.panenkebun* — Farming, tanam benih tunggu waktu, lalu panen.
*.koin [angka/gambar] [jumlah]* & *.slot [jumlah]* — Judi.
*.leaderboard* / *.top* / *.toprank* / *.topguild* — Papan peringkat.
*.stat* (alias: .me) — Cek profil RPG lu.`
  }
}

const ORDER = ['mulai', 'gather', 'peta', 'combat', 'ekonomi', 'item', 'sosial', 'lain']

export default {
  command: 'panduanrpg',
  alias: ['guiderpg', 'rpghelp', 'cararpg'],
  category: 'rpg',
  description: 'Panduan lengkap semua fitur RPG biar kaga bingung mulai dari mana.',

  async execute(m, { args }) {
    const arg = args[0]?.toLowerCase()

    if (!arg) {
      let text = `📖 *PANDUAN RPG* 📖\n\n_Sistemnya lumayan banyak, jadi dibagi per topik. Ketik salah satu ini:_\n\n`
      for (const key of ORDER) {
        text += `🔸 *.panduanrpg ${key}* - ${SECTIONS[key].title}\n`
      }
      text += `\n💡 Kalo baru mulai main, ketik *.panduanrpg mulai* dulu buat tau alur awalnya.`
      return m.reply(text)
    }

    const section = SECTIONS[arg]
    if (!section) {
      return m.reply(`❌ Topik *${arg}* kaga ada.\n\nTopik yang tersedia: ${ORDER.map(k => `\`${k}\``).join(', ')}\n\nKetik *.panduanrpg* buat liat daftar lengkap.`)
    }

    return m.reply(`${section.title}\n\n${section.body}`)
  }
}
