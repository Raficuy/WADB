import { rankedDuel } from '../../lib/rpgDatabase.js'

export default {
  command: 'rankedduel',
  alias: ['ranked', 'arena'],
  category: 'rpg',
  description: 'Duel ranked, rating naik/turun kayak MMR.',
  groupOnly: true,

  async execute(m, { sock }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender
    if (!target) return m.reply('❌ Tag lawan ranked duel lu!\nContoh: `.rankedduel @orangnya`')
    if (target === m.sender) return m.reply('❌ Duel sama diri sendiri? Aneh.')

    const res = rankedDuel(m.sender, target)

    await sock.sendReact(m.chat, '🏅', m.key).catch(() => {})

    const text = `🏅 *RANKED DUEL!* 🏅\n\n🏆 Pemenang: @${res.winnerJid.split('@')[0]}\n   Rating: ${res.winnerRating} (${res.winnerTier}) [+${res.delta}]\n\n💔 Kalah: @${res.loserJid.split('@')[0]}\n   Rating: ${res.loserRating} (${res.loserTier}) [-${res.delta}]`

    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
