import { kerja, jobConfig, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'kerja',
  alias: ['work'],
  category: 'rpg',
  description: 'Kerja buat nyari duit halal.',

  async execute(m, { sock, args }) {
    const jobKey = args[0]?.toLowerCase()

    if (!jobKey) {
      let list = `💼 *DAFTAR PEKERJAAN* 💼\n_Ketik .kerja [nama_kerjaan]_\n\n`
      jobConfig.forEach(j => {
        list += `🔹 *${j.key}*\n   (${j.name}) | Gaji: ${j.minIncome}-${j.maxIncome}\n`
      })
      return m.reply(list)
    }

    const hasil = kerja(m.sender, jobKey)

    if (!hasil.status) {
      if (hasil.reason === 'job_invalid') return m.reply(`❌ Kerjaan *${jobKey}* kaga ada! Ketik .kerja buat liat list.`)
      if (hasil.reason === 'cooldown') return m.reply(`⏳ Lu masih capek! Istirahat dulu selama *${fmtTime(hasil.timeLeft)}* sebelum kerja lagi.`)
    }

    let text = `💼 *KERJA BERHASIL* 💼\n\n`
    text += `Lu baru aja kerja sebagai *${hasil.job.name}* dan dibayar:\n`
    text += `💰 +Rp${hasil.income.toLocaleString('id-ID')}\n`
    text += `✨ +XP ${hasil.xpResult.levelUps.length > 0 ? '(🎉 NAIK LEVEL!)' : ''}\n\n`
    text += `💳 Total Uang: Rp${hasil.balance.toLocaleString('id-ID')}`
try {
      return await sock.sendThumbnail(m.chat, {
        url: 'https://github.com/',
        title: 'RPG SHOP',
        body: 'Lihat item di bawah',
        text,
        thumbnail: 'https://d.tmpfile.link/public/2026-09-27/8bb920e7-5436-4976-87cc-7d34bb0cd785/file_1790520341274.jpeg',
        quote: m
      })
    } catch (err) {
      console.error('[shop sendThumbnail]', err)
      return m.reply(text)
    }
  }
}