import { rampokUser } from '../../lib/rpgDatabase.js'

export default {
  command: 'rampok',
  alias: ['begal', 'curi', 'rob'],
  category: 'rpg',
  description: 'Rampok duit member lain. Resiko ditanggung penumpang.',
  groupOnly: true,

  async execute(m, { sock }) {
    // Cari siapa yang di-tag atau di-reply
    const target = m.mentionedJid?.[0] || m.quoted?.sender
    
    if (!target) return m.reply('❌ Tag orang yang mau lu rampok!\nContoh: `.rampok @orangnya`')
    if (target === m.sender) return m.reply('❌ Stres lu? Masa ngerampok diri sendiri.')
    
    const botJid = sock.user?.id?.split(':')[0] + '@s.whatsapp.net' || ''
    if (target === botJid) return m.reply('❌ Berani lu ngerampok bandar?!')

    // Eksekusi data ke database
    const hasil = rampokUser(m.sender, target)

    // Handle Kalo Gagal Eksekusi
    if (!hasil.status) {
      if (hasil.reason === 'cooldown') {
        const mins = Math.floor(hasil.timeLeft / (1000 * 60))
        return m.reply(`⏳ *Buronan Polisi!*\nLu baru aja beraksi. Sembunyi dulu selama *${mins} menit* sebelum ngerampok lagi.`)
      }
      if (hasil.reason === 'modal_kurang') return m.reply('❌ Saldo lu di bawah Rp5.000! Kalo ketangkep lu mau bayar rumah sakit pake daun? Ngumpulin modal dulu sana.')
      if (hasil.reason === 'korban_miskin') return m.reply('❌ Targetnya gembel! Saldonya di bawah Rp5.000. Kasihanilah orang miskin, cari target lain.')
    }

    const tagPelaku = `@${m.sender.split('@')[0]}`
    const tagKorban = `@${target.split('@')[0]}`

    // Handle Tampilan Berhasil / Babak Belur
    if (hasil.isSuccess) {
      await sock.sendReact(m.chat, '🥷', m.key).catch(() => {})
      const text = `💰 *PERAMPOKAN BERHASIL!* 💰\n\n${tagPelaku} baru aja ngebegal ${tagKorban} di gang gelap!\n\n💸 *Hasil Rampokan:* +Rp${hasil.amount.toLocaleString('id-ID')}\n💳 *Sisa Uang Korban:* Rp${hasil.korbanBal.toLocaleString('id-ID')}\n\n_Korban menangis di pojokan..._`
      
      return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: "text" } })
    } else {
      await sock.sendReact(m.chat, '🚓', m.key).catch(() => {})
      const text = `🚨 *PERAMPOKAN GAGAL!* 🚨\n\n${tagPelaku} nyoba ngebegal ${tagKorban}, tapi korbannya jago silat!\nPelaku digebukin warga sampe babak belur.\n\n💸 *Biaya Rumah Sakit:* -Rp${hasil.amount.toLocaleString('id-ID')}\n💳 *Sisa Uang Pelaku:* Rp${hasil.pelakuBal.toLocaleString('id-ID')}\n\n_Mampus lu, makanya kerja halal aja._`
      
      return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: "text" } })
    }
  }
}