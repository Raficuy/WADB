import { mancing, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'mancing',
  alias: ['fishing', 'pancing'],
  category: 'rpg',
  description: 'Mancing ikan, tangan kosong bisa (dapet ikan teri doang), pancingan bikin hasilnya jauh lebih bagus.',

  async execute(m) {
    const res = mancing(m.sender)

    if (!res.status) {
      if (res.reason === 'cooldown') return m.reply(`⏳ Kailnya belum siap lagi! Tunggu *${fmtTime(res.timeLeft)}*.`)
      if (res.reason === 'map_terlarang') return m.reply(`❌ Kaga bisa mancing di *${res.map.name}*, medannya kaga cocok. Balik ke laut/kota dulu pake \`.peta pergi\`.`)
    }

    let text = `🎣 *MANCING BERHASIL!*${res.hasRod ? ` (Pancingan Tier ${res.rodTier})` : ' (tangan kosong)'}\n\nLu dapet *${res.qty}x ${res.fish.name}* (${res.rarity})!`
    if (res.petBonus) text += `\n🐱 Kucing lu bantu nemuin ikan tambahan!`
    if (res.mapBonusActive) text += `\n🌊 *${res.map.name}* nambah peluang tangkepan bagus!`
    if (!res.hasRod) {
      text += `\n\n_Mancing tangan kosong cuma bisa dapet ikan teri. Craft *.craft pancingan_kayu* (butuh 3 kayu_biasa + 1 batu) biar bisa dapet ikan yang lebih bagus!_`
    } else {
      text += `\n\n_Ketik *.jual ${res.fishKey}* buat dijual, atau simpen buat crafting._`
    }

    return m.reply(text)
  }
}
