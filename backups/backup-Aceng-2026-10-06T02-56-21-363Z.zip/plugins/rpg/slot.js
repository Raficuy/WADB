import { slotMachine } from '../../lib/rpgDatabase.js'

export default {
  command: 'slot',
  alias: ['gacor'],
  category: 'rpg',
  description: 'Main mesin slot, siapa tau gacor.',

  async execute(m, { args }) {
    const amount = parseInt(args[0])
    if (!amount) return m.reply('❌ Contoh: `.slot 10000`')

    const res = slotMachine(m.sender, amount)
    if (!res.status) return m.reply('❌ Saldo lu kurang buat main segitu.')

    const tampilan = `[ ${res.slot.join(' | ')} ]`

    if (res.win) {
      return m.reply(`🎰 ${tampilan}\n🎉 *JACKPOT!* Kalikan x${res.multiplier}!\n+Rp${(res.hasil - amount).toLocaleString('id-ID')}\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    } else {
      return m.reply(`🎰 ${tampilan}\n😭 Kaga cocok. -Rp${amount.toLocaleString('id-ID')}\n💳 Saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }
  }
}
