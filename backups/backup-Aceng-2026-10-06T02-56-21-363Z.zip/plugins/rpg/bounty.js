import { getUser, pasangBounty, klaimBounty, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'bounty',
  alias: ['buronan'],
  category: 'rpg',
  description: 'Pasang harga kepala orang, atau klaim bounty target.',
  groupOnly: true,

  async execute(m, { sock, args }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender

    if (args[0] === 'klaim' || args[0] === 'claim') {
      if (!target) return m.reply('❌ Tag target yang mau lu klaim bounty-nya!\nContoh: `.bounty klaim @orangnya`')

      const res = klaimBounty(m.sender, target)
      if (!res.status) {
        if (res.reason === 'tidak_ada_bounty') return m.reply('❌ Target itu kaga ada bounty-nya.')
        if (res.reason === 'cooldown') return m.reply(`⏳ Lu masih cooldown *${fmtTime(res.timeLeft)}* buat klaim bounty lagi.`)
      }

      if (res.win) {
        return m.reply(`🎯 *BOUNTY BERHASIL DIKLAIM!*\n\n+Rp${res.dapet.toLocaleString('id-ID')} dari kepala @${target.split('@')[0]}!`)
      } else {
        return m.reply(`💨 Target berhasil kabur. Bounty masih nangkring, coba lagi nanti.`)
      }
    }

    if (!target) return m.reply('❌ Tag orang yang mau lu pasang bounty!\nContoh: `.bounty @orangnya 20000`')

    const amount = parseInt(args.find(a => /^\d+$/.test(a)))
    if (!amount) return m.reply('❌ Sebutin nominalnya! Contoh: `.bounty @orangnya 20000`')

    const res = pasangBounty(m.sender, target, amount)
    if (!res.status) return m.reply('❌ Saldo lu kurang buat masang bounty segitu.')

    const text = `🎯 *BOUNTY DIPASANG!*\n\n@${m.sender.split('@')[0]} masang harga kepala @${target.split('@')[0]} sebesar Rp${amount.toLocaleString('id-ID')}!\n💰 Total Bounty Sekarang: Rp${res.totalBounty.toLocaleString('id-ID')}\n\n_Siapapun bisa klaim pake .bounty klaim @${target.split('@')[0]}_`

    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
