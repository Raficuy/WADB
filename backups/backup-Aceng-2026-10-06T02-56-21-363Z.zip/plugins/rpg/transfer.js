import { transferBalance } from '../../lib/rpgDatabase.js'

export default {
  command: 'transfer',
  alias: ['tf', 'kirimduit'],
  category: 'rpg',
  description: 'Kirim saldo ke member lain.',
  groupOnly: true,

  async execute(m, { sock, args }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender
    const amount = parseInt(args.find(a => /^\d+$/.test(a)))

    if (!target) return m.reply('❌ Tag orang yang mau lu kirimin duit!\nContoh: `.transfer @orangnya 10000`')
    if (target === m.sender) return m.reply('❌ Ngapain transfer ke diri sendiri.')
    if (!amount || isNaN(amount)) return m.reply('❌ Masukin nominalnya! Contoh: `.transfer @orangnya 10000`')

    const res = transferBalance(m.sender, target, amount)
    if (!res.status) {
      if (res.reason === 'saldo_kurang') return m.reply('❌ Saldo lu kurang buat kirim segitu.')
      if (res.reason === 'jumlah_invalid') return m.reply('❌ Nominal kaga valid.')
    }

    const text = `💸 *TRANSFER BERHASIL*\n\n@${m.sender.split('@')[0]} ngirim Rp${amount.toLocaleString('id-ID')} ke @${target.split('@')[0]}.`
    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
