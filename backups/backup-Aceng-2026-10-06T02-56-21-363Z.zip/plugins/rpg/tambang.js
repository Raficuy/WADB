import { menambang, fmtTime } from '../../lib/rpgDatabase.js'

export default {
  command: 'tambang',
  alias: ['mining', 'nambang'],
  category: 'rpg',
  description: 'Nambang batu/bijih/berlian, tangan kosong bisa tapi lebih pegel & cuma dapet batu.',

  async execute(m) {
    const res = menambang(m.sender)

    if (!res.status) {
      if (res.reason === 'cooldown') return m.reply(`⏳ Kapak lu masih tumpul! Tunggu *${fmtTime(res.timeLeft)}*.`)
      if (res.reason === 'hp_kurang') return m.reply(`❌ HP lu kritis (${res.hp})! Istirahat/makan dulu sebelum nambang.`)
      if (res.reason === 'map_terlarang') return m.reply(`❌ Kaga bisa nambang di *${res.map.name}*, medannya kaga cocok. Balik ke gunung/kota dulu pake \`.peta pergi\`.`)
    }

    let text = `⛏️ *NAMBANG BERHASIL!*${res.hasPickaxe ? '' : ' (tangan kosong)'}\n\nLu dapet *${res.qty}x ${res.ore.name}* (${res.rarity})!\n❤️ HP: ${res.hp}`
    if (res.mapBonusActive) text += `\n⛰️ *${res.map.name}* nambah peluang bijih langka! (tapi HP kepake lebih banyak)`
    if (!res.hasPickaxe) {
      text += `\n\n_Nambang tangan kosong cuma bisa dapet batu & lebih makan HP. Craft *.craft beliung_kayu* (butuh 3 kayu_biasa + 2 batu) biar hasilnya lebih bagus!_`
    } else {
      text += `\n\n_Ketik *.jual ${res.oreKey}* buat dijual, atau simpen buat crafting._`
    }

    return m.reply(text)
  }
}
