import { duelUser } from '../../lib/rpgDatabase.js'

export default {
  command: 'duel',
  alias: ['tarung'],
  category: 'rpg',
  description: 'Duel PvP lawan member lain, bisa pake taruhan.',
  groupOnly: true,

  async execute(m, { sock, args }) {
    const target = m.mentionedJid?.[0] || m.quoted?.sender
    const taruhan = parseInt(args.find(a => /^\d+$/.test(a))) || 0

    if (!target) return m.reply('❌ Tag lawan duel lu!\nContoh: `.duel @orangnya 10000`')
    if (target === m.sender) return m.reply('❌ Duel sama diri sendiri? Aneh.')

    const res = duelUser(m.sender, target, taruhan)
    if (!res.status) {
      if (res.reason === 'saldo_a_kurang') return m.reply('❌ Saldo lu kurang buat taruhan segitu.')
      if (res.reason === 'saldo_b_kurang') return m.reply('❌ Saldo lawan kurang buat taruhan segitu.')
    }

    await sock.sendReact(m.chat, '⚔️', m.key).catch(() => {})

    const critText = (res.critA ? `💥 @${m.sender.split('@')[0]} CRITICAL HIT!\n` : '') + (res.critB ? `💥 @${target.split('@')[0]} CRITICAL HIT!\n` : '')
    const text = `⚔️ *DUEL!* ⚔️\n\n${critText}@${m.sender.split('@')[0]} (skor ${res.scoreA}) VS @${target.split('@')[0]} (skor ${res.scoreB})\n\n🏆 Pemenang: @${res.winnerJid.split('@')[0]}!${taruhan > 0 ? `\n💰 Menang Rp${taruhan.toLocaleString('id-ID')} dari taruhan.` : ''}`

    return sock.message.send(m.chat, { text, mentions: [m.sender, target] }, { additionalAttributes: { type: 'text' } })
  }
}
