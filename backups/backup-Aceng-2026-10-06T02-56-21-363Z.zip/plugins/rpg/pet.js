import { getUser, petConfig, adoptPet, feedPet } from '../../lib/rpgDatabase.js'

export default {
  command: 'pet',
  alias: ['hewan', 'adopt'],
  category: 'rpg',
  description: 'Adopsi & rawat pet, tiap pet punya spesialisasi beda (mancing/combat/gather).',

  async execute(m, { args }) {
    const sub = args[0]?.toLowerCase()

    if (sub === 'adopsi' || sub === 'adopt') {
      const petKey = args[1]?.toLowerCase()
      if (!petKey) {
        let text = `🐾 *DAFTAR PET*\n_Ketik .pet adopsi [nama]_\n\n`
        for (const [key, p] of Object.entries(petConfig)) {
          text += `🔹 *${key}* - ${p.name} (Rp${p.price.toLocaleString('id-ID')})\n   ${p.desc}\n\n`
        }
        return m.reply(text)
      }

      const res = adoptPet(m.sender, petKey)
      if (!res.status) {
        if (res.reason === 'pet_invalid') return m.reply(`❌ Pet *${petKey}* kaga ada.`)
        if (res.reason === 'sudah_punya_pet') return m.reply('❌ Lu udah punya pet! Sayangi dulu yang sekarang.')
        if (res.reason === 'saldo_kurang') return m.reply('❌ Saldo lu kurang buat adopsi pet ini.')
      }

      return m.reply(`🎉 Lu berhasil adopsi *${res.pet.name}*!\n${res.pet.desc}\n💳 Sisa saldo: Rp${res.balance.toLocaleString('id-ID')}`)
    }

    if (sub === 'makan' || sub === 'feed') {
      const res = feedPet(m.sender)
      if (!res.status) {
        if (res.reason === 'tidak_punya_pet') return m.reply('❌ Lu belum punya pet. Ketik `.pet adopsi` dulu.')
        if (res.reason === 'umpan_kosong') return m.reply('❌ Umpan hewan lu abis. Beli di `.shop beli umpan_pet`.')
      }
      return m.reply(`🍖 Lu kasih makan *${res.pet.name}*. Dia makin sayang sama lu!`)
    }

    const user = getUser(m.sender)
    if (!user.pet) return m.reply('🐾 Lu belum punya pet. Ketik `.pet adopsi` buat liat daftar pet.')

    const pet = petConfig[user.pet]
    const specialtyLabel = { mancing: '🎣 Mancing', combat: '⚔️ Hunt/Duel', gather: '⛏️ Tambang/Nebang' }
    return m.reply(`🐾 *PET LU*\n\nNama: ${pet.name}\nSpesialisasi: ${specialtyLabel[pet.specialty]}\nBonus: +${pet.bonus}\n${pet.desc}\n\n_Ketik *.pet makan* buat kasih makan (butuh umpan_pet)._`)
  }
}
