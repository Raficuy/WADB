// plugins/grup/setwelcome.js
import { handleSetCommand } from '../../lib/welcome.js'

export default {
  command: 'setwelcome',
  alias: ['welcome'],
  category: 'grup',
  description: `> Mengatur pesan sambutan untuk member baru di grup ini. Dikirim berupa kartu gambar (link preview) yang dibuat otomatis.

*Variabel teks:*
\`{user}\` = mention member
\`{name}\` = nama member
\`{group}\` = nama grup
\`{count}\` = jumlah member
\`{desc}\` = deskripsi grup

contoh penggunaan:
\`.setwelcome\` (lihat pengaturan)
\`.setwelcome on\` / \`.setwelcome off\`
\`.setwelcome Halo {user}, selamat datang di {group}!\`
\`.setwelcome reset\`
\`.setwelcome test\`

*Catatan:*
> hanya bisa digunakan admin grup.`,
  help: '<on/off/reset/test/teks>',
  onlyGroup: true,
  onlyAdmin: true,

  async execute(m, ctx) {
    return handleSetCommand('welcome', m, ctx)
  }
}
