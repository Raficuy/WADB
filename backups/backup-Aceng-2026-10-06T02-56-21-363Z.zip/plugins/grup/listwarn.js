// plugins/grup/listwarn.js
import { parseTargetAndReason, getWarnLimit, numberOf } from '../../lib/warn.js'
import { listWarned, getWarns } from '../../db/warn.js'

const fmtDate = (unix) => new Date(unix * 1000).toLocaleString('id-ID', {
  timeZone: 'Asia/Jakarta',
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit'
})

export default {
  command: 'listwarn',
  alias: ['warnlist', 'cekwarn', 'daftarwarn'],
  category: 'grup',
  description: `> Melihat daftar member yang punya warn, atau detail warn satu member.

*Format:*
> \`.listwarn\` (semua member yang punya warn)
> \`.listwarn @mention\` (detail satu member)
> \`.listwarn\` (reply pesan)`,
  help: '(@mention/reply)',
  onlyGroup: true,

  async execute(m, { args }) {
    const limit = getWarnLimit(m.chat)
    const { target } = parseTargetAndReason(m, args)

    // detail satu member
    if (target) {
      const rows = getWarns(m.chat, target)
      if (!rows.length) {
        return m.reply(m.chat, `@${numberOf(target)} tidak punya warn.`, { mentions: [target] })
      }
      const mentions = [target]
      const lines = rows.map((r, i) => {
        if (r.warned_by) mentions.push(r.warned_by)
        const by = r.warned_by ? ` oleh @${numberOf(r.warned_by)}` : ''
        return `${i + 1}. ${r.reason || 'Tidak disebutkan'}\n    _${fmtDate(r.created_at)}${by}_`
      })
      return m.reply(m.chat,
        `⚠️ *WARN @${numberOf(target)}* (${rows.length}/${limit})\n\n${lines.join('\n')}`,
        { mentions })
    }

    // semua member
    const rows = listWarned(m.chat)
    if (!rows.length) return m.reply('Belum ada member yang punya warn di grup ini ✅')

    const list = rows.slice(0, 30)
    const text =
      `⚠️ *DAFTAR WARN* (batas ${limit}x)\n\n` +
      list.map((r, i) => `${i + 1}. @${numberOf(r.jid_user)} — *${r.total}/${limit}*`).join('\n') +
      (rows.length > list.length ? `\n\n_...dan ${rows.length - list.length} lainnya_` : '')

    return m.reply(m.chat, text, { mentions: list.map(r => r.jid_user) })
  }
}