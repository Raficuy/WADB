// plugins/grup/warn.js
import { giveWarn, parseTargetAndReason } from '../../lib/warn.js'

export default {
  command: 'warn',
  alias: ['peringatan'],
  category: 'grup',
  description: `> Memberi peringatan (warn) ke member. Jika warn mencapai batas (bawaan 3x, atur lewat \`.setwarn\`), member otomatis dikeluarkan dari grup.

*Format:*
> \`.warn @mention <alasan>\`
> \`.warn <alasan>\` (reply pesan)

*Catatan:*
> hanya bisa digunakan admin grup.
> admin dan bot tidak bisa di-warn.`,
  help: '(@mention/reply) <alasan>',
  onlyGroup: true,
  onlyAdmin: true,
  typing: true,

  async execute(m, { sock, args }) {
    const { target, reason } = parseTargetAndReason(m, args)
    if (!target) {
      return m.reply(`Format Salah!\nContoh pakai:\n> ${m.prefix}${m.command} @mention spam link\n\natau reply:\n> ${m.prefix}${m.command} spam link`)
    }
    return giveWarn(m, sock, target, reason)
  }
}