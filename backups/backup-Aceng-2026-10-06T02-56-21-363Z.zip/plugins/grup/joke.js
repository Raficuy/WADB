import axios from 'axios';

export default {
  command: 'joke',
  alias: ['lawak', 'lelucon'],
  category: 'fun',
  description: 'Mengirimkan lelucon acak.',
  async execute(m, { sock }) {
    try {
      const res = await axios.get('https://icanhazdadjoke.com/', {
        headers: { 'Accept': 'application/json' }
      });
      const joke = res.data.joke;
      return m.reply(`${joke}`);
    } catch (err) {
      console.error(err);
      return m.reply('Gagal.');
    }
  }
}