// plugins/grup/wrapped.js

import { config } from '../../settings.js'
import {
  getMessageCountInRange,
  getDistinctSenderCountInRange,
  getTopActiveInRange,
  getSenderRankInRange,
  getHourlyActivityInRange,
  getDailyActivityInRange,
  getTextsInRange,
  getEarliestTimestamp,
  getLatestPushName
} from '../../db/rawMessage.js'
import { getGroupMetadata } from '../../db/groupCache.js'
import { getTopWords } from '../../lib/wordFrequency.js'
import { renderGroupWrappedCard, renderPersonalWrappedCard } from '../../lib/wrappedCard.js'

const HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']
const TARGET_URL = 'https://chat.whatsapp.com'

async function sendWrappedCard(sock, m, chat, buffer, { title, description, caption, mentions = [] }) {
  try {
    const meta = await sock.uploadThumbnail(buffer)

    return await sock.message.send(chat, {
      extendedTextMessage: {
        title,
        description,
        text: `${TARGET_URL}\n\n${caption}`,
        matchedText: TARGET_URL,
        previewType: 0,
        inviteLinkGroupTypeV2: 0,
        ...meta
      }
    }, { mentions })
  } catch (err) {
    console.error('[WRAPPED] gagal upload thumbnail, fallback ke foto biasa:', err?.message || err)
    try {
      return await sock.message.send(chat, {
        type: 'image',
        media: buffer,
        mimetype: 'image/png',
        caption,
        mentions
      }, { additionalAttributes: { type: 'text' } })
    } catch (err2) {
      console.error('[WRAPPED] gagal kirim foto juga, fallback teks:', err2?.message || err2)
      return m.reply(caption)
    }
  }
}

function formatDateLabel(dateStr) {
  const [y, mo, d] = dateStr.split('-').map(Number)
  const dow = new Date(Date.UTC(y, mo - 1, d)).getUTCDay()
  return `${HARI[dow]}, ${d} ${BULAN[mo - 1]} ${y}`
}

function resolveSince(args) {
  const allIdx = args.findIndex(a => a?.toLowerCase() === 'all' || a?.toLowerCase() === 'semua')
  if (allIdx !== -1) return { mode: 'all', label: 'Sepanjang Waktu Tercatat' }

  const numArg = args.find(a => /^\d+$/.test(a))
  const days = numArg ? Math.min(365, Math.max(1, parseInt(numArg))) : 30
  return { mode: 'days', days, label: `${days} Hari Terakhir` }
}

export default {
  command: 'wrapped',
  alias: ['groupwrapped', 'rekap'],
  category: 'grup',
  description: `> Rekap ala Spotify Wrapped: member paling aktif, jam paling ramai, kata favorit, dan hari paling rame di grup.

*Keterangan Format:*
> \`.wrapped\` = rekap grup, 30 hari terakhir (default).
> \`.wrapped [jumlah_hari]\` = rekap grup custom rentang hari.
> \`.wrapped all\` = rekap grup sepanjang waktu tercatat.
> \`.wrapped @user\` = rekap pribadi 1 orang, 30 hari terakhir.
> \`.wrapped @user [jumlah_hari]\` = rekap pribadi custom rentang hari.

contoh penggunaan:
> \`.wrapped\`
> \`.wrapped 90\`
> \`.wrapped all\`
> \`.wrapped @orangnya\`
> \`.wrapped @orangnya 7\``,
  help: '[@user] [hari|all]',
  groupOnly: true,
  wait: true,
  typing: true,

  async execute(m, { sock, args }) {
    const chat = m.chat
    const target = m.mentionedJid?.[0] || (m.quoted?.sender && !m.quoted.sender.endsWith('@g.us') ? m.quoted.sender : null)

    const { mode, days, label } = resolveSince(args)
    let sinceTs
    if (mode === 'all') {
      sinceTs = getEarliestTimestamp(chat) ?? Math.floor(Date.now() / 1000)
    } else {
      sinceTs = Math.floor(Date.now() / 1000) - days * 24 * 60 * 60
    }

    try {
      if (target) {

        const totalMessages = getMessageCountInRange(chat, sinceTs, target)

        if (totalMessages === 0) {
          return m.reply(`❌ @${target.split('@')[0]} belum punya pesan tercatat di rentang waktu ini.`)
        }

        const rankInfo = getSenderRankInRange(chat, sinceTs, target)
        const hourlyRows = getHourlyActivityInRange(chat, sinceTs, target)
        const dailyRows = getDailyActivityInRange(chat, sinceTs, target)
        const texts = getTextsInRange(chat, sinceTs, target, 5000)
        const [topWord] = getTopWords(texts, 1)

        let name = getLatestPushName(chat, target) || target.split('@')[0]
        try {
          const metadata = await getGroupMetadata(chat, sock)
          const participant = metadata?.participants?.find(p => p.jid === target)
          if (participant?.displayName) name = participant.displayName
        } catch { }

        let avatarBuffer = null
        try {
          const pp = await sock.profile.getProfilePicture(target, 'image')
          if (pp?.url) {
            const res = await fetch(pp.url)
            if (res.ok) avatarBuffer = Buffer.from(await res.arrayBuffer())
          }
        } catch { }

        const buffer = await renderPersonalWrappedCard({
          name,
          avatarBuffer,
          periodLabel: label,
          totalMessages,
          rank: rankInfo?.rank || null,
          totalSenders: rankInfo?.totalSenders || 1,
          favoriteHour: hourlyRows[0] ? { hour: hourlyRows[0].hour, count: hourlyRows[0].total } : null,
          topWord: topWord || null,
          busiestDay: dailyRows[0] ? { dateLabel: formatDateLabel(dailyRows[0].date), count: dailyRows[0].total } : null,
          botName: config.botName
        })

        return sendWrappedCard(sock, m, chat, buffer, {
          title: `Rangkuman • ${name}`,
          description: `${label} • ${totalMessages.toLocaleString('id-ID')} pesan dikirim`,
          caption: `* *Rekap* buat @${target.split('@')[0]} — ${label.toLowerCase()}`,
          mentions: [target]
        })
      }

      const totalMessages = getMessageCountInRange(chat, sinceTs)

      if (totalMessages === 0) {
        return m.reply('❌ Belum ada pesan tercatat di grup ini buat direkap.')
      }

      const totalMembers = getDistinctSenderCountInRange(chat, sinceTs)
      const [topActiveRow] = getTopActiveInRange(chat, sinceTs, 1)
      const hourlyRows = getHourlyActivityInRange(chat, sinceTs)
      const dailyRows = getDailyActivityInRange(chat, sinceTs)
      const texts = getTextsInRange(chat, sinceTs, null, 5000)
      const [topWord] = getTopWords(texts, 1)

      let groupName = 'Grup Ini'
      try {
        const metadata = await getGroupMetadata(chat, sock)
        if (metadata?.subject) groupName = metadata.subject
      } catch { }

      let topActiveName = null
      if (topActiveRow) {
        topActiveName = topActiveRow.push_name || topActiveRow.sender_jid.split('@')[0]
      }

      const buffer = await renderGroupWrappedCard({
        groupName,
        periodLabel: label,
        totalMessages,
        totalMembers,
        topActive: topActiveRow ? { name: topActiveName, count: topActiveRow.total } : null,
        busiestHour: hourlyRows[0] ? { hour: hourlyRows[0].hour, count: hourlyRows[0].total } : null,
        topWord: topWord || null,
        busiestDay: dailyRows[0] ? { dateLabel: formatDateLabel(dailyRows[0].date), count: dailyRows[0].total } : null,
        botName: config.botName
      })

      return sendWrappedCard(sock, m, chat, buffer, {
        title: `${groupName} Rekap`,
        description: `${label} • ${totalMessages.toLocaleString('id-ID')} pesan dari ${totalMembers} orang`,
        caption: `*${groupName} Rekao* — ${label.toLowerCase()}`,
        mentions: []
      })

    } catch (err) {
      console.error('[WRAPPED] error:', err?.stack || err?.message || err)
      return m.reply(`❌ Gagal bikin kartu wrapped: ${err?.message || 'terjadi kesalahan.'}`)
    }
  }
}