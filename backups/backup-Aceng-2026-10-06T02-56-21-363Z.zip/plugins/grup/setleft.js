// plugins/grup/setleft.js
import { handleSetCommand } from '../../lib/welcome.js'

export default {
  command: 'setleft',
  alias: ['left', 'setbye', 'setgoodbye'],
  category: 'grup',
  description: `> Mengatur pesan perpisahan saat member keluar / dikeluarkan dari grup ini. Dikirim berupa kartu gambar (link preview) yang dibuat otomatis.

*Variabel teks:*
\`{user}\` = mention member
\`{name}\` = nama member
\`{group}\` = nama grup
\`{count}\` = jumlah member
\`{desc}\` = deskripsi grup

contoh penggunaan:
\`.setleft\` (lihat pengaturan)
\`.setleft on\` / \`.setleft off\`
\`.setleft Yah {user} keluar dari {group} 😢\`
\`.setleft reset\`
\`.setleft test\`

*Catatan:*
> hanya bisa digunakan admin grup.`,
  help: '<on/off/reset/test/teks>',
  onlyGroup: true,
  onlyAdmin: true,

  async execute(m, ctx) {
    return handleSetCommand('left', m, ctx)
  }
}
