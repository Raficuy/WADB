// plugins/grup/unwarn.js
import { parseTargetAndReason, getWarnLimit, numberOf } from '../../lib/warn.js'
import { removeLastWarn } from '../../db/warn.js'

export default {
  command: 'unwarn',
  alias: ['delwarn', 'kurangwarn'],
  category: 'grup',
  description: `> Mengurangi 1 warn dari member.

*Format:*
> \`.unwarn @mention\`
> \`.unwarn\` (reply pesan)`,
  help: '(@mention/reply)',
  onlyGroup: true,
  onlyAdmin: true,

  async execute(m, { args }) {
    const { target } = parseTargetAndReason(m, args)
    if (!target) return m.reply(`Format Salah!\nContoh pakai:\n> ${m.prefix}${m.command} @mention`)

    const sisa = removeLastWarn(m.chat, target)
    if (sisa === null) {
      return m.reply(m.chat, `@${numberOf(target)} tidak punya warn.`, { mentions: [target] })
    }
    return m.reply(m.chat, `✅ Warn @${numberOf(target)} dikurangi 1.\nSisa: *${sisa}/${getWarnLimit(m.chat)}*`, { mentions: [target] })
  }
}