import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'
import { claimDaily } from '../../lib/rpgDatabase.js' // Import database RPG lu

export default {
  command: 'absen',
  alias: ['hadir', 'present', 'daily', 'klaim'], // Sekalian masukin alias daily
  category: 'rpg', // Kategori ganti ke rpg
  description: 'Absen kehadiran harian berhadiah saldo RPG dengan scan biometrik.',
  typing: true,

  async execute(m, { sock }) {
    try {
      const senderJid = m.sender
      const senderName = m.pushName || 'User'

      // ==========================================
      // 1. CEK STATUS ABSEN / DAILY DULU
      // ==========================================
      const claim = claimDaily(senderJid)
      
      // Kalo belom 24 jam, langsung tolak (Biar kaga nyepam animasi)
      if (!claim.status) {
        const hours = Math.floor(claim.timeLeft / (1000 * 60 * 60))
        const minutes = Math.floor((claim.timeLeft % (1000 * 60 * 60)) / (1000 * 60))
        
        await sock.sendReact(m.chat, '❌', m.key).catch(() => {})
        return m.reply(`⏳ *Sidik jari ditolak!*\n\nLu udah absen hari ini. Mesin absensi masih *cooldown*.\nSilakan absen lagi dalam *${hours} jam ${minutes} menit*.`)
      }

      // ==========================================
      // 2. KALO BISA ABSEN, JALANIN ANIMASINYA
      // ==========================================
      await sock.sendReact(m.chat, '✅', m.key).catch(() => {})

      const rich = new AIRich(sock)
      rich.addText('⏳ Menginisialisasi sistem absensi...', { id: 'status' })
      
      await rich.send(m.chat, { 
        additionalAttributes: { type: "text" } 
      })

      let ppUrl = ''
      try {
        const pp = await sock.profile.getProfilePicture(senderJid, 'image')
        if (pp && pp.url) ppUrl = pp.url
      } catch (err) {
        ppUrl = null
      }

      rich.addText(` *${senderName}*...`, { replace: 'status', id: 'scan' })
      if (ppUrl) {
        rich.addImage('', { 
          status: 'GENERATING', 
          update_text: 'Mengekstrak data wajah...', 
          id: 'loading_pp' 
        })
      }
      await rich.sendEdit()
      await delay(1500)

      const time = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })
      const date = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' })

      // ==========================================
      // 3. SELIPIN INFO HADIAH RPG DI HASIL AKHIR
      // ==========================================
      const textFinal = ` *Data Kehadiran*\n\n` +
                        `👤 *Nama:* ${senderName}\n` +
                        `📱 *ID:* @${senderJid.split('@')[0]}\n` +
                        `🕒 *Waktu:* ${time} WIB\n` +
                        `📅 *Tanggal:* ${date}\n\n` +
                        `🎁 *Reward Absen:* +Rp${claim.hadiah.toLocaleString('id-ID')} 💰\n` +
                        `💳 *Total Saldo:* Rp${claim.balance.toLocaleString('id-ID')}` +
                        `${!ppUrl ? '\n\n_(Foto profil tidak terdeteksi/privasi)_' : ''}`
      
      rich.addText(textFinal, { replace: 'scan' })
      if (ppUrl) {
        rich.addImage(ppUrl, { replace: 'loading_pp', id: 'final_pp' })
      }
      
      rich.setFooter('BERHASIL ABSEN')
      
      await rich.sendEdit()

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Sistem absensi gagal:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}