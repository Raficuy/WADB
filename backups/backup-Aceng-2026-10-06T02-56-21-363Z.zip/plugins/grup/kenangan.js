// plugins/grup/kenangan.js
import { getRandomMessageText } from '../../db/rawMessage.js'
import { getPushNameByJid } from '../../db/contacts.js'

function formatDate(ts) {
  if (!ts) return '-'
  return new Date(ts * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
}

export default {
  command: 'kenangan',
  alias: ['throwback', 'tbt', 'nostalgia'],
  category: 'grup',
  description: `> Menampilkan pesan random dari masa lalu di grup ini, buat nostalgia.

contoh penggunaan:
> \`.kenangan\``,
  help: '(tanpa argumen)',
  onlyGroup: true,
  typing: true,

  async execute(m) {
    const row = getRandomMessageText(m.chat)
    if (!row) return m.reply('Belum ada histori pesan teks yang tersimpan buat grup ini.')

    const name = getPushNameByJid(row.sender_jid) || row.push_name || row.sender_jid?.split('@')[0] || 'Unknown'

    return m.reply(
      ` *KENANGAN LAMA*\n──────────────────\n\n` +
      `* *${name}*\n* ${formatDate(row.timestamp)}\n\n"${row.text}"`
    )
  }
}