// plugins/grup/persona.js
// Ganti kepribadian/karakter bot per grup. Pilihannya disimpan di SQLite
// (store/ai_persona.db, lewat lib/aiChat.js) jadi tiap grup bisa beda karakter.

import {
  PERSONAS,
  DEFAULT_PERSONA_KEY,
  getPersonaInfo,
  setPersona,
  resetPersona
} from '../../lib/aiChat.js'

function labelOf(key) {
  return PERSONAS[key]?.label || key
}

function timeWib(sec) {
  if (!sec) return '-'
  return new Date(sec * 1000).toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    dateStyle: 'medium',
    timeStyle: 'short'
  })
}

function listText(activeKey) {
  const keys = Object.keys(PERSONAS)
  const lines = keys.map((k, i) => {
    const mark = k === activeKey ? ' ✅' : ''
    return (i + 1) + '. *' + PERSONAS[k].label + '* — ' + k + mark
  })
  return '*Daftar karakter (' + keys.length + ')*\n\n' + lines.join('\n') +
    '\n\nPilih pakai nomor atau kode.\nContoh: *.persona set 3* atau *.persona set gaul*'
}

const HELP = '❌ Perintah gak dikenal.\n\n' +
  '*.persona* — lihat karakter yang aktif\n' +
  '*.persona list* — daftar semua karakter\n' +
  '*.persona set <nama/nomor>* — ganti karakter (admin/owner)\n' +
  '*.persona reset* — balik ke karakter default (admin/owner)'

export default {
  command: 'persona',
  alias: ['setai'],
  category: 'grup',
  groupOnly: true,
  description: `> Ganti kepribadian/karakter bot khusus di grup ini.
> Pilihan disimpan per grup di SQLite, jadi tiap grup bisa punya karakter berbeda.

contoh penggunaan:
> \`.persona\` — lihat karakter yang sedang aktif
> \`.persona list\` — lihat daftar semua karakter
> \`.persona set sarkas\` — ganti karakter (khusus admin grup)
> \`.persona reset\` — balik ke karakter default (khusus admin grup)`,
  help: '[list | info | set <nama|nomor> | reset]',

  async execute(m, { args }) {
    const sub = String(args[0] || '').toLowerCase().trim()
    const isAdmin = !!(m.isOwner || m.isAdmin)

    // tanpa argumen / info = tampilkan yang aktif
    if (!sub || sub === 'info' || sub === 'cek' || sub === 'aktif') {
      const info = getPersonaInfo(m.chat)
      return m.reply(
        '*Kepribadian grup ini*\n\n' +
        'Aktif   : *' + info.label + '*\n' +
        'Kode    : ' + info.key + (info.custom ? '' : ' _(default, belum pernah diganti)_') + '\n' +
        'Diubah  : ' + timeWib(info.updatedAt) + '\n\n' +
        'Ganti pakai *.persona set <kode>*, lihat semua pakai *.persona list*.'
      )
    }

    if (sub === 'list' || sub === 'daftar') {
      return m.reply(listText(getPersonaInfo(m.chat).key))
    }

    if (sub === 'set' || sub === 'ganti' || sub === 'pilih') {
      if (!isAdmin) {
        return m.reply('❌ Cuma admin grup (atau owner bot) yang boleh ganti kepribadian.')
      }

      const raw = String(args[1] || '').toLowerCase().trim()
      if (!raw) {
        return m.reply('❌ Mau diubah jadi apa?\nContoh: *.persona set sarkas*\n\nLihat daftarnya: *.persona list*')
      }

      let key = raw
      if (/^\d+$/.test(raw)) {
        const keys = Object.keys(PERSONAS)
        const idx = Number(raw) - 1
        if (idx < 0 || idx >= keys.length) {
          return m.reply('❌ Nomornya di luar daftar. Cek dulu: *.persona list*')
        }
        key = keys[idx]
      }

      if (!PERSONAS[key]) {
        return m.reply('❌ Karakter *' + raw + '* gak ada di daftar.\n\nCek dulu: *.persona list*')
      }

      const before = getPersonaInfo(m.chat).key
      setPersona(m.chat, key)

      return m.reply(
        '✅ Kepribadian grup ini diganti jadi *' + labelOf(key) + '*.\n' +
        'Kode: ' + key + (before === key ? ' _(sebelumnya udah ini sih)_' : '') + '\n\n' +
        'Coba panggil *ler* buat ngetes karakternya'
      )
    }

    if (sub === 'reset' || sub === 'hapus' || sub === 'default') {
      if (!isAdmin) {
        return m.reply('❌ Cuma admin grup (atau owner bot) yang boleh reset kepribadian.')
      }
      const changed = resetPersona(m.chat)
      return m.reply(changed
        ? '✅ Kepribadian grup ini balik ke *' + labelOf(DEFAULT_PERSONA_KEY) + '*.'
        : 'ℹ️ Grup ini belum pernah ganti kepribadian, masih *' + labelOf(DEFAULT_PERSONA_KEY) + '*.')
    }

    return m.reply(HELP)
  }
}