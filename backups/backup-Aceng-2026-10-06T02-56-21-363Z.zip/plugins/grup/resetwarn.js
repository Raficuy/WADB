// plugins/grup/resetwarn.js
import { parseTargetAndReason, numberOf } from '../../lib/warn.js'
import { clearWarns } from '../../db/warn.js'

export default {
  command: 'resetwarn',
  alias: ['clearwarn', 'hapuswarn'],
  category: 'grup',
  description: `> Menghapus semua warn milik member.

*Format:*
> \`.resetwarn @mention\`
> \`.resetwarn\` (reply pesan)`,
  help: '(@mention/reply)',
  onlyGroup: true,
  onlyAdmin: true,

  async execute(m, { args }) {
    const { target } = parseTargetAndReason(m, args)
    if (!target) return m.reply(`Format Salah!\nContoh pakai:\n> ${m.prefix}${m.command} @mention`)

    const total = clearWarns(m.chat, target)
    if (!total) {
      return m.reply(m.chat, `@${numberOf(target)} tidak punya warn.`, { mentions: [target] })
    }
    return m.reply(m.chat, `✅ ${total} warn @${numberOf(target)} dihapus semua.`, { mentions: [target] })
  }
}