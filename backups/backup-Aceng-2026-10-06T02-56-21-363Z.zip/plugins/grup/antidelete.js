// plugins/grup/antidelete.js
import { getEffectiveGroupSettings, updateGroupSettings } from '../../lib/groupAndBot.js'

export default {
  command: 'antidelete',
  alias: ['antidel', 'antihapus'],
  category: 'grup',
  description: `> Kalau aktif, bot bakal nampilin ulang isi pesan (teks) yang dihapus pengirimnya di grup ini.
Catatan: cuma untuk pesan teks, media gak bisa dipulihin.

contoh penggunaan:
> \`.antidelete on\`
> \`.antidelete off\``,
  help: '`<on|off>`',
  onlyOwner: true,
  onlyGroup: true,

  async execute(m, { args }) {
    const value = args[0]?.toLowerCase()
    if (!['true', 'false', 'on', 'off'].includes(value)) {
      const settings = getEffectiveGroupSettings(m.chat)
      return m.reply(`Status antidelete: ${settings.antidelete ? 'ON' : 'OFF'}\nGunakan: ${m.prefix}${m.command} <on|off>`)
    }

    const settings = updateGroupSettings(m.chat, {
      antidelete: value === 'true' || value === 'on'
    })

    return m.reply(`✅ Antidelete ${settings.antidelete ? 'diaktifkan' : 'dinonaktifkan'} untuk grup ini.`)
  }
}
