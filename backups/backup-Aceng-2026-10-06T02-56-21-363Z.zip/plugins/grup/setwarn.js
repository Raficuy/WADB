// plugins/grup/setwarn.js
import { updateGroupSettings } from '../../lib/groupAndBot.js'
import { getWarnLimit, MIN_LIMIT, MAX_LIMIT } from '../../lib/warn.js'

export default {
  command: 'setwarn',
  alias: ['warnlimit'],
  category: 'grup',
  description: `> Mengatur batas warn sebelum member otomatis dikeluarkan dari grup ini (bawaan 3).

*Format:*
> \`.setwarn\` (lihat batas saat ini)
> \`.setwarn <angka>\` (${MIN_LIMIT}-${MAX_LIMIT})

contoh:
> \`.setwarn 5\`

*Catatan:*
> hanya bisa digunakan admin grup.`,
  help: '<angka>',
  onlyGroup: true,
  onlyAdmin: true,

  async execute(m, { args }) {
    const current = getWarnLimit(m.chat)

    if (!args[0]) {
      return m.reply(
        `⚠️ *BATAS WARN*\nSaat ini: *${current}x*\n\n` +
        `Member akan dikeluarkan otomatis setelah mendapat ${current} warn.\n\n` +
        `Ubah: \`${m.prefix}${m.command} <angka ${MIN_LIMIT}-${MAX_LIMIT}>\``
      )
    }

    const limit = Number(args[0])
    if (!Number.isInteger(limit) || limit < MIN_LIMIT || limit > MAX_LIMIT) {
      return m.reply(`Angka tidak valid. Masukkan bilangan bulat ${MIN_LIMIT}-${MAX_LIMIT}.\nContoh: \`${m.prefix}${m.command} 5\``)
    }

    updateGroupSettings(m.chat, { warn: { limit } })
    return m.reply(`✅ Batas warn diubah menjadi *${limit}x*.\nMember akan dikeluarkan otomatis setelah mendapat ${limit} warn.`)
  }
}