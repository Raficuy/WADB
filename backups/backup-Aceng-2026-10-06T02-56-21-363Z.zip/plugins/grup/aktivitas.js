// plugins/grup/aktivitas.js
//
// Semua data ini udah kesimpen tiap ada pesan masuk (db/rawMessage.js),
// tapi getTopActive & getLastActivePerSender-nya sendiri sebelumnya gak pernah dipanggil.

import { getTopActive, getLastActivePerSender } from '../../db/rawMessage.js'
import { getPushNameByJid } from '../../db/contacts.js'
import { getCachedGroupMetadata, getGroupMetadata } from '../../db/groupCache.js'

function displayName(jid) {
  return getPushNameByJid(jid) || jid?.split('@')[0] || 'Unknown'
}

function formatRelative(tsSeconds) {
  if (!tsSeconds) return 'belum pernah tercatat'
  const diffMs = Date.now() - tsSeconds * 1000
  const days = Math.floor(diffMs / 86_400_000)
  if (days <= 0) return 'hari ini'
  if (days === 1) return 'kemarin'
  return `${days} hari lalu`
}

export default {
  command: 'aktivitas',
  alias: ['statsgrup', 'aktifgc', 'groupstats'],
  category: 'grup',
  description: `> Menampilkan member paling aktif & paling jarang ngobrol di grup ini, berdasarkan histori pesan yang tersimpan di database.

contoh penggunaan:
> \`.aktivitas\``,
  help: '(tanpa argumen)',
  onlyGroup: true,
  typing: true,

  async execute(m, { sock }) {
    let metadata = getCachedGroupMetadata(m.chat)
    if (!metadata) metadata = await getGroupMetadata(m.chat, sock).catch(() => null)

    const topActive = getTopActive(m.chat, 5)
    const lastActiveRows = getLastActivePerSender(m.chat)
    const lastActiveMap = new Map(lastActiveRows.map(r => [r.sender_jid, r.last_ts]))

    if (!topActive.length) {
      return m.reply('📊 Belum ada data pesan yang tercatat buat grup ini.')
    }

    let text = `📊 *AKTIVITAS GRUP*\n${metadata?.subject ? `Grup: ${metadata.subject}\n` : ''}──────────────────\n\n`

    text += `🔥 *Top 5 Paling Aktif (dari histori tersimpan)*\n`
    topActive.forEach((row, i) => {
      text += `${i + 1}. ${displayName(row.sender_jid)} — ${row.total} pesan\n`
    })

    // Cari member yang PALING JARANG ngobrol: bandingin daftar participant
    // grup vs sender_jid yang ada di histori pesan. Yang gak pernah muncul
    // sama sekali dianggap paling sepi.
    if (metadata?.participants?.length) {
      const knownSenders = new Set(lastActiveMap.keys())
      const withActivity = []
      const neverChatted = []

      for (const p of metadata.participants) {
        const jid = p.jid || p.phoneNumber
        if (!jid) continue
        if (knownSenders.has(jid)) {
          withActivity.push({ jid, last_ts: lastActiveMap.get(jid) })
        } else {
          neverChatted.push(jid)
        }
      }

      withActivity.sort((a, b) => a.last_ts - b.last_ts)
      const quietest = withActivity.slice(0, 5)

      text += `\n😴 *Paling Jarang Ngobrol*\n`
      if (quietest.length) {
        quietest.forEach((row, i) => {
          text += `${i + 1}. ${displayName(row.jid)} — terakhir ${formatRelative(row.last_ts)}\n`
        })
      }
      if (neverChatted.length) {
        text += `\n👻 *Belum Pernah Ngobrol Sama Sekali:* ${neverChatted.length} member`
        if (neverChatted.length <= 8) {
          text += `\n${neverChatted.map(displayName).join(', ')}`
        }
      }
    }

    return m.reply(text.trim())
  }
}
