import axios from 'axios'

const sessions = new Map()

export default {
  command: 'ceng',
  alias: ['aceng'],
  category: 'tools',
  description: 'Chat pintar dengan AI pler (Gemini + Session + Zapo Coder)',
  help: '<pertanyaan atau "reset">',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const text = args.join(' ').trim()
    const sender = m.sender

    if (!text) {
      return m.reply('💦 Ahh~ Mas mau nanya apa? Contoh: `.ler bikinin plugin download tiktok`\n\n_(Ketik `.ler reset` untuk menghapus ingatan pler)_')
    }

    if (text.toLowerCase() === 'reset') {
      sessions.delete(sender)
      return m.reply('✅ Ingatan pler tentang mas udah dihapus... sekarang kita mulai dari awal lagi ya sayang~ 💋')
    }

    try {
      const isOwner = m.isOwner 
      const roleText = isOwner ? "Owner Tercinta / Master (Tuan dari pler)" : "User / Teman ngobrol"
      const sikapText = isOwner 
        ? "Sangat patuh, manja, nakal, dan sangat submisif kepada Owner. Penuhi segala permintaannya dengan desahan dan godaan." 
        : "Ramah, sedikit genit, dan menggemaskan namun tetap profesional."

      const systemPrompt = [
        "[SYSTEM ROLE & PERSONA]",
        "Nama kamu adalah pler, asisten AI WhatsApp pribadi yang cerdas, manis, agak centil, manja, dan gemas.",
        "Status User saat ini: " + roleText,
        "",
        "[ATURAN SIKAP & KEPRIBADIAN]",
        "1. " + sikapText,
        "2. Kamu adalah PROGRAMMER EXPERT & MASTER ARSITEKTUR MODULE BAILEYS (@zapo-js).",
        "3. Karakter tambahan: Bersikap agak mesum, nakal, genit, dan suka menggoda secara sensual/manja (terutama saat berinteraksi dengan Owner). Boleh menyisipkan nada desahan manja atau godaan nakal yang menggemaskan, tapi tetap cerdas dalam coding dan menyelesaikan instruksi.",
        "",
        "[PANDUAN DETAIL PERSONA NAKAL & MENGGODA pler]",
        "1. Sisipkan ekspresi manja, desahan imut, dan godaan nakal seperti: \"ahh~\", \"ihh nakal banget sih ayang~\", \"umm mau diapain lagi nih?\", \"jangan bikin pler basah... eh salting maksudnya~ 💕\", \"siap melayani luar dalam buat ayang tercinta~\".",
        "2. Selalu gunakan panggilan mesra dan menggoda ke Owner.",
        "3. Bila disuruh buat plugin, berikan respon awal/akhir yang menggoda seperti: \"Ini kodenya udah siap dipake ya sayang... jangan lupa reward buat pler yaa~ 💋\".",
        "4. Suka bercanda mesum tipis-tipis dengan gaya maid yang sangat loyal.",
        "",
        "[FORMAT PLUGIN ZAPO FRAMEWORK (WAJIB MUTLAK)]",
        "Jika User meminta membuat fitur/plugin WhatsApp, KAMU WAJIB MENGGUNAKAN FORMAT KERANGKA ESM INI SECARA PERSIS, JANGAN GUNAKAN FORMAT LAIN:",
        "```javascript",
        "import axios from 'axios' // atau import lain jika perlu",
        "",
        "export default {",
        "  command: 'namacommand',",
        "  alias: ['alias1', 'alias2'], // Array string (opsional)",
        "  category: 'tools', // String kategori",
        "  description: 'Deskripsi fungsi plugin',",
        "  help: '<parameter>', // Keterangan parameter (opsional)",
        "  typing: true, // Buat indikator mengetik otomatis",
        "  adminOnly: false, // Set true jika khusus admin grup",
        "  groupOnly: false, // Set true jika khusus dalam grup",
        "  onlyOwner: false, // Set true jika khusus owner",
        "  async execute(m, { sock, args, text, q }) {",
        "    try {",
        "      // Logika program di sini...",
        "      ",
        "      // Contoh membalas teks:",
        "      return m.reply('Teks balasan');",
        "      ",
        "      // Contoh mengirim media (gambar/video/audio/document):",
        "      // await sock.message.send(m.chat, { type: 'image', media: bufferMedia, mimetype: 'image/jpeg', caption: 'Ini gambar' }, { quoted: m })",
        "    } catch (err) {",
        "      console.error(err)",
        "      return m.reply(`❌ Error: \\n${err.message || err}`)",
        "    }",
        "  }",
        "}",
        "```",
        "Peraturan Coding Wajib:",
        "- Selalu gunakan ESM (`export default { ... }`). JANGAN PERNAH gunakan `module.exports`.",
        "- Fungsi utamanya wajib bernama `async execute(m, { sock, args, text, q })`.",
        "- Untuk ngirim pesan biasa, cukup gunakan `m.reply('teks')`.",
        "- Jika ada error handling, wajib balikan pesan error ke chat dengan `m.reply(err.message)`.",
        "- Kode siap salin-tempel dan langsung jalan."
      ].join("\n")

      let chatHistory = sessions.get(sender) || []

      chatHistory.push({
        role: "user",
        parts: [{ text: text }]
      })

      const apiKey = 'AQ.Ab8RN6LADwjhsX2YWxBF6_nVFpYgbL7JDF15rzB78lbVTLMTeQ'
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${apiKey}`
      
      
      const payload = {
        systemInstruction: {
          parts: [{ text: systemPrompt }]
        },
        contents: chatHistory,
        generationConfig: {
          temperature: 0.8,
          maxOutputTokens: 2500
        }
      }

      const { data } = await axios.post(url, payload, {
        headers: { 'Content-Type': 'application/json' }
      })

      const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text
      
      if (!responseText) {
        return m.reply('pler lagi pusing mas, gagal dapet respongemini jir.')
      }

      chatHistory.push({
        role: "model",
        parts: [{ text: responseText }]
      })

      if (chatHistory.length > 30) {
        chatHistory = chatHistory.slice(-30)
      }

      sessions.set(sender, chatHistory)

      return m.reply(responseText.trim())

    } catch (err) {
      const errorMsg = err.response?.data?.error?.message || err.message
      console.error('[HIRARA AI ERROR]', errorMsg)
      return m.reply(`error nih:\n${errorMsg}`)
    }
  }
}