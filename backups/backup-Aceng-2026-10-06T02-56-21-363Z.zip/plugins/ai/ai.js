export default {
  command: 'bb',
  alias: ['blackbox'],
  category: 'ai',
  description: 'Chatting pintar dengan Blackbox AI mutlak.',
  help: '<pertanyaan> atau reply pesan',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    // Ambil input dari ketikan atau pesan yang di-reply
    const query = args.join(' ').trim() || m.quoted?.text || ''

    if (!query) {
      return m.reply('❌ Kasih pertanyaannya cuy!\n\n*Contoh:* .ai Tolong buatin script bot WA')
    }


    try {
      // Tembak langsung ke API FAA bawaan script lu
      const targetUrl = `https://api-faa.my.id/faa/blackbox?query=${encodeURIComponent(query)}`
      const apiResponse = await fetch(targetUrl, {
        method: 'GET',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'
        }
      })

      if (!apiResponse.ok) {
        throw new Error(`Server API meledak mutlak (Status: ${apiResponse.status})`)
      }

      const data = await apiResponse.json()

      // Ekstrak teks balasan AI sesuai struktur JSON dari API
      let resultText = data.result?.response || data.response || "Berhasil terhubung, tapi AI kaga ngasih balasan apa-apa."

      // Format Output ala Zapo
      const caption = `${resultText}`

      return m.reply(caption)

    } catch (err) {
      return m.reply(`❌ *Sistem AI Error:*\n${err.message || err}`)
    }
  }
}