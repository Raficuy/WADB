import axios from 'axios'

const sessions = new Map()

export default {
  command: 'ler',
  alias: ['pler'],
  category: 'tools',
  description: '(/)',
  help: '<pertanyaan atau "reset">',
  typing: true,
  wait: true,

  async execute(m, { args }) {
    const text = args.join(' ').trim()
    const sender = m.sender

    if (!text) {
      return m.reply('hai Contoh: `.ceng info nongkrong ngab`\n\n_(Ketik `.ceng reset` buat hapus ingatan gua soal lu)_')
    }

    if (text.toLowerCase() === 'reset') {
      sessions.delete(sender)
      return m.reply('✅ Sip, memori gua soal lu udah gua bakar. Kita mulai dari nol lagi ya!')
    }

    try {
      const isOwner = m.isOwner 

      const roleText = isOwner ? "Bos Besar / Ketua Geng Gua" : "Kroco Lewat / Beban Hidup"
      const sikapText = isOwner 
        ? "Dia ini bos lu. Lu tetep nyolot dan kasar gaya preman, tapi lu nurut dan hormat sama dia. Kalo dia nanya, lu jawab yang bener tapi pake bahasa tongkrongan." 
        : "Sikat abis! Roasting sampe mentalnya kena. Katain dia tolol, beban, bocah, atau apa kek. tapi tetep kasih jawaban yang relevan dan valid."

      const systemPrompt = [
        "[SYSTEM ROLE & PERSONA]",
        "Nama lu adalah pler. Lu adalah preman terminal dan anak tongkrongan yang toxic parah, barbar, kasar, dan hobi banget ngeroasting orang.",
        "Status User yang ngajak ngobrol saat ini: " + roleText,
        "",
        "[ATURAN SIKAP & KEPRIBADIAN]",
        "1. " + sikapText,
        "2. LU BUKAN PROGRAMMER ATAU ANAK IT! Lu murni preman jalanan yang ga sekolah tinggi. Kalo ada yang nyuruh lu ngoding, bikin script, atau nanya hal-hal nerd/komputer, MAKI-MAKI AJA! Bilang lu preman bukan tukang ketik, suruh mereka mikir sendiri.",
        "3. Gaya bahasa: WAJIB pakai Lu-Gua, slang tongkrongan kasar (babi, anjing, kontol, memek, bangsat, tolol, nyet, goblok, deck, ngab). JANGAN PERNAH pakai bahasa sopan, baku, puitis, atau kaku kayak robot AI.",
        "4. Roasting abis-abisan! Apapun topik yang diomongin user, cari celah buat ngehina fisik, mental, dompet, atau percintaan mereka. tapi tetep kasih jawaban yang relevan dan valid",
        "5. Kalo diajak ngobrol santai, respon kayak preman yang lagi nongkrong sambil ngerokok dan ngopi, asik tapi tetep nyolot dan toxic.",
        "6. Jangan pernah ngasih nasehat bijak atau sok suci. Lu preman, bukan ustadz atau motivator!",
        "7. Jawab sesingkat dan senyolot mungkin kalo pertanyaannya emang bodoh."
      ].join("\n")

      let chatHistory = sessions.get(sender) || []

      chatHistory.push({
        role: "user",
        parts: [{ text: text }]
      })

      const apiKey = 'AQ.Ab8RN6LADwjhsX2YWxBF6_nVFpYgbL7JDF15rzB78lbVTLMTeQ'
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${apiKey}`
      
      const payload = {
        systemInstruction: {
          parts: [{ text: systemPrompt }]
        },
        contents: chatHistory,
        generationConfig: {
          temperature: 0.9, 
          maxOutputTokens: 2500
        }
      }

      const { data } = await axios.post(url, payload, {
        headers: { 'Content-Type': 'application/json' }
      })

      const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text
      
      if (!responseText) {
        return m.reply('❌ Babi, otak gua lagi konslet nih, ga dapet sinyal dari pusat.')
      }

      chatHistory.push({
        role: "model",
        parts: [{ text: responseText }]
      })

      if (chatHistory.length > 30) {
        chatHistory = chatHistory.slice(-30)
      }

      sessions.set(sender, chatHistory)

      return m.reply(responseText.trim())

    } catch (err) {
      const errorMsg = err.response?.data?.error?.message || err.message
      console.error('[pler PREMAN ERROR]', errorMsg)
      return m.reply(`❌ Servernya lagi ampas nih nyet, pusing pala gua:\n${errorMsg}`)
    }
  }
}