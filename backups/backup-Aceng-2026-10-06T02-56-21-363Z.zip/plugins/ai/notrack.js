import axios from "axios";
import crypto from "crypto";

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const BASE_URL = "https://notrack.ai";

const userSessions = new Map();

async function notrackChat({ prompt, session_id = null, chat_id = null, persona = "normal", mode = "usual" }) {
  if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
    throw new Error("Parameter prompt wajib diisi");
  }

  const effectiveSessionId = session_id || crypto.randomUUID();
  const cookieStr = `uid=${effectiveSessionId}`;

  const payload = {
    user_input: prompt.trim(),
    mode: mode || "usual",
    model: "C",
    persona: persona || "normal",
    max_turns: 10,
    chat_id: chat_id || null,
    attachments: [],
    regenerate: false,
    edit: false,
    edit_mid: null,
    via: "text"
  };

  const res = await axios.post(`${BASE_URL}/api/dispatch`, payload, {
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/json",
      Origin: BASE_URL,
      Referer: `${BASE_URL}/id/chat`,
      Cookie: cookieStr,
      Accept: "text/event-stream"
    },
    responseType: "stream",
    timeout: 35000
  });

  let fullAnswer = "";
  let returnedChatId = chat_id || null;

  await new Promise((resolve, reject) => {
    let hasError = false;

    res.data.on("data", (chunk) => {
      const lines = chunk.toString().split("\n");
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === "chat_meta" && evt.chat_id) {
              returnedChatId = evt.chat_id;
            } else if (evt.type === "delta" && evt.chunk) {
              fullAnswer += evt.chunk;
            } else if ((evt.type === "message" || evt.type === "consensus") && evt.content) {
              fullAnswer = evt.content;
            } else if (evt.type === "error") {
              hasError = true;
              reject(new Error(evt.content || "Terjadi kesalahan dari NoTrack AI"));
            }
          } catch (e) {
          }
        }
      }
    });

    res.data.on("end", () => {
      if (!hasError) resolve();
    });

    res.data.on("error", (err) => {
      if (!hasError) reject(err);
    });
  });

  if (!fullAnswer.trim()) {
    throw new Error("NoTrack AI tidak memberikan respon jawaban");
  }

  return {
    prompt: prompt.trim(),
    result: fullAnswer.trim(),
    session_id: effectiveSessionId,
    chat_id: returnedChatId
  };
}

export default {
  command: 'notrack',
  alias: ['mek'],
  category: 'ai',
  typing: true,
  description: 'Chatbot AI NoTrack dengan memori percakapan.',
  help: '<pertanyaan atau reply pesan>',

  async execute(m, { sock, args, text }) {
 
    let prompt = text || args.join(' ') || '';

    if (!prompt && m.quoted) {
      prompt = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.message?.conversation || '';
    }

    if (!prompt.trim()) {
      return m.reply(`Masukkan prompt atau reply sebuah pesan teks!\n\nContoh: *.ai kenalin gua ${m.pushName}*\nKetik *.ai reset* untuk menghapus ingatan chat.`);
    }

    const sender = m.sender; 
    if (prompt.toLowerCase() === 'reset') {
      userSessions.delete(sender);
      return m.reply('Sesi chat AI kamu telah direset. chat sebelumnya sudah dihapus.');
    }

    try {
      const userContext = userSessions.get(sender) || { session_id: null, chat_id: null };

      const response = await notrackChat({
        prompt: prompt,
        session_id: userContext.session_id,
        chat_id: userContext.chat_id
      });

      userSessions.set(sender, {
        session_id: response.session_id,
        chat_id: response.chat_id
      });

      return m.reply(response.result);

    } catch (err) {
      console.error('[NOTRACK AI ERROR]', err);
      return m.reply(`❌ *Gagal memproses AI:*\n${err.message || err}`);
    }
  }
}