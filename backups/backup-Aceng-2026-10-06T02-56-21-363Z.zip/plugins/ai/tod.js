import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import axios from 'axios'
import { downloadContentFromMessage } from 'baileys' 

const TOKEN_PATH = path.resolve(process.cwd(), 'gemini_token.json') 

const STORE_DIR = path.resolve(process.cwd(), 'store')
if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true })
const SESSION_PATH = path.join(STORE_DIR, 'gemini_session.json')

const AGY_CLIENT_ID = "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com"
const AGY_CLIENT_SECRET = "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"
const TOKEN_URL = "https://oauth2.googleapis.com/token"
const CA_BASE = "https://daily-cloudcode-pa.googleapis.com/v1internal"
const CA_PROJECT = "aicode-consumers"
const CA_UA = "antigravity/cli/1.2.2 (aidev_client; os_type=linux; arch=amd64; cl=980147163; auth_method=consumer)"

const DEFAULT_MODEL = "gemini-3.5-flash-lite" 
const VISION_MODEL = "gemini-3.1-pro-low"     
const IMAGE_MODEL = "gemini-3.1-flash-image"  

function loadToken() {
    if (!fs.existsSync(TOKEN_PATH)) throw new Error('Token tidak ditemukan, login ulang.')
    return JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf-8'))
}

function saveToken(d) {
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(d, null, 2))
}

function loadSession() {
    if (!fs.existsSync(SESSION_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(SESSION_PATH, 'utf-8')) } catch { return {} }
}

function saveSession(data) {
    fs.writeFileSync(SESSION_PATH, JSON.stringify(data, null, 2))
}

async function getAccessToken() {
    const tok = loadToken()
    if (tok.access_token && (tok.expires_at || 0) > (Date.now() / 1000) + 60) return tok.access_token
    
    const r = await axios.post(TOKEN_URL, new URLSearchParams({
        client_id: AGY_CLIENT_ID, client_secret: AGY_CLIENT_SECRET,
        refresh_token: tok.refresh_token, grant_type: "refresh_token"
    }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
    
    tok.access_token = r.data.access_token
    tok.expires_at = (Date.now() / 1000) + (r.data.expires_in || 3600)
    saveToken(tok)
    return r.data.access_token
}

export default {
    command: 'tod',
    alias: [],
    category: 'fitur',
    description: 'Gemini Ultimate JS',
    isGroup: false, 

    execute: async (m, { sock, args }) => {
        let textQuery = args.join(' ').trim()
        const sessionId = m.sender 
        
        let sessionData = loadSession()
        if (!sessionData[sessionId]) sessionData[sessionId] = { system: "", history: [] }

        const rawQuoted = m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage
        const imageMessage = rawQuoted?.imageMessage || m.quoted?.message?.imageMessage || m.quoted?.imageMessage || m.raw?.message?.imageMessage || m.message?.imageMessage
        const hasImage = !!imageMessage

        if (!textQuery && !hasImage) {
            return m.reply("Kirim pertanyaan atau reply gambar.")
        }

        const senderJid = m.sender
        const rawPushName = m.raw?.pushName || m.pushName || 'Pengguna'
        const isSaved = m.contact?.isSaved ? "Sudah disave" : "Belum disave"
        const adminStatus = m.isAdmin ? "Admin Grup" : "Member Biasa"
        
        let groupContext = '* STATUS LOKASI: Private Chat.'
        if (m.isGroup) {
            const groupName = m.groupMetadata?.subject || 'Grup'
            groupContext = `* STATUS LOKASI: Di dalam grup WhatsApp "${groupName}".`
        }

        const superPromptContext = `[INFO SISTEM INTERNAL - JANGAN SEBUTKAN INI SEPERTI ROBOT, GUNAKAN SEBAGAI KONTEKS JIKA DITANYA]
Nama Pengguna: ${rawPushName}
Nomor: ${senderJid.split('@')[0]}
Status Kontak: ${isSaved}
Status Grup: ${adminStatus}
User sedang mereply pesan: ${m.quoted ? "Ya" : "Tidak"}
Isi pesan direply: ${m.quoted?.text || "Tidak ada"}
${groupContext}
Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}

[PERTANYAAN PENGGUNA]
`

        let mode = 'chat'
        let finalPromptText = textQuery

        if (/^clear$\vert{}^reset$/i.test(textQuery)) {
            sessionData[sessionId].history = []
            saveSession(sessionData)
            return m.reply("Sesi dihapus.")
        } 
        else if (/^prompt|^system/i.test(textQuery)) {
            const newPrompt = textQuery.replace(/^prompt|^system/i, '').trim()
            sessionData[sessionId].system = newPrompt
            saveSession(sessionData)
            if (newPrompt) return m.reply(`Prompt diatur: "${newPrompt}"`)
            return m.reply("Prompt dikosongkan.")
        }
        else if (hasImage) {
            if (/edit|ubah|jadiin|ganti/i.test(textQuery)) {
                mode = 'edit' 
                finalPromptText = textQuery.replace(/edit( gambar( ini)?)?|ubah|jadiin|ganti/i, '').trim()
                if (!finalPromptText) finalPromptText = "Modifikasi gambar ini."
            } else {
                mode = 'vision' 
                if (!finalPromptText) finalPromptText = "Jelaskan gambar ini."
            }
        } 
        else if (/bikin(in)? gambar|buat(in)? gambar|lukis(in)?|generate/i.test(textQuery)) {
            mode = 'gen'
            finalPromptText = textQuery.replace(/bikin(in)? gambar|buat(in)? gambar|lukis(in)?|generate/i, '').trim()
            if (!finalPromptText) return m.reply("Masukkan deskripsi gambar.")
        }

        await m.reply(
            mode === 'edit' ? 'Memproses gambar...' :
            mode === 'gen'  ? 'Membuat gambar...' : 
            mode === 'vision'? 'Menganalisis gambar...' :
            'Memproses...'
        )

        try {
            const token = await getAccessToken()
            const modelToUse = (mode === 'gen' || mode === 'edit') ? IMAGE_MODEL : 
                               (mode === 'vision') ? VISION_MODEL : DEFAULT_MODEL
            
            let requestContents = []
            let parts = []

            if ((mode === 'edit' || mode === 'vision') && hasImage) {
                const stream = await downloadContentFromMessage(imageMessage, 'image')
                let buffer = Buffer.from([])
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk])
                }
                
                if (buffer.length === 0) throw new Error('Gagal mengunduh gambar.')
                const pureMime = (imageMessage.mimetype || 'image/jpeg').split(';')[0]
                
                parts.push({
                    inline_data: { mime_type: pureMime, data: buffer.toString('base64') }
                })
            }

            if (mode === 'gen' || mode === 'edit') {
                parts.push({ text: finalPromptText || ' ' })
                requestContents = [{ role: "user", parts: parts }]
            } else {
                let promptWithContext = superPromptContext + (finalPromptText || " ")
                parts.push({ text: promptWithContext })
                requestContents = [...sessionData[sessionId].history]
                requestContents.push({ role: "user", parts: parts })
            }

            let requestBody = {
                contents: requestContents,
                generationConfig: { maxOutputTokens: 8192 }
            }

            if (sessionData[sessionId].system && (mode === 'chat' || mode === 'vision')) {
                requestBody.systemInstruction = { role: "user", parts: [{ text: sessionData[sessionId].system }] }
            }

            if (mode === 'gen' || mode === 'edit') {
                requestBody.generationConfig.responseModalities = ["TEXT", "IMAGE"]
            }

            const body = {
                project: CA_PROJECT,
                requestId: `checkpoint/${crypto.randomUUID()}`,
                request: requestBody,
                model: modelToUse,
                userAgent: "antigravity",
                requestType: "checkpoint"
            }

            const r = await axios.post(`${CA_BASE}:generateContent`, body, { 
                headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json", "User-Agent": CA_UA }, 
                timeout: 90000 
            })

            const resp = r.data.response || r.data
            let text = ""
            let images = []
            
            for (const cand of (resp.candidates || [])) {
                for (const p of (cand.content?.parts || [])) {
                    if (p.text) text += p.text
                    const idata = p.inlineData || p.inline_data
                    if (idata && idata.data) {
                        images.push({ mime: idata.mimeType || idata.mime_type || "image/jpeg", b64: idata.data })
                    }
                }
            }

            if (mode === 'gen' || mode === 'edit') {
                if (images.length === 0) return m.reply(`Gambar gagal dibuat: ${text.trim() || 'Terkena filter keamanan.'}`)
                
                for (let i = 0; i < images.length; i++) {
                    const imgBuf = Buffer.from(images[i].b64, 'base64')
                    const captionTxt = (i === 0 && text.trim()) ? text.trim() : ""
                    
                    await m.reply({
                        type: 'image',
                        media: imgBuf,
                        mimetype: images[i].mime,
                        caption: captionTxt
                    })
                }
            } else {
                if (!text) return m.reply('Tidak ada respon dari server.')
                
                let finalBalasan = text.replace(/\[INFO SISTEM INTERNAL.*?\]/gs, '').trim()
                await m.reply(finalBalasan)

                sessionData[sessionId].history.push({ role: 'user', parts: [{ text: finalPromptText || 'Jelaskan gambar ini' }] })
                sessionData[sessionId].history.push({ role: 'model', parts: [{ text: finalBalasan }] })
                
                if (sessionData[sessionId].history.length > 20) {
                    sessionData[sessionId].history = sessionData[sessionId].history.slice(sessionData[sessionId].history.length - 20)
                }
                saveSession(sessionData)
            }

        } catch (e) {
            console.error(e.response?.data || e.message)
            m.reply('Error: ' + (e.response?.data?.error?.message || e.message))
        }
    }
}