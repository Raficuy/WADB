import axios from 'axios'

export default {
    command: 'aidraw',
    alias: ['gambar', 'createimg', 'text2img', 'flux'],
    category: 'ai',
    description: 'Generate gambar AI kualitas FLUX secepat kilat.',
    help: '<prompt>',
    typing: true,
    wait: true,

    async execute(m, { args }) {
        const prompt = args.join(' ').trim()
        
        if (!prompt) {
            return m.reply('kasih prompt!\n\n*Contoh:* .aidraw cyberpunk cat wearing sunglasses in neon city')
        }


        try {

            const seed = Math.floor(Math.random() * 1000000000)
            const encodedPrompt = encodeURIComponent(prompt)
            
            
            const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?seed=${seed}&width=1024&height=1024&nologo=true&model=flux`

            const res = await axios.get(url, { 
                responseType: 'arraybuffer', 
                timeout: 20000 
            })

            const imageBuffer = Buffer.from(res.data)

            let caption = `*AI Image Generator*\n`
            caption += `*Prompt:* ${prompt}\n`
            caption += `*model:* nano banana\n`
            caption += `*Seed:* ${seed}`
           
            return m.reply({
                type: 'image',
                media: imageBuffer,
                mimetype: 'image/jpeg',
                caption: caption
            })

        } catch (err) {
            return m.reply(`❌ *Generator Error:*\n${err.message || err}`)
        }
    }
}