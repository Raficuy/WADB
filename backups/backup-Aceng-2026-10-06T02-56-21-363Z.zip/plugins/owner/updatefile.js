// plugins/owner/updatefile.js

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { downloadMediaMessage } from 'zapo-js'
import { reviveBase64Fields } from '../../lib/utils.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const ROOT_DIR = path.join(__dirname, '..', '..')
const BACKUP_DIR = path.join(ROOT_DIR, 'sampah', 'backup')

const PROTECTED = ['node_modules', '.git', 'session', 'sampah', '.env']

function resolveSafePath(rawPath) {
  const cleaned = String(rawPath || '').trim().replace(/^\/+/, '')
  const resolved = path.resolve(ROOT_DIR, cleaned)
  const rel = path.relative(ROOT_DIR, resolved)

  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) {
    return { ok: false, reason: 'Path keluar dari folder project. Gak diizinkan.' }
  }

  const firstSegment = rel.split(path.sep)[0]
  if (PROTECTED.includes(firstSegment)) {
    return { ok: false, reason: `\`${firstSegment}\` itu folder/file terproteksi, gak boleh ditimpa lewat sini.` }
  }

  return { ok: true, resolved, rel }
}

function splitPathAndContent(raw) {
  const trimmedStart = raw.replace(/^[ \t]+/, '')
  const match = trimmedStart.match(/^(\S+)([\s\S]*)$/)
  if (!match) return { filePath: '', content: null }

  let content = match[2].replace(/^\r?\n/, '') 
  content = content.replace(/[ \t]+$/, '') 
  const fenced = content.match(/^```[a-zA-Z0-9]*\r?\n([\s\S]*?)\r?\n?```$/)
  if (fenced) content = fenced[1]

  return { filePath: match[1], content }
}

function extractMediaMessage(msg) {
  if (!msg) return null
  let m = msg.message || msg
  const mediaKeys = ['imageMessage', 'videoMessage', 'stickerMessage', 'documentMessage', 'audioMessage', 'ptvMessage']

  while (m && typeof m === 'object') {
    const foundKey = Object.keys(m).find(k => mediaKeys.includes(k))
    if (foundKey) return { [foundKey]: m[foundKey] }

    if (m.documentWithCaptionMessage?.message) m = m.documentWithCaptionMessage.message
    else if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message
    else if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message
    else if (m.viewOnceMessageV2Extension?.message) m = m.viewOnceMessageV2Extension.message
    else if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message
    else break
  }
  return null
}

function backupIfExists(targetPath, rel) {
  if (!fs.existsSync(targetPath)) return null
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true })

  const flatName = rel.replace(/[\\/]/g, '_')
  const backupName = `${Date.now()}__${flatName}.bak`
  const backupPath = path.join(BACKUP_DIR, backupName)
  fs.copyFileSync(targetPath, backupPath)
  return backupName
}

export default {
  command: 'updatefile',
  alias: ['editfile', 'writefile', 'timpafile'],
  category: 'owner',
  description: `> Timpa isi file dengan teks/kode baru, atau ganti file dengan media yang di-reply. Backup versi lama otomatis disimpan ke \`sampah/backup/\` sebelum ditimpa. Kalau file belum ada, otomatis dibuat (beserta foldernya).

*Keterangan Format:*
> \`.updatefile <path>\` lalu baris berikutnya isi teks/kode barunya.
> \`.updatefile <path>\` (reply pesan teks) — isi diambil dari pesan yang di-reply.
> \`.updatefile <path>\` (reply media/dokumen) — file ditimpa pakai media itu.

contoh penggunaan:
\`\`\`.updatefile plugins/owner/test.js
export default {
  command: 'test',
  ...
}\`\`\`
> \`.updatefile settings.js\` (reply pesan berisi kode baru)`,
  help: '<path> (isi baru / reply)',
  onlyOwner: true,

  async execute(m) {
    const rawAfterCommand = (m.text || '').slice(m.prefix.length + m.command.length)
    const { filePath, content: typedContent } = splitPathAndContent(rawAfterCommand)

    if (!filePath) {
      return m.reply('Kasih path file yang mau ditimpa.\nContoh: .updatefile plugins/owner/test.js')
    }

    const check = resolveSafePath(filePath)
    if (!check.ok) return m.reply(`❌ ${check.reason}`)

    const { resolved: targetPath, rel: relPath } = check

    const q = m.quoted
    const rawMsg = m.raw?.message
    const contextInfo = rawMsg?.extendedTextMessage?.contextInfo || rawMsg?.[m.type]?.contextInfo
    const rawQuotedMsg = contextInfo?.quotedMessage
    const mediaObj = q ? (extractMediaMessage(rawQuotedMsg) || extractMediaMessage(reviveBase64Fields(q.full))) : null

    if (!mediaObj && !typedContent && !q?.text) {
      return m.reply(
        'Isi barunya belum ada. Pilih salah satu:\n' +
        '• Ketik langsung setelah path (baris baru)\n' +
        '• Reply pesan teks/kode yang mau dijadiin isi file\n' +
        '• Reply media/dokumen buat ganti file dengan itu'
      )
    }

    try {
      const targetDir = path.dirname(targetPath)
      if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true })

      const backupName = backupIfExists(targetPath, relPath)
      const isNew = !backupName

      let sizeInfo = ''

      if (mediaObj) {
        const stream = await downloadMediaMessage(mediaObj)
        const chunks = []
        for await (const chunk of stream) chunks.push(chunk)
        const buffer = Buffer.concat(chunks)
        fs.writeFileSync(targetPath, buffer)
        sizeInfo = `${(buffer.length / 1024).toFixed(2)} KB`
      } else {
        const finalContent = typedContent || q.text || ''
        fs.writeFileSync(targetPath, finalContent, 'utf-8')
        sizeInfo = `${Buffer.byteLength(finalContent, 'utf-8')} bytes`
      }

      let response = `✅ *File ${isNew ? 'dibuat' : 'ditimpa'}*\n\n`
      response += `\`Path:\` ${relPath}\n`
      response += `\`Size:\` ${sizeInfo}\n`
      if (backupName) response += `\`Backup lama:\` sampah/backup/${backupName}\n`
      response += `\n_Kalau file ini bukan bagian dari sistem hot-reload (.reloadcore), inget jalanin \`.reload\` (plugin) atau \`.restart\` (core/db) biar perubahan ke-apply._`

      return m.reply(response.trim())
    } catch (err) {
      return m.reply(`❌ Gagal update file: ${err?.message || err}`)
    }
  }
}