// plugins/owner/dbmaintenance.js
import fs from 'fs'
import path from 'path'
import { runMaintenanceNow } from '../../lib/dbMaintenance.js'

// Fungsi otomatis mengubah Bytes ke KB/MB/GB
function formatSize(bytes) {
  if (bytes === 0) return '0 Byte'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

export default {
  command: 'dbmaintenance',
  alias: ['dbclean', 'prunedb'],
  category: 'owner',
  description: `> Menjalankan pembersihan & optimasi database pesan (raw_message.db) secara manual.
Bisa spesifik berdasarkan user, grup, atau jumlah hari.

contoh penggunaan:
> \`.dbmaintenance 7\` (Hapus pesan > 7 hari)
> \`.dbmaintenance group\` (Hapus semua pesan di grup ini)
> \`.dbmaintenance @user/reply\` (Hapus pesan dari user tertentu)
> \`.dbmaintenance\` (Default sesuai setting)`,
  onlyOwner: true,
  typing: true,

  async execute(m) {
    const dbPath = path.join(process.cwd(), 'store', 'raw_message.db')
    
    // Ambil ukuran memori awal
    const sizeBefore = fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0

    // Parsing argumen
    const args = m.args || (m.text ? m.text.trim().split(/ +/).slice(1) : [])
    const arg1 = args[0] ? args[0].toLowerCase() : ''
    
    let targetUser = (m.mentionedJid && m.mentionedJid[0]) || (m.quoted ? m.quoted.sender : null)
    let targetGroup = null
    let pruneDays = null
    let criteriaText = ''

    // Logika kriteria pembersihan
    if (targetUser) {
      criteriaText = `Pesan dari @${targetUser.split('@')[0]}`
    } else if (arg1 === 'group' || arg1 === 'grup') {
      if (!m.isGroup) return m.reply('❌ Perintah ini hanya bisa digunakan di dalam grup!')
      targetGroup = m.chat
      criteriaText = `Semua pesan di grup ini`
    } else if (arg1 && !isNaN(arg1)) {
      pruneDays = parseInt(arg1)
      criteriaText = `Pesan lebih tua dari ${pruneDays} hari`
    } else if (arg1 === '') {
      criteriaText = `Pengaturan Default (Dari settings.js)`
    } else {
      return m.reply(`🛠️ *Format Salah!*\n\nContoh penggunaan:\n> .dbmaintenance 7\n> .dbmaintenance group\n> .dbmaintenance @tag/reply`)
    }

    const startTime = Date.now()
    await m.reply(`🧹 Membersihkan database dengan kriteria:\n*${criteriaText}*\nMohon tunggu...`)

    // Eksekusi fungsi backend dengan mengirim parameter filter
    const opts = await runMaintenanceNow({
      user: targetUser,
      group: targetGroup,
      days: pruneDays
    })

    // Ambil ukuran memori akhir
    const sizeAfter = fs.existsSync(dbPath) ? fs.statSync(dbPath).size : 0
    let spaceSaved = sizeBefore - sizeAfter
    if (spaceSaved < 0) spaceSaved = 0

    const processTime = ((Date.now() - startTime) / 1000).toFixed(2)

    // Susun laporan dasbor
    const reportMsg = `🛠️ *DATABASE MAINTENANCE REPORT* 🛠️\n` +
      `────────────────────────\n` +
      `✅ *Status:* Selesai\n` +
      `🗑️ *Kriteria:* ${criteriaText}\n` +
      `⏱️ *Waktu Proses:* ${processTime} Detik\n\n` +
      `📊 *Statistik raw_message.db:*\n` +
      ` ◦ Ukuran Awal   : ${formatSize(sizeBefore)}\n` +
      ` ◦ Ukuran Akhir  : ${formatSize(sizeAfter)}\n` +
      ` ◦ Ruang Bebas   : ${formatSize(spaceSaved)} (Dibersihkan)\n\n` +
      `💡 *Note:* Beban pembacaan database sekarang lebih ringan.`

    return m.reply(reportMsg)
  }
}