import { filterEncNodes, extractReplayableAttrs } from '../../lib/rawMessageUtils.js'
import { getRawMessageById } from '../../db/rawMessage.js'

export default {
  command: 'resend',
  alias: ['clone', 'copy', 'sendagain'],
  category: 'tools',
  description: 'Mengirim ulang pesan secara persis (Clone Payload dari Database).',
  help: '(reply pesan)',
  adminOnly: true,

  async execute(m, { sock, q }) {
    if (!m.quoted) {
      return sock.message.send(m.chat, { 
        text: '❌ Reply pesan yang mau di-resend.' 
      }, { 
        additionalAttributes: { type: "text" } 
      })
    }

    try {
      // 1. Ambil ID dari pesan yang di-reply
      const quotedId = m.quoted?.id || m.quoted?.key?.id || m.raw?.message?.extendedTextMessage?.contextInfo?.stanzaId
      
      // 2. Tarik log murni dari database SQLite lu
      const stored = quotedId ? getRawMessageById(quotedId) : null
      
      // 3. Ekstrak payload message nya
      let rawMessage = stored?.raw?.message 
        || m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage 
        || m.quoted?.message 
        || m.quoted?.full 
        || q?.message 
        || q?.json

      if (rawMessage?.message) {
        rawMessage = rawMessage.message
      }

      if (!rawMessage) {
        return sock.message.send(m.chat, { 
          text: '❌ Gagal mengekstrak raw message, pastikan pesan ada di database bot.' 
        }, { 
          additionalAttributes: { type: "text" } 
        })
      }

      // Bersihkan contextInfo bawaan (opsional tapi penting).
      // Biar pesannya murni berdiri sendiri (gak ngutip command '.resend' lu)
      const msgKey = Object.keys(rawMessage)[0];
      if (rawMessage[msgKey]?.contextInfo) {
        delete rawMessage[msgKey].contextInfo.stanzaId;
        delete rawMessage[msgKey].contextInfo.participant;
        delete rawMessage[msgKey].contextInfo.quotedMessage;
      }

      // 4. Tarik Nodes & Attributes kayak di crm.js
      const nodes = filterEncNodes(stored?.raw?.nodes || m.quoted?.nodes || q?.nodes || null)
      const baseAttrs = extractReplayableAttrs(m.quoted?.json || q?.json) || {}
      
      const finalAttrs = { ...baseAttrs, type: "text" }

      // 5. EKSEKUSI RESEND INSTAN
      // Tembakkan rawMessage secara murni bersama atribut yang udah diekstrak
      await sock.message.send(
        m.chat, 
        rawMessage, 
        {
          additionalAttributes: finalAttrs,
          ...(nodes && nodes.length > 0 ? { additionalNodes: nodes } : {})
        }
      )

    } catch (err) {
      console.error('[RESEND] Error:', err)
      return sock.message.send(m.chat, { 
        text: `❌ Gagal resend pesan:\n${err.message || err}` 
      }, { 
        additionalAttributes: { type: "text" } 
      })
    }
  }
}