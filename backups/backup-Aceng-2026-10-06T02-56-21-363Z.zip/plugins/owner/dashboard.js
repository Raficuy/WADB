// plugins/owner/dashboard.js

import os from 'os'
import { getFullDashboardStats } from '../../lib/dashboardStats.js'
import { config } from '../../settings.js'

function fmt(n) {
  return new Intl.NumberFormat('id-ID').format(n || 0)
}

function fmtJid(jid) {
  return jid ? jid.split('@')[0] : '-'
}

function pct(part, total) {
  if (!total) return '0%'
  return Math.round((part / total) * 100) + '%'
}

function fmtUptime(seconds) {
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const mi = Math.floor((seconds % 3600) / 60)
  const parts = []
  if (d) parts.push(`${d}h`)
  if (h) parts.push(`${h}j`)
  parts.push(`${mi}m`)
  return parts.join(' ')
}

function fmtBytes(bytes) {
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

export default {
  command: 'dashboard',
  alias: ['dash', 'infobot'],
  category: 'owner',
  description: '> Ringkasan lengkap: total user, grup, pesan, sampe statistik RPG -- semuanya dalam satu pesan.',
  onlyOwner: true,

  async execute(m, { sock }) {
    const data = getFullDashboardStats()
    const { contacts, groups, messages, rpg } = data

    const creds = sock.getCredentials?.()
    const botJid = creds?.meJid ? fmtJid(creds.meJid) : config.botNumber
    const connStatus = creds?.meJid ? '🟢 Connected' : '🔴 Belum connect'

    const pluginCount = global.plugins ? new Set(global.plugins.values()).size : 0

    let text = ` *BOT DASHBOARD*\n_Update: ${new Date(data.generatedAt).toLocaleString('id-ID')}_\n\n`

    text += `*INFO BOT*\n\n`
    text += `• Nama Bot: *${config.botName}*\n`
    text += `• Nomor Bot: *${botJid}* (${connStatus})\n`
    text += `• Owner: *${config.ownerName}* (${config.owner})\n`
    text += `• Prefix: ${config.prefixes.join(' ')}\n`
    text += `• Total Plugin: *${fmt(pluginCount)}* command\n`
    text += `• Uptime: *${fmtUptime(process.uptime())}*\n`
    text += `• RAM Bot: ${fmtBytes(process.memoryUsage().rss)} / Total Server: ${fmtBytes(os.totalmem())}\n`
    text += `• Node: ${process.version} | Platform: ${process.platform}\n\n`

    text += `\n *USER & GRUP*\n\n`
    text += `• Total kontak dikenal: *${fmt(contacts.total)}*\n`
    text += `• Total grup: *${fmt(groups.total)}*\n\n`

    text += `\n *PESAN*\n\n`
    text += `• Total tercatat: *${fmt(messages.totalMessages)}*\n`
    text += `• 24 jam terakhir: *${fmt(messages.last24h)}*\n`
    text += `• Grup vs Private: ${pct(messages.groupVsPrivate.group, messages.totalMessages)} / ${pct(messages.groupVsPrivate.private, messages.totalMessages)}\n`
    text += `• Teks vs Media: ${pct(messages.mediaVsText.text, messages.totalMessages)} / ${pct(messages.mediaVsText.media, messages.totalMessages)}\n\n`

    if (messages.topSenders.length) {
      text += `* *Top Pengirim Pesan:*\n`
      messages.topSenders.slice(0, 5).forEach((s, i) => {
        text += `${i + 1}. ${s.push_name || fmtJid(s.sender_jid)} - ${fmt(s.c)} pesan\n`
      })
      text += '\n'
    }

    if (messages.topCommands.length) {
      text += `* *Top Command:*\n`
      messages.topCommands.slice(0, 5).forEach((c, i) => {
        text += `${i + 1}. .${c.command} - ${fmt(c.c)}x\n`
      })
      text += '\n'
    }

    text += `\n *RPG*\n\n`
    text += `• Total player: *${fmt(rpg.totalPlayers)}*\n`
    text += `• Total guild: *${fmt(rpg.totalGuilds)}*\n`
    text += `• Total ekonomi: *Rp${fmt(rpg.totalBalance)}*\n`
    text += `• Avg level: *${rpg.avgLevel}*\n`
    if (rpg.marketDate) text += `• Black market: reset ${rpg.marketDate}, ${rpg.marketStockCount} item tersisa\n`
    text += '\n'

    if (rpg.topRichest.length) {
      text += `🏆 *Top Terkaya:*\n`
      rpg.topRichest.slice(0, 5).forEach((u, i) => {
        text += `${i + 1}. ${fmtJid(u.jid)} - Rp${fmt(u.total)} (Lv${u.level})\n`
      })
      text += '\n'
    }

    if (rpg.topLevel.length) {
      text += `⭐ *Top Level:*\n`
      rpg.topLevel.slice(0, 5).forEach((u, i) => {
        text += `${i + 1}. ${fmtJid(u.jid)} - Lv${u.level} (XP ${fmt(u.xp)}${u.prestige ? `, P${u.prestige}` : ''})\n`
      })
      text += '\n'
    }

    const jobEntries = Object.entries(rpg.jobCounts).sort((a, b) => b[1] - a[1])
    if (jobEntries.length) {
      text += `💼 *Distribusi Pekerjaan:*\n`
      jobEntries.slice(0, 8).forEach(([job, count]) => {
        text += `• ${job}: ${fmt(count)}\n`
      })
    }

    return m.reply(text.trim())
  }
}