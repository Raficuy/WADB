import { startJadibot, sanitizeNumber, activeCount, maxActive } from '../../lib/jadibot.js'

export default {
  command: 'jadibot',
  category: 'bot',
  description: `Jadikan nomor WA kamu sendiri sebagai bot tambahan (sub-bot), memakai kode pairing.\n\n*Format:*\n> .jadibot 628xxxxxxxxxx\n> .jadibot 628xxxxxxxxxx KODEUNIK (8 karakter, tanpa 0/I/O/U)`,
  help: '<nomor> <kode custom opsional>',
  typing: true,
  wait: true,
  onlyOwner: true,

  async execute(m, { sock, args }) {
    const number = sanitizeNumber(args[0])
    if (!number || number.length < 8) {
      return m.reply(`Nomor tidak valid.\nContoh: ${m.prefix}${m.command} 628123456789`)
    }

    let customCode = args[1] ? args[1].trim().toUpperCase() : null
    if (customCode && (customCode.length !== 8 || !/^[1-9A-HJ-NP-TV-Z]{8}$/.test(customCode))) {
      return m.reply('Kode custom harus 8 karakter, tanpa angka 0 dan huruf I, O, U.')
    }

    if (activeCount() >= maxActive()) {
      return m.reply(`Batas jadibot aktif sudah tercapai (${maxActive()}). Coba lagi nanti.`)
    }

    let code
    try {
      code = await startJadibot({ mainSock: sock, number, ownerJid: m.sender, customCode })
    } catch (err) {
      return m.reply(`Gagal membuat jadibot: ${err?.message || err}`)
    }

    await sock.message.send(m.chat, {
      interactiveMessage: {
        header: { title: 'Kode Pairing Jadibot', hasMediaAttachment: false },
        body: {
          text: `Nomor: ${number}\n\nBuka WhatsApp di HP nomor itu, masuk ke Perangkat Tertaut > Tautkan dengan nomor telepon, lalu tempel kode di bawah.\n\nKode berlaku singkat, buruan sebelum kedaluwarsa.`
        },
        footer: { text: 'Tekan tombol untuk salin kode' },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_copy',
              buttonParamsJson: JSON.stringify({
                display_text: 'Salin Kode',
                copy_code: code
              })
            }
          ],
          messageVersion: 1
        }
      }
    }, { quote: m.raw })
  }
}