export default {
    command: 'dmsg',
    alias: ['delmsg', 'sirna'],
    category: 'owner',
    description: 'Menghapus pesan orang lain tanpa akses admin (menggunakan trik edit null byte).',
    onlyOwner: true,
    isGroup: true,

    execute: async (m, { sock }) => {
        if (!m.quoted) {
            return m.reply('Reply pesan yang ingin dihapus.')
        }

        const stanzaId = m.quoted.key.id
        if (!stanzaId) {
            return m.reply('Gagal mendapatkan ID pesan target.')
        }

        try {
            // 1. Kirim pesan pancingan (groupStatusMessageV2)
            const temp1 = await sock.message.send(m.chat, {
                groupStatusMessageV2: {
                    message: {
                        extendedTextMessage: {
                            text: '',
                            contextInfo: { isGroupStatus: true }
                        }
                    }
                }
            }, {})

            const tempId = temp1.id || (temp1.key && temp1.key.id)

            // 2. Kirim pesan edit ke tempId, ID-nya ditimpa ke stanzaId target, isinya \0 (null byte)
            const temp2 = await sock.message.send(m.chat, '\0', {
                editKey: { id: tempId },
                id: stanzaId 
            })

            const temp2Id = temp2.id || (temp2.key && temp2.key.id)

            // 3. Jeda sejenak sebelum dihapus
            await new Promise(resolve => setTimeout(resolve, 100))

            // 4. Hapus menggunakan native revoke zapo-js
            await Promise.allSettled([
                sock.message.send(m.chat, {
                    type: 'revoke',
                    target: { remoteJid: m.chat, id: tempId, fromMe: true }
                }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true }),
                sock.message.send(m.chat, {
                    type: 'revoke',
                    target: { remoteJid: m.chat, id: temp2Id, fromMe: true }
                }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true })
            ])

        } catch (e) {
            console.error('[dmsg]', e)
            await m.reply('Error: ' + (e?.message || e))
        }
    }
}