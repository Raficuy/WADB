import { execFile } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import path from 'path'
import os from 'os'
import { config } from '../../settings.js'
import { excludeFolders, excludeFiles } from '../../lib/backupExclude.js'

const execFilePromise = promisify(execFile)

const HARD_EXCLUDES = [

  'node_modules',
  '.git',
  '.cache',
  '.npm',
  '.local',
  'backup-tmp',
  'tmp',
  'sampah',

  'session',
  'store',
  'gemini_token.json',
  '.env',

  '*.zip',
  '*.tar.gz',
  '*.log',
  'zapo-js-main*'
]

const MUST_KEEP = ['package.json', 'package-lock.json']

function normalizePattern(p) {
  return String(p || '').trim().replace(/^\.\//, '').replace(/\/+$/, '')
}

function globToRegex(glob) {
  const escaped = glob
    .replace(/[.+^${}()|[\]\\]/g, '\\$&')
    .replace(/\*/g, '.*')
    .replace(/\?/g, '.')
  return new RegExp(`^${escaped}$`)
}

function variants(p) {
  return [p, `${p}/`, `${p}/*`, `*/${p}`, `*/${p}/`, `*/${p}/*`]
}

function buildExcludePatterns() {
  const raw = [
    ...HARD_EXCLUDES,
    ...(excludeFolders || []),
    ...(excludeFiles || [])
  ].map(normalizePattern).filter(Boolean)

  const safe = []
  for (const p of new Set(raw)) {
    const dangerous = variants(p).some((v) => {
      const re = globToRegex(v)
      return MUST_KEEP.some((f) => re.test(f))
    })
    if (dangerous) {
      console.warn(`[BACKUP] pola exclude "${p}" ngebuang file penting (${MUST_KEEP.join(', ')}), pola ini diabaikan.`)
      continue
    }
    safe.push(p)
  }
  return safe
}

async function listArchive(outPath, isTar) {
  try {
    const { stdout } = isTar
      ? await execFilePromise('tar', ['-tzf', outPath], { maxBuffer: 256 * 1024 * 1024 })
      : await execFilePromise('unzip', ['-Z1', outPath], { maxBuffer: 256 * 1024 * 1024 })
    return stdout.split('\n').map((l) => l.replace(/^\.\//, '').trim()).filter(Boolean)
  } catch {
    return null // unzip/tar listing ga tersedia, verifikasi dilewati
  }
}

async function makeZip(projectRoot, outPath, patterns) {
  const args = ['-r', '-q', outPath, '.', '-x', ...patterns.flatMap(variants)]
  try {
    await execFilePromise('zip', args, { cwd: projectRoot, maxBuffer: 64 * 1024 * 1024 })
  } catch (err) {
    if (typeof err.code === 'number' && [1, 12, 18].includes(err.code)) {
      console.warn('[BACKUP] zip warning, lanjut cek hasil:', err.message)
      return
    }
    throw err
  }
}

async function makeTar(projectRoot, outPath, patterns) {
  const args = ['-czf', outPath, ...patterns.map((p) => `--exclude=${p}`), '-C', projectRoot, '.']
  try {
    await execFilePromise('tar', args, { maxBuffer: 64 * 1024 * 1024 })
  } catch (err) {

    if (err.code === 1) {
      console.warn('[BACKUP] tar warning, lanjut cek hasil:', err.message)
      return
    }
    throw err
  }
}

let running = false

export default {
  command: 'backup',
  alias: ['getsc', 'getscript', 'backupproject'],
  category: 'owner',
  description: `> Membuat backup project (Source Code) dan mengirimkannya ke grup tujuan.\n\ncontoh penggunaan:\n> \`.backup\` (kirim ke grup di settings)\n> \`.backup here\` (kirim ke chat ini)`,
  onlyOwner: true,
  typing: true,
  wait: true,

  async execute(m, { sock, args }) {
    const sendHere = ['here', 'ini', 'chat'].includes(args?.[0]?.toLowerCase())
    const target = sendHere ? m.chat : config.jidGroup

    if (!target) {
      return m.reply('`config.jidGroup` belum disetel di settings.js')
    }
    if (running) {
      return m.reply('Backup lain lagi jalan, tunggu selesai dulu.')
    }
    running = true

    const projectRoot = process.cwd()
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const baseName = `backup-${config.botName || 'bot'}-${timestamp}`
    const patterns = buildExcludePatterns()

    let useTar = false
    let fileName = `${baseName}.zip`
    let outPath = path.join(os.tmpdir(), fileName)

    try {
      try {
        await makeZip(projectRoot, outPath, patterns)
      } catch (err) {

        if (err.code !== 'ENOENT') throw err
        console.warn('[BACKUP] zip ga ditemukan, fallback ke tar.gz')
        useTar = true
        fileName = `${baseName}.tar.gz`
        outPath = path.join(os.tmpdir(), fileName)
        await makeTar(projectRoot, outPath, patterns)
      }

      const stat = await fs.promises.stat(outPath).catch(() => null)
      if (!stat || !stat.size) {
        throw new Error('Hasil backup kosong/0 byte, kemungkinan perintah zip/tar gagal.')
      }

      const sizeMB = (stat.size / 1024 / 1024).toFixed(2)

      const entries = await listArchive(outPath, useTar)
      let checkLine = ''
      if (entries) {
        const missing = MUST_KEEP.filter((f) => !entries.includes(f))
        checkLine = missing.length
          ? `⚠️ Tidak ikut: ${missing.join(', ')}\n`
          : `✅ package.json & package-lock.json ikut\n`
        checkLine += `🗂️ Total file: ${entries.filter((e) => !e.endsWith('/')).length}\n`
      }

      const caption =
        `*── 「 BACKUP BOT 」 ──*\n\n` +
        `👤 Pengirim: ${m.pushName || 'Owner'}\n` +
        `📄 File: ${fileName}\n` +
        `📦 Ukuran: ${sizeMB} MB\n` +
        checkLine +
        `📅 Waktu: ${new Date().toLocaleString('id-ID')}`

      await sock.message.send(target, {
        type: 'document',
        media: outPath,
        mimetype: useTar ? 'application/gzip' : 'application/zip',
        fileName,
        caption
      })

      await m.reply(
        `✅ *Backup Berhasil!*\n\n📄 ${fileName} (${sizeMB} MB)\n` +
        checkLine +
        `📤 Dikirim ke: \`${target}\``
      )
    } catch (err) {
      console.error('[BACKUP] gagal:', err?.stack || err)
      return m.reply(`❌ *Gagal membuat backup:*\n\n${err.message || err}\n\n_(Catatan: pastikan package 'zip' atau 'tar' sudah ter-install di Pterodactyl/VPS kamu)_`)
    } finally {
      running = false
      fs.promises.unlink(outPath).catch(() => {})
    }
  }
}