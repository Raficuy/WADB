import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'demo',
  alias: ['tour', 'showcase'],
  category: 'main',
  description: 'Live tour MessageBuilder v4.7',
  typing: true,

  async execute(m, { sock }) {
    try {
      const rich = new AIRich(sock)
        .setTitle('Hello' + m.pushName)
        .addText('Hey! Welcome to [Aceng Bot](wa.me/6283854944887) 👋', { id: 'intro' })
        .setFooter('Built with Zapo')

      await rich.send(m.chat)
      await delay(1500)

      rich.addText('This is a live tour of Dynaimik Ai Rich. Everything below will be built directly into this message.', { insertAt: 'intro', id: 'welcome' })
      rich.addSuggest(['Paduka Rafi', 'Dynamic AIRich', 'Aceng'])
      await rich.sendEdit(m.chat)
      await delay(1800)

      rich.addText('First, loading states. The item appears first, then gets replaced when the content is ready.', { insertAt: 'welcome', id: 'loading_intro' })
      await rich.sendEdit(m.chat)
      await delay(1500)

      rich.addImage('', {
        status: 'GENERATING',
        update_text: 'Generating image...',
        insertAt: 'loading_intro',
        id: 'image1',
      })
      await rich.sendEdit(m.chat)
      await delay(3000)

      rich.addImage('https://cdn.ornzora.eu.cc/2a639cd2-5c33-49e3-982f-77f471c9313f-FIORA.jpg', { replace: 'image1' })
      await rich.sendEdit(m.chat)
      await delay(2000)

      rich.addText('Video supports the same loading → replace flow.', { insertAt: 'image1', id: 'video_intro' })
      await rich.sendEdit(m.chat)
      await delay(1500)

      rich.addVideo('', {
        status: 'GENERATING',
        estimatedTime: 3000,
        insertAt: 'video_intro',
        id: 'video1',
      })
      await rich.sendEdit(m.chat)
      await delay(4000)

      rich.addVideo('https://cdn.ornzora.eu.cc/3bb12237-2365-4a76-a4e2-635faea6d54c-FIORA.mp4', { replace: 'video1' })
      await rich.sendEdit(m.chat)
      await delay(2000)

      rich.addText('Now for code blocks with syntax highlighting.', { insertAt: 'video1', id: 'code_intro' })
      await rich.sendEdit(m.chat)
      await delay(1200)

      rich.addCode(
        'javascript',
        `function greet(name) {\n\treturn \`Hello, \${name}!\`\n}\ngreet('Aceng')`,
        { insertAt: 'code_intro', id: 'code1' }
      )
      await rich.sendEdit(m.chat)
      await delay(2500)

      rich.addText('Tables are supported too.', { insertAt: 'code1', id: 'table_intro' })
      await rich.sendEdit(m.chat)
      await delay(1200)

      rich.addTable(
        [
          ['Name', 'Role'],
          ['[Rafi](https://google.com/)', 'Owner'],
          ['Aceng', 'Assistant'],
        ],
        {
          insertAt: 'table_intro',
          id: 'table1',
        }
      )
      await rich.sendEdit(m.chat)
      await delay(2500)

      rich.addText('You can also build content in another AIRich instance and reuse its items.', { insertAt: 'table1', id: 'mix_intro' })
      await rich.sendEdit(m.chat)
      await delay(1800)

      const items = new AIRich(sock)
        .addProduct({
          title: 'Paduka Rafi',
          brand: 'Rafi',
          price: 'MessageBuilderV4.7',
          product_url: 'google.com',
          image_url: 'https://cdn.ornzora.eu.cc/2a639cd2-5c33-49e3-982f-77f471c9313f-FIORA.jpg',
        })
        .addPost({
          profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
          title: 'Behind the build',
          username: 'google.com',
          verified: true,
          caption: 'Built separately, then mixed into another AIRich message.',
          thumbnail: 'https://cdn.ornzora.eu.cc/69551181-48c0-4466-b22d-235a93db8a63-FIORA.jpg',
          url: 'https://google.com/',
          source_app: 'INSTAGRAM',
        })
        .addReels({
          profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
          username: 'google.com',
          thumbnail: 'https://cdn.ornzora.eu.cc/6b1c1b29-9b80-4cfa-9c57-d008d60e18bc-FIORA.jpg',
          url: 'https://google.com/',
          verified: true,
        }).items

      rich.addText('These cards came from a completely separate AIRich instance.', { insertAt: 'mix_intro', id: 'mix_note' })
      await rich.sendEdit(m.chat)
      await delay(1500)

      rich.addSection(AIRich.newLayout('HScroll', items), { insertAt: 'mix_note', id: 'mixed_items' })
      await rich.sendEdit(m.chat)
      await delay(3000)

      rich.addTip('The Product and Post above were created separately, extracted with .items, then inserted here using .addSection().', { insertAt: 'mixed_items', id: 'mix_explain' })
      await rich.sendEdit(m.chat)
      await delay(2500)

      rich.addText('You can continue building underneath the mixed section normally.', { insertAt: 'mix_explain', id: 'after_mix' })
      await rich.sendEdit(m.chat)
      await delay(1800)

      rich.addSource(
        [
          {
            icon: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
            url: 'https://google.com/',
            title: 'MessageBuilderV4.7',
            subtitle: 'GitHub Gist . RafiCuy',
          },
        ],
        {
          insertAt: 'after_mix',
          id: 'source1',
        }
      )
      await rich.sendEdit(m.chat)
      await delay(1800)

      rich.addReels(
        [
          {
            profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
            username: 'google.com',
            thumbnail: 'https://cdn.ornzora.eu.cc/2a639cd2-5c33-49e3-982f-77f471c9313f-FIORA.jpg',
            url: 'https://google.com/',
            verified: true,
          },
          {
            profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
            username: 'google.com',
            thumbnail: 'https://cdn.ornzora.eu.cc/69551181-48c0-4466-b22d-235a93db8a63-FIORA.jpg',
            url: 'https://google.com/',
            verified: true,
          },
          {
            profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
            username: 'RafiCuy',
            thumbnail: 'https://cdn.ornzora.eu.cc/6b1c1b29-9b80-4cfa-9c57-d008d60e18bc-FIORA.jpg',
            url: 'https://google.com/',
            verified: true,
          },
          {
            profile: 'https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg',
            username: 'Rafi',
            thumbnail: 'https://cdn.ornzora.eu.cc/6b07d572-8aeb-4bbe-9faa-f226bacd5c99-FIORA.jpg',
            url: 'https://google.com/',
            verified: true,
          },
        ],
        {
          insertAt: 'source1',
          id: 'reels1',
        }
      )
      await rich.sendEdit(m.chat)
      await delay(2200)

      rich.addWidget(
        {
          title: 'Quick Actions',
          sections: [],
          actions: [
            {
              label: 'Join Channel',
              kind: 'OTHER',
              state: 'PENDING',
              id: 'channel'
            },
          ],
        },
        {
          insertAt: 'reels1',
          id: 'widget1',
        }
      )
      await rich.sendEdit(m.chat)
      await delay(2000)

      rich.addFooterAction(
        {
          text: 'Visit Channel',
          url: 'https://whatsapp.com/channel/0029Vb5h45DKWEKjMyUUbg1O',
        },
        {
          id: 'footer1',
        }
      )
      await rich.sendEdit(m.chat)
      await delay(2500)

      rich.addMetadata('That is the basic workflow: create, insert, replace, mix, and continue building downward in the same editable message.', { id: 'cleanup_intro', insertAt: 'reels1' })
      await rich.sendEdit(m.chat)
      await delay(3000)

      rich.delete('cleanup_intro')
      await rich.sendEdit(m.chat)
      await delay(400)

      rich.addText(
        'That’s the full dinamic tour — built live, edited live, and mixed from separate AIRich instances.\n\nFor more information, check it out [here](wa.me/6283854944887).',
        { insertAt: 'widget1', id: 'final' }
      )
      await rich.sendEdit(m.chat)

    } catch (err) {
      return m.reply(`Sistem error: ${err.message || err}`)
    }
  }
}