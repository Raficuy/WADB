// plugins/owner/delfile.js

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const ROOT_DIR = path.join(__dirname, '..', '..')
const TRASH_DIR = path.join(ROOT_DIR, 'sampah', 'deleted')

const PROTECTED = ['node_modules', '.git', 'session', 'sampah', '.env']

function resolveSafePath(rawPath) {
  const cleaned = String(rawPath || '').trim().replace(/^\/+/, '')
  const resolved = path.resolve(ROOT_DIR, cleaned)
  const rel = path.relative(ROOT_DIR, resolved)

  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) {
    return { ok: false, reason: 'Path keluar dari folder project. Gak diizinkan.' }
  }

  const firstSegment = rel.split(path.sep)[0]
  if (PROTECTED.includes(firstSegment)) {
    return { ok: false, reason: `\`${firstSegment}\` itu folder/file terproteksi, gak boleh dihapus lewat sini.` }
  }

  return { ok: true, resolved, rel }
}

export default {
  command: 'delfile',
  alias: ['deletefile', 'rmfile', 'hapusfile'],
  category: 'owner',
  description: `> Hapus file atau folder dari project (soft-delete, dipindah ke \`sampah/deleted/\` dulu -- gak langsung ilang permanen).

*Keterangan Format:*
> \`<path>\` = path file/folder relatif ke root project.
> tambahin \`--permanent\` di akhir buat hapus permanen (skip trash).
> tambahin \`-r\` kalau targetnya folder.

contoh penggunaan:
> \`.delfile plugins/owner/test.js\`
> \`.delfile temp/cache -r\`
> \`.delfile plugins/owner/test.js --permanent\``,
  help: '<path> [-r] [--permanent]',
  onlyOwner: true,

  async execute(m, { args }) {
    if (!args[0]) {
      return m.reply('Kasih path file/foldernya.\nContoh: .delfile plugins/owner/test.js')
    }

    const flags = args.slice(1).map(a => a.toLowerCase())
    const isRecursive = flags.includes('-r') || flags.includes('--recursive')
    const isPermanent = flags.includes('--permanent') || flags.includes('--hard')

    const check = resolveSafePath(args[0])
    if (!check.ok) return m.reply(`❌ ${check.reason}`)

    const { resolved: targetPath, rel: relPath } = check

    if (!fs.existsSync(targetPath)) {
      return m.reply(`File/folder tidak ditemukan:\n\`${relPath}\``)
    }

    const stat = fs.statSync(targetPath)

    if (stat.isDirectory() && !isRecursive) {
      return m.reply(`\`${relPath}\` itu folder. Tambahin flag \`-r\` kalau emang mau dihapus.\nContoh: .delfile ${args[0]} -r`)
    }

    try {
      if (isPermanent) {
        fs.rmSync(targetPath, { recursive: true, force: true })
        return m.reply(`🗑️ *Berhasil dihapus permanen*\n\`${relPath}\``)
      }

      if (!fs.existsSync(TRASH_DIR)) fs.mkdirSync(TRASH_DIR, { recursive: true })

      const flatName = relPath.replace(/[\\/]/g, '_')
      const trashName = `${Date.now()}__${flatName}`
      const trashPath = path.join(TRASH_DIR, trashName)

      fs.renameSync(targetPath, trashPath)

      return m.reply(
        ` *Berhasil dihapus (soft-delete)*\n` +
        `\`${relPath}\`\n\n` +
        `Dipindah ke: \`sampah/deleted/${trashName}\`\n` +
        `_Mau balikin lagi? Pindahin manual dari folder itu, atau pakai \`--permanent\` lain kali kalau emang yakin._`
      )
    } catch (err) {
      return m.reply(`❌ Gagal hapus: ${err?.message || err}`)
    }
  }
}