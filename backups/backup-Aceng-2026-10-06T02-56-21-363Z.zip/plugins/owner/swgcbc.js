import { buildStatusPayload } from '../../lib/statusMessage.js'
import { setSession, clearSession } from '../../lib/broadcastSession.js'
import { getRecentGroupChats } from '../../db/rawMessage.js'
import { getCachedGroupMetadata, getGroupMetadata } from '../../db/groupCache.js'

const MAX_GROUPS = 40

async function resolveGroups(sock, rows) {
  const results = await Promise.all(rows.map(async (row) => {
    const cached = getCachedGroupMetadata(row.jid)
    const meta = cached || await getGroupMetadata(row.jid, sock).catch(() => null)
    if (!meta) return null
    return {
      jid: row.jid,
      name: meta.subject || row.jid.split('@')[0],
      size: meta.participants?.length || 0
    }
  }))
  return results.filter(Boolean)
}

export default {
  command: 'swgcbc',
  alias: ['swgcremote', 'broadcaststatus'],
  category: 'owner',
  description: `Kirim status grup dari jarak jauh (tidak harus dari dalam grup). Reply pesan yang mau dijadikan status, nanti muncul tombol pilih grup tujuan.\n\n*Format:*\n> .swgcbc [teks|emoji] (reply pesan)\n> .swgcbc batal`,
  help: '[teks|emoji] (reply pesan)',
  onlyOwner: true,

  async execute(m, { sock, args }) {
    if (args[0]?.toLowerCase() === 'batal') {
      clearSession(m.sender)
      return m.reply('Sesi swgcbc dibatalkan.')
    }

    if (!m.quoted) return m.reply('Reply pesan yang mau dijadikan status grup!')
    if (!m.quoted.full) return m.reply('Data pesan tidak ditemukan!')

    const input = args.join(' ').trim()
    const payload = buildStatusPayload(m.quoted.full, input)
    if (!payload) return m.reply('Tipe pesan tidak dikenali atau tidak didukung!')

    const rows = getRecentGroupChats(MAX_GROUPS)
    if (!rows.length) return m.reply('Belum ada data grup yang dikenali bot.')

    const groups = await resolveGroups(sock, rows)
    if (!groups.length) return m.reply('Tidak ada grup aktif yang berhasil diverifikasi.')

    setSession(m.sender, { msgType: payload.msgType, raw: payload.raw, groups })

    const rows_ = groups.map((g, i) => ({
      header: '',
      title: g.name.length > 60 ? g.name.slice(0, 57) + '...' : g.name,
      description: `${g.size} anggota`,
      id: `.swgcbcsend ${i}`
    }))

    const payload_ = {
      interactiveMessage: {
        header: { title: 'Pilih Grup Tujuan', hasMediaAttachment: false },
        body: { text: `Pesan siap dikirim sebagai status grup.\nPilih salah satu grup di bawah ini (${groups.length} grup).` },
        footer: { text: 'Sesi berlaku 15 menit' },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'single_select',
              buttonParamsJson: JSON.stringify({
                title: 'Pilih Grup',
                sections: [{ title: 'Grup tersedia', highlight_label: '', rows: rows_ }]
              })
            }
          ],
          messageVersion: 1
        }
      }
    }

    await sock.message.send(m.chat, payload_, {
      quote: m.raw,
      additionalNodes: [
        {
          tag: 'biz',
          attrs: {},
          content: [
            {
              tag: 'interactive',
              attrs: { type: 'native_flow', v: '1' },
              content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
            }
          ]
        }
      ]
    })
  }
}