import axios from 'axios'

// Sinkronisasi memori global sama amprem.js
global.tmSessions = global.tmSessions || new Map() // key: sender jid -> session
global.tmSessionsByAddress = global.tmSessionsByAddress || new Map() // key: email address -> session

// Coba beberapa provider tempmail bergantian (1secmail udah mati per laporan user),
// jadi kalau satu down, otomatis fallback ke yang lain.
async function createTempEmail() {
  try {
    const res = await axios.get('https://api.tempmail.lol/v2/inbox/create', { timeout: 6000 })
    if (res.data?.address && res.data?.token) {
      return { status: true, provider: 'tempmail.lol', address: res.data.address, token: res.data.token }
    }
  } catch (e) { /* lanjut ke provider berikutnya */ }

  try {
    const domRes = await axios.get('https://api.mail.tm/domains', { timeout: 6000 })
    const domains = (domRes.data?.['hydra:member'] || []).filter(d => d.isActive && !d.isPrivate)
    const domain = (domains[Math.floor(Math.random() * domains.length)] || domRes.data?.['hydra:member']?.[0])?.domain
    if (!domain) throw new Error('no domain')

    const address = `bot${Date.now()}${Math.floor(Math.random() * 1000)}@${domain}`
    const password = 'Pass' + Math.random().toString(36).slice(-8) + 'A1!'

    await axios.post('https://api.mail.tm/accounts', { address, password }, { timeout: 6000 })
    const tokenRes = await axios.post('https://api.mail.tm/token', { address, password }, { timeout: 6000 })

    if (tokenRes.data?.token) {
      return { status: true, provider: 'mail.tm', address, token: tokenRes.data.token }
    }
  } catch (e) { /* lanjut ke provider berikutnya */ }

  try {
    const res = await axios.get('https://api.guerrillamail.com/ajax.php?f=get_email_address', { timeout: 6000 })
    if (res.data?.email_addr && res.data?.sid_token) {
      return { status: true, provider: 'guerrillamail', address: res.data.email_addr, token: res.data.sid_token }
    }
  } catch (e) { /* habis, semua provider gagal */ }

  return { status: false, error: 'Semua provider tempmail lagi down/diblokir, coba lagi beberapa saat lagi.' }
}

async function getTempMailMessages(tempMailObj) {
  if (!tempMailObj || !tempMailObj.token) return { status: false, emails: [] }
  const { provider, token } = tempMailObj

  if (provider === 'tempmail.lol') {
    try {
      const res = await axios.get(`https://api.tempmail.lol/v2/inbox?token=${token}`, { timeout: 8000 })
      return { status: true, emails: res.data ? (res.data.emails || []) : [] }
    } catch (err) { return { status: false, emails: [] } }
  }
  if (provider === 'mail.tm') {
    try {
      const res = await axios.get('https://api.mail.tm/messages', { headers: { Authorization: `Bearer ${token}` }, timeout: 8000 })
      const msgs = res.data ? (res.data['hydra:member'] || []) : []
      const detailedEmails = []
      for (let i = 0; i < msgs.length; i++) {
        try {
          const detail = await axios.get(`https://api.mail.tm/messages/${msgs[i].id}`, { headers: { Authorization: `Bearer ${token}` }, timeout: 5000 })
          detailedEmails.push({
            subject: detail.data.subject || 'No Subject',
            from: detail.data.from?.address || '',
            body: detail.data.text || '',
            html: detail.data.html ? detail.data.html.join(' ') : ''
          })
        } catch (e) {}
      }
      return { status: true, emails: detailedEmails }
    } catch (err) { return { status: false, emails: [] } }
  }
  if (provider === 'guerrillamail') {
    try {
      const res = await axios.get(`https://api.guerrillamail.com/ajax.php?f=check_email&sid_token=${token}&seq=0`, { timeout: 8000 })
      const list = res.data ? (res.data.list || []) : []
      const detailedEmails = []
      for (let i = 0; i < list.length; i++) {
        try {
          const detail = await axios.get(`https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id=${list[i].mail_id}&sid_token=${token}`, { timeout: 5000 })
          detailedEmails.push({
            subject: list[i].mail_subject || 'No Subject',
            from: list[i].mail_from || '',
            body: detail.data.mail_body || '',
            html: detail.data.mail_body || ''
          })
        } catch (e) {}
      }
      return { status: true, emails: detailedEmails }
    } catch (err) { return { status: false, emails: [] } }
  }
  return { status: false, emails: [] }
}

function extractLinks(email) {
  const content = (email.html || '') + ' ' + (email.body || '')
  const links = []

  const amMatch = content.match(/href=['"](https?:\/\/[^'"]+auth\/links\?[^'"]+)['"]/i) ||
                  content.match(/(https?:\/\/[^\s<>"']+alightcreative[^\s<>"']+)/i) ||
                  content.match(/(https?:\/\/[^\s<>"']+firebaseapp[^\s<>"']+)/i)

  if (amMatch) {
    links.push((amMatch[1] || amMatch[0]).replace(/&amp;/g, '&'))
  }

  if (links.length === 0) {
    const generalHref = content.match(/href=['"](https?:\/\/[^'"]+)['"]/gi)
    const rawLinks = content.match(/(https?:\/\/[^\s"'<>]+)/gi)

    if (generalHref) {
      generalHref.forEach(l => {
        const clean = l.replace(/href=['"]/i, '').replace(/['"]$/, '')
        links.push(clean.replace(/&amp;/g, '&'))
      })
    }
    if (rawLinks) {
      rawLinks.forEach(l => links.push(l.replace(/&amp;/g, '&')))
    }
  }

  return [...new Set(links)]
}

async function renderInboxReply(m, address, inbox) {
  if (!inbox.status) {
    return m.reply('❌ Gagal terhubung ke server inbox. Coba lagi nanti.')
  }

  if (!inbox.emails || inbox.emails.length === 0) {
    return m.reply(`📭 *Kotak masuk masih kosong.*\nTarget: ${address}\n\nTunggu beberapa saat terus cek lagi.`)
  }

  let text = `📬 *INBOX TEMP MAIL*\n`
  text += `📧 Target: ${address}\n`
  text += `=================================\n\n`

  for (let i = 0; i < inbox.emails.length; i++) {
    const email = inbox.emails[i]
    const links = extractLinks(email)

    text += `📩 *Pesan ${i + 1}*\n`
    if (email.from) text += `*Dari:* ${email.from}\n`
    text += `*Subjek:* ${email.subject}\n`

    if (links.length > 0) {
      text += `🔗 *Link Ditemukan:*\n`
      links.forEach((link, idx) => {
        text += `  ${idx + 1}. ${link}\n`
      })
    } else {
      const cleanBody = (email.body || email.html || '').replace(/<[^>]*>?/gm, '').trim()
      text += `📝 *Isi Pesan (Potongan):*\n${cleanBody.substring(0, 800)}${cleanBody.length > 800 ? '...' : ''}\n`
    }
    text += `\n---------------------------------\n`
  }

  return m.reply(text)
}

export default {
  command: 'tempmail',
  alias: ['tm', 'mail', 'fakemail'],
  category: 'tools',
  description: `> Bikin & cek email sementara (temp mail). Otomatis coba beberapa provider (tempmail.lol, mail.tm, guerrillamail) biar kalau satu down, tetep jalan.

*Sub-command:*
\`create\` = bikin email sementara baru
\`cek <email>\` = cek inbox email yang udah dibikin lewat bot ini

Catatan: \`cek <email>\` cuma bisa buat email yang dibikin lewat \`.tempmail create\` (atau .amprem), karena provider-nya butuh token login, bukan cuma alamat emailnya doang.

contoh penggunaan:
> \`.tempmail create\`
> \`.tempmail cek bot12345@mail.tm\`
> \`.tempmail\` (cek sesi terakhir)`,
  help: '<create|cek <email>>',
  typing: true,

  execute: async function (m, { args }) {
    const sender = m.sender || m.key?.participant || m.chat
    const sub = args[0]?.toLowerCase()

    if (sub === 'create') {
      await m.reply('⏳ Lagi bikin email sementara...')
      const result = await createTempEmail()

      if (!result.status) {
        return m.reply(`❌ Gagal bikin email sementara.\n${result.error || ''}`)
      }

      const session = { provider: result.provider, address: result.address, token: result.token }
      global.tmSessions.set(sender, session)
      global.tmSessionsByAddress.set(result.address.toLowerCase(), session)

      return m.reply(
        `📧 *Email Sementara Dibuat!*\n\n` +
        `Alamat: *${result.address}*\n` +
        `Provider: ${result.provider}\n\n` +
        `Cek inbox-nya pakai:\n` +
        `\`${m.prefix}${m.command} cek ${result.address}\`\n` +
        `atau cukup \`${m.prefix}${m.command}\` (otomatis pakai email ini)`
      )
    }

    if ((sub === 'cek' || sub === 'check') && args[1]?.includes('@')) {
      const address = args[1].trim().toLowerCase()
      const session = global.tmSessionsByAddress.get(address)

      if (!session) {
        return m.reply(
          `❌ Email *${address}* gak dikenali di sesi bot.\n\n` +
          `\`${m.prefix}${m.command} cek\` cuma bisa dipake buat email yang dibikin lewat \`${m.prefix}${m.command} create\` (atau .amprem), soalnya butuh token login yang tersimpan di bot, bukan cuma alamatnya doang.`
        )
      }

      await m.reply(`⏳ Mengecek inbox dari:\n*${address}*...`)
      const inbox = await getTempMailMessages(session)
      return renderInboxReply(m, address, inbox)
    }

    // Fallback: sesi terakhir (dari .tempmail create ATAU otomatis dari .amprem)
    const sessionData = global.tmSessions.get(sender)
    if (!sessionData) {
      return m.reply(
        `❌ Lu belum punya sesi email.\n\n` +
        `Bikin baru: \`${m.prefix}${m.command} create\`\n` +
        `Atau jalankan *.amprem* dulu buat auto-generate.`
      )
    }

    await m.reply(`⏳ Mengecek inbox dari:\n*${sessionData.address}*...`)
    const inbox = await getTempMailMessages(sessionData)
    return renderInboxReply(m, sessionData.address, inbox)
  }
}