import { AIRich } from '../../lib/MessageBuilder.js'
import { buildReplayCode, filterEncNodes, extractReplayableAttrs } from '../../lib/rawMessageUtils.js'
import { getRawMessageById } from '../../db/rawMessage.js'

export default {
  command: 'crm',
  alias: ['coderelay', 'getcode', 'ripcode'],
  category: 'tools',
  description: 'Mengekstrak pesan menjadi file JS siap eksekusi (Bypass WA Stripping).',
  help: '(reply pesan) [-snip] [-b]',
 

  async execute(m, { sock, args, q }) {
    if (!m.quoted) {
      return sock.message.send(m.chat, { 
        text: '❌ Reply pesan yang mau di-rip kodenya.' 
      }, { 
        additionalAttributes: { type: "text" } 
      })
    }

    try {
      const quotedId = m.quoted?.id || m.quoted?.key?.id || m.raw?.message?.extendedTextMessage?.contextInfo?.stanzaId
      const stored = quotedId ? getRawMessageById(quotedId) : null
      
      let rawMessage = stored?.raw?.message 
        || m.raw?.message?.extendedTextMessage?.contextInfo?.quotedMessage 
        || m.quoted?.message 
        || m.quoted?.full 
        || q?.message 
        || q?.json

      if (rawMessage?.message) {
        rawMessage = rawMessage.message
      }

      if (!rawMessage) {
        return sock.message.send(m.chat, { 
          text: '❌ Gagal ngekstrak raw message, pastikan pesan ada di database bot.' 
        }, { 
          additionalAttributes: { type: "text" } 
        })
      }

      const nodes = filterEncNodes(stored?.raw?.nodes || m.quoted?.nodes || q?.nodes || null)
      const baseAttrs = extractReplayableAttrs(m.quoted?.json || q?.json) || {}
      
      const finalAttrs = { ...baseAttrs, type: "text" }

      let generatedCode = buildReplayCode(rawMessage, nodes, finalAttrs)
      
      // Replace target kirim ke m.chat
      generatedCode = generatedCode.replace(/await sock\.message\.send\(jid, /g, 'await sock.message.send(m.chat, ')

      const isSnip = args && args.includes('-snip')
      const isBase64 = args && args.includes('-b')

      // --- LOGIK FITUR -b (Base64 ke Text / JSON) ---
      if (isBase64) {
        const b64Regex = /Buffer\.from\(\s*(['"])([^'"]+)\1\s*,\s*(['"])base64\3\s*\)/g;
        let payloadIndex = 1;
        let payloadDecls = [];

        generatedCode = generatedCode.replace(b64Regex, (match, quote, b64str) => {
          try {
            const decodedText = Buffer.from(b64str, 'base64').toString('utf-8');
            try {
              const parsed = JSON.parse(decodedText);
              const payloadName = payloadIndex === 1 ? 'payload' : `payload${payloadIndex}`;
              payloadIndex++;
              
              const jsonString = JSON.stringify(parsed, null, 2);
              payloadDecls.push(`const ${payloadName} = ${jsonString};`);
              
              return `Buffer.from(JSON.stringify(${payloadName}))`;
            } catch (e) {
              // Kalau bukan JSON tapi teks yg bisa dibaca
              if (!/[\x00-\x08\x0E-\x1F]/.test(decodedText)) {
                return `Buffer.from(${JSON.stringify(decodedText)})`;
              }
              return match; 
            }
          } catch (e) {
            return match;
          }
        });

        // Kalo ada JSON yg sukses diekstrak, taruh di baris paling atas
        if (payloadDecls.length > 0) {
          generatedCode = payloadDecls.join('\n\n') + '\n\n\n' + generatedCode;
        }
      }

      // --- LOGIK PENGIRIMAN ---
      if (isSnip) {
        // Jika pakai -snip, kirim dengan animasi edit ala AIRich
        const rich = new AIRich(sock)
        
        rich.addText('⏳ Membongkar payload dari database...', { id: 'loading' })
        await rich.send(m.chat, { additionalAttributes: { type: "text" } })
        
        rich.addCode('javascript', generatedCode, { replace: 'loading' })
        await rich.sendEdit() 
        
      } else if (isBase64) {
        // Jika pakai -b aja (tanpa -snip), langsung jadikan pesan teks / reply 
        // biar gak ngirim file doc yg menuh-menuhin memori hp
        if (typeof m.reply === 'function') {
          return m.reply(generatedCode)
        } else {
          return sock.message.send(m.chat, { 
            text: generatedCode 
          }, { 
            quoted: m,
            additionalAttributes: { type: "text" } 
          })
        }
      } else {
        // Default (tanpa flag): Kirim sebagai file .js seperti awal yang udah pasti work
        const fileBuffer = Buffer.from(generatedCode, 'utf-8')

        await sock.message.send(m.chat, { 
          text: '⏳ Memproses file JS...' 
        }, { 
          additionalAttributes: { type: "text" } 
        })

        await sock.message.send(m.chat, {
          document: fileBuffer,
          mimetype: 'application/javascript',
          fileName: 'payload_rip.js',
          caption: '✅ *Payload berhasil diekstrak dari database.*'
        }, {
          additionalAttributes: { type: "text" }
        })
      }

    } catch (err) {
      return sock.message.send(m.chat, { 
        text: `❌ Gagal mengekstrak:\n${err.message || err}` 
      }, { 
        additionalAttributes: { type: "text" } 
      })
    }
  }
}