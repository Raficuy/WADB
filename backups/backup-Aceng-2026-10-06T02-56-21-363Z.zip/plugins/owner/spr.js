// plugins/owner/spr.js
// Kirim foto profil tiap member grup secara "rahasia" lewat #sPR — satu pesan ke
// grup, tapi tiap orang cuma liat foto profilnya sendiri.
// Semua pemanggilan sock.* di sini dipakein versi yang udah kebukti jalan di
// project ini (getGroupMetadata, sock.profile.getProfilePicture, sock.message.send,
// sock.generateWAMessageContent + sock.waUploadToServer — persis pola plugins/tools/apkpure.js).

import { getGroupMetadata } from '../../db/groupCache.js'

const FALLBACK_PP = 'https://cloud.yardansh.com/4aDFXw.jpg'
const CAPTION = 'gambar disini sesuai dengan foto profilmu\n> _hanya kamu yang dapat melihat pesan ini._'

export default {
  command: 'pptag',
  alias: ['spr', 'tagpp'],
  category: 'admin',
  description: `> Kirim foto profil tiap member grup secara "rahasia" — satu pesan ke grup, tapi tiap orang cuma liat foto profilnya sendiri doang.`,
  help: '(tanpa argumen, jalanin di dalem grup)',
  adminOnly: true,
  groupOnly: true,
  typing: true,
  wait: true,

  async execute(m, { sock }) {
    const jid = m.chat

    try {
      const sPR = await import('#sPR')
      const baileys = await import('baileys')

      const groupMeta = await getGroupMetadata(jid, sock)
      if (!groupMeta?.participants?.length) {
        return m.reply('❌ Gagal ambil data grup.')
      }

      const botNum = sock.user?.id?.split('@')[0]?.split(':')[0]
      const participants = groupMeta.participants.filter(p => {
        const id = p.id || p.jid
        const num = id?.split('@')[0]?.split(':')[0]
        return num && num !== botNum
      })

      if (participants.length === 0) {
        return m.reply('❌ Tidak ada member yang bisa diproses.')
      }

      const messageId = baileys.generateMessageIDV2()

      await sock.message.send(jid, { text: 'Preparing images...' }, { additionalAttributes: { type: 'text' } })

      const prepared = await Promise.all(
        participants.map(async (p) => {
          const id = p.id || p.jid

          let profile
          try {
            const pp = await sock.profile.getProfilePicture(id, 'image')
            profile = pp?.url || FALLBACK_PP
          } catch {
            profile = FALLBACK_PP // fallback kalau PP private/gak ada
          }

          const imageMessage = await sock.generateWAMessageContent(
            { image: { url: profile } },
            { upload: sock.waUploadToServer }
          )

          const msg = {
            imageMessage: {
              ...imageMessage,
              caption: CAPTION
              //contextInfo: { mentionedJid: [id] }
            }
          }

          const includeJids = [id]
          if (p.lid) includeJids.push(p.lid)

          return { id, msg, includeJids }
        })
      )

      await sock.message.send(jid, { text: 'Sending messages...' }, { additionalAttributes: { type: 'text' } })

      let iteration = 0

      for (const { id, msg, includeJids } of prepared) {
        try {
          await sPR.default(
            sock,
            jid,
            msg,
            {
              mode: 'include',
              include: includeJids,
              messageId,
              excludeMe: true,
              includeMe: false
            }
          )
          iteration++
        } catch (err) {
          console.error(`[pptag] gagal kirim ke ${id}:`, err.message)
        }

        await baileys.delay(200)
      }

      return m.reply(`Sended. (${iteration}/${prepared.length} sukses)`)
    } catch (err) {
      console.error('[PPTAG] Error:', err)
      return m.reply(`❌ Gagal jalanin pptag: ${err?.message || err}`)
    }
  }
}