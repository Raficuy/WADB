// plugins/owner/reloadcore.js

import { reloadCore, listCoreModules } from '../../lib/hotCore.js'

export default {
  command: 'reloadcore',
  alias: ['rldcore', 'hotreload'],
  category: 'owner',
  description: `> Reload file core (handler.js, lib/*.js, db/*.js, settings.js) TANPA restart proses & TANPA koneksi WA putus.

Beda sama \`.reload\` yang cuma buat plugin -- ini buat file inti yang biasanya butuh restart penuh.

contoh penggunaan:
> \`.reloadcore\`
> \`.reloadcore list\` — lihat file apa aja yang ke-cover`,
  help: '(list)',
  onlyOwner: true,

  async execute(m, { args }) {
    if ((args[0] || '').toLowerCase() === 'list') {
      const files = listCoreModules()
      if (!files.length) return m.reply('Belum ada core module yang ter-registrasi.')
      return m.reply(`*Core module yang ke-cover hot-reload:*\n${files.map(f => `• ${f}`).join('\n')}`)
    }

    const start = Date.now()
    const results = await reloadCore()
    const timeTaken = Date.now() - start

    const ok = results.filter(r => r.ok)
    const failed = results.filter(r => !r.ok)

    let response = `* *RELOAD CORE COMPLETED* (${timeTaken}ms)\n\n`
    response += `* Berhasil: ${ok.length}/${results.length}\n`

    if (failed.length) {
      response += `\n❌ *GAGAL (${failed.length}):*\n`
      for (const f of failed) {
        response += `• \`${f.file}\`\n  └─ ${f.error}\n`
      }
      response += `\n_File yang gagal reload tetap pakai versi lama (rollback otomatis, gak ada downtime)._`
    } else {
      response += `\nSemua core module berhasil dimuat ulang. Koneksi WA gak keputus sama sekali.`
    }

    return m.reply(response.trim())
  }
}
