// plugins/owner/cmdstats.js
//
// Kolom `command` udah kesimpen di tiap row raw_messages sejak lama, tapi
// gak pernah dipake buat analisis. Plugin ini jawab pertanyaan "command apa
// yang beneran kepake" dan "plugin mana yang kemungkinan gak guna".

import { getCommandUsage } from '../../db/rawMessage.js'

export default {
  command: 'cmdstats',
  alias: ['cmdusage', 'plugincek'],
  category: 'owner',
  description: `> Menampilkan command paling sering dipakai, dan daftar plugin yang belum pernah dipanggil sama sekali (kandidat buat dihapus).

contoh penggunaan:
> \`.cmdstats\``,
  help: '(tanpa argumen)',
  onlyOwner: true,
  typing: true,

  async execute(m) {
    const usage = getCommandUsage()
    const usedCommands = new Set(usage.map(u => u.command))

    // Kumpulin plugin unik dari global.plugins (Map command/alias -> plugin object)
    const uniquePlugins = new Map()
    for (const plugin of global.plugins?.values() ?? []) {
      if (plugin?.command) uniquePlugins.set(plugin.command, plugin)
    }

    const totalPlugins = uniquePlugins.size
    const neverUsed = [...uniquePlugins.values()].filter(p => !usedCommands.has(p.command))

    let text = `📈 *COMMAND USAGE REPORT*\n──────────────────\n\n`

    if (usage.length) {
      text += `🏆 *Top 10 Command Paling Sering Dipakai*\n`
      usage.slice(0, 10).forEach((row, i) => {
        text += `${i + 1}. \`.${row.command}\` — ${row.total}x\n`
      })
    } else {
      text += `Belum ada histori command yang tercatat.\n`
    }

    text += `\n📦 Total plugin terdaftar: ${totalPlugins}\n`
    text += `❌ Belum pernah dipanggil sekali pun: ${neverUsed.length}\n`

    if (neverUsed.length) {
      const preview = neverUsed.slice(0, 25)
      text += `\n*Kandidat gak kepake (cek/hapus manual):*\n`
      text += preview.map(p => `\`.${p.command}\` _(${p.category})_`).join('\n')
      if (neverUsed.length > preview.length) {
        text += `\n...dan ${neverUsed.length - preview.length} lainnya.`
      }
      text += `\n\n⚠️ Catatan: ini cuma histori sejak database ini dipakai, bukan berarti fitur itu pasti sampah — bisa aja emang jarang dibutuhin.`
    }

    return m.reply(text.trim())
  }
}
