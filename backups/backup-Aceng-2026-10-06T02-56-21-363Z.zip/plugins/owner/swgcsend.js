import { getSession } from '../../lib/broadcastSession.js'
import { sendStatusToGroup } from '../../lib/statusMessage.js'

export default {
  command: 'swgcbcsend',
  category: 'owner',
  description: 'Perintah internal untuk tombol swgcbc, jangan dipakai manual.',
  hidden: true,
  onlyOwner: true,

  async execute(m, { sock, args }) {
    const session = getSession(m.sender)
    if (!session) return m.reply('Sesi swgcbc sudah kadaluarsa. Ulangi .swgcbc sambil reply pesan.')

    const idx = Number(args[0])
    const group = session.groups[idx]
    if (!Number.isInteger(idx) || !group) return m.reply('Pilihan grup tidak valid, sesi mungkin sudah berubah.')

    try {
      await sendStatusToGroup(sock, group.jid, session.msgType, session.raw)
      return m.reply(`Status berhasil dikirim ke grup "${group.name}".\nBalas tombol lain untuk kirim ke grup berikutnya, atau ketik .swgcbc batal untuk selesai.`)
    } catch (err) {
      return m.reply(`Gagal mengirim ke "${group.name}": ${err?.message || err}`)
    }
  }
}