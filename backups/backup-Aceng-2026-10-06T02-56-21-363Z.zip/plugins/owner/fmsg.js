export default {
    command: 'fakemsg',
    alias: ['fm', 'fmsg'],
    category: 'owner',
    description: 'Ubah/edit pesan orang lain di grup (manipulasi ProtocolMessage).',
    onlyOwner: true,
    isGroup: true,

    execute: async (m, { sock, args }) => {
        if (!m.quoted) {
            return m.reply('Reply pesan yang ingin diedit/diproses.')
        }
        
        const text = args.join(' ').trim()
        if (!text) {
            return m.reply('Masukkan teks penggantinya.')
        }

        const stanzaId = m.quoted.key.id
        if (!stanzaId) {
            return m.reply('Gagal mendapatkan ID pesan target.')
        }

        try {
            // 1. Kirim pesan pancingan (kosong)
            const temp1 = await sock.message.send(m.chat, {
                extendedTextMessage: {
                    text: '',
                    contextInfo: { isGroupStatus: true }
                }
            }, {})

            const tempId = temp1.id || (temp1.key && temp1.key.id)

            // 2. Kirim pesan edit ke tempId, tapi timpa ID packet jadi stanzaId target
            const temp2 = await sock.message.send(m.chat, text, {
                editKey: { id: tempId },
                id: stanzaId 
            })

            const temp2Id = temp2.id || (temp2.key && temp2.key.id)

            // 3. Jeda sejenak sebelum dihapus
            await new Promise(resolve => setTimeout(resolve, 100))

            // 4. Hapus pesan jejak menggunakan native revoke zapo-js
            await Promise.allSettled([
                sock.message.send(m.chat, {
                    type: 'revoke',
                    target: { remoteJid: m.chat, id: tempId, fromMe: true }
                }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true }),
                sock.message.send(m.chat, {
                    type: 'revoke',
                    target: { remoteJid: m.chat, id: temp2Id, fromMe: true }
                }, { disableGroupEphemeralAutoInject: true, disableDirectEphemeralAutoInject: true })
            ])

        } catch (e) {
            console.error('[fakemsg]', e)
            await m.reply('Error: ' + (e?.message || e))
        }
    }
}