global.bungkamList = global.bungkamList || new Set()

const getCleanId = (jid) => {
    if (!jid) return ''
    let num = jid.split('@')[0].split(':')[0]
    return `${num}@s.whatsapp.net`
}

export default {
    command: 'bungkam',
    alias: ['hitamkan', 'mute'],
    category: 'owner',
    description: 'Lakban mulut orang otomatis pake santet zapo.',
    onlyOwner: true,
    isGroup: true,

    execute: async (m, { sock }) => {
      
        const rawTarget = m.quoted 
            ? (m.quoted.participantAlt || m.quoted.sender || m.quoted.participant) 
            : (m.mentionedJid && m.mentionedJid[0])
        
        if (!rawTarget) {
            return m.reply('Woy tolol! Tag atau reply dulu pesen orang yang mau dilakban!')
        }

        const target = getCleanId(rawTarget)

        if (global.bungkamList.has(target)) {
            global.bungkamList.delete(target)
            return m.reply(`✅ @${target.split('@')[0]} udah ga hitam.`)
        } else {
            global.bungkamList.add(target)
            return m.reply(`Target  Dihitamkan( @${target.split('@')[0]} ) gabisa ngetik di grup ini!`)
        }
    }
}