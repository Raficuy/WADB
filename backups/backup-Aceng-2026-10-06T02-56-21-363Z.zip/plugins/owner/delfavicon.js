// plugins/owner/delfavicon.js

import { deleteThumb } from '../../db/thumbnails.js'

export default {
    command: 'delfavicon',
    alias: ['deletefavicon', 'hapusfavicon'],
    category: 'owner',
    description: `> Menghapus favicon dari koleksi database.

*Keterangan Format:*
> \`<nama>\` = nama favicon yang ingin dihapus.
> \`<nama1>, <nama2>\` = hapus beberapa favicon sekaligus.

contoh penggunaan:
> \`.delfavicon google\`
> \`.delfavicon google, github\``,
    help: '<nama>',
    ownerOnly: true,
    typing: true,

    async execute(m, { args }) {
        const input = args.join(' ').trim()

        if (!input) {
            return m.reply(`Sebutkan nama favicon-nya!\nContoh: ${m.prefix}${m.command} google`)
        }

        const names = [...new Set(input.split(',').flatMap(part => part.trim().split(/\s+/)).filter(Boolean))]

        const lines = []
        let deleted = 0

        for (const name of names) {
            if (/^random$/i.test(name)) {
                lines.push(`⚠️ \`${name}\` - kata kunci khusus, tidak bisa dihapus`)
                continue
            }

            if (deleteThumb(name, 'favicon')) {
                deleted++
                lines.push(`✅ \`${name}\` - terhapus`)
            } else {
                lines.push(`⚠️ \`${name}\` - tidak ditemukan`)
            }
        }

        return m.reply(
            `╾─「 *HAPUS FAVICON* 」─╼\n\n` +
            `${lines.join('\n')}\n\n` +
            `*Total terhapus:* ${deleted}/${names.length}`
        )
    }
}
