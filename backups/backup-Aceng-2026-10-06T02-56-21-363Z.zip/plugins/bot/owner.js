import { config } from '../../settings.js'
import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'owner',
  alias: ['creator'],
  category: 'bot',
  description: 'Mengirim kontak card (vCard) owner bot ke chat saat ini.',

  async execute(m, { sock }) {
    const number = String(config.owner).replace(/\D/g, '')
    const name = config.ownerName
    const vcard = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN:${name}`,
      `TEL;type=CELL;type=VOICE;waid=${number}:+${number}`,
      'END:VCARD'
    ].join('\n')

    await m.reply({
      contactMessage: {
        displayName: name,
        vcard
      }
    })

    try {
      const rich = new AIRich(sock)
      rich.addText(` ${name}...`, { id: 'status' })
      
      await rich.send(m.chat)
      
      await delay(1)

      const sectionImage = AIRich.newLayout('Single', {
        media: {
          url: "https://d.tmpfile.link/public/2026-09-22/6fb2dd95-cdfd-4432-93dd-90f99b405de1/file_1790043358570.jpeg",
          mime_type: "image/png",
          width: 16,
          height: 9
        },
        imagine_type: "IMAGE",
        status: { status: "READY" },
        __typename: "GenAIImaginePrimitive"
      })

      const sectionFollow = AIRich.newLayout('Single', {
        title: `${config.ownerName}`,
        subtitle: `Owner of ${config.botName}`,
        secondary_subtitle: `${config.ownerName}`,
        entity_id: config.owner,
        entity_url: `https://wa.me/${config.owner}`,
        entity_type: "PAGE",
        action_type: "FOLLOW",
        is_verified: true,
        image: {
          url: "https://d.tmpfile.link/public/2026-09-22/d11f36a5-2e2d-4aad-8198-5dc83ab68c23/file_1790043352030.jpeg",
          url_fallback: "https://d.tmpfile.link/public/2026-09-22/d11f36a5-2e2d-4aad-8198-5dc83ab68c23/file_1790043352030.jpeg"
        },
        __typename: "GenAICompactEntityPrimitive"
      })

      const sectionMarkdown = AIRich.newLayout('Single', {
        text: `OWNER OF ${config.botName} Bot`,
        __typename: "GenAIMarkdownTextUXPrimitive"
      })

      const sectionFooter = AIRich.newLayout('Single', {
        text: `© Powered by ${config.ownerName}`,
        __typename: "GenAIMetadataTextPrimitive"
      })

      const customSubmessage = {
        messageType: 2,
        messageText: `Owner of ${config.botName}`
      }

      rich._addContent(sectionImage, customSubmessage, { replace: 'status', id: 's1' })
      
      rich._addContent(sectionFollow, null, { id: 's2' })
      rich._addContent(sectionMarkdown, null, { id: 's3' })
      rich._addContent(sectionFooter, null, { id: 's4' })

      await rich.sendEdit()

    } catch (err) {
      console.error("[OWNER UI] Error:", err)
      return sock.message.send(m.chat, {
        text: `❌ Gagal memuat UI:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}