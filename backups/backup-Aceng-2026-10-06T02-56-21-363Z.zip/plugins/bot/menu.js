// menu.js

import zapoPkg from 'zapo-js/package.json' with { type: 'json' }
import { config } from '../../settings.js'
import { getRandomThumb } from '../../db/thumbnails.js'

const zapoVersion = zapoPkg.version

const MENU_URL = 'https://github.com/RafiCuy'
const BOT_CREATED_AT = new Date('2026-08-20T00:00:00')
const BULAN_ID = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']

// Satu ikon per kategori, dipake sekali di judul kategori aja (bukan tiap baris) biar tetep rapi.
const CATEGORY_ICON = {
    ai: '🤖',
    asupan: '📸',
    bot: '⚙️',
    chanel: '📢',
    downloader: '⬇️',
    game: '🎮',
    grup: '👥',
    konvert: '🔄',
    owner: '👑',
    rpg: '🗡️',
    search: '🔍',
    tools: '🧰',
    root: '📦'
}

function getRuntime() {
    if (typeof Bun !== 'undefined') return `Bun v${Bun.version}`
    return `Node v${process.versions.node}`
}

function formatCreatedDate() {
    const tanggal = BOT_CREATED_AT.getDate()
    const bulan = BULAN_ID[BOT_CREATED_AT.getMonth()]
    const tahun = BOT_CREATED_AT.getFullYear()
    return `${tanggal} ${bulan} ${tahun}`
}

function getBotAge() {
    const now = new Date()
    let years = now.getFullYear() - BOT_CREATED_AT.getFullYear()
    let months = now.getMonth() - BOT_CREATED_AT.getMonth()
    let days = now.getDate() - BOT_CREATED_AT.getDate()

    if (days < 0) {
        months -= 1
        const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0)
        days += prevMonth.getDate()
    }

    if (months < 0) {
        years -= 1
        months += 12
    }

    const parts = []
    if (years > 0) parts.push(`${years} tahun`)
    if (months > 0) parts.push(`${months} bulan`)
    if (days > 0 || parts.length === 0) parts.push(`${days} hari`)

    return parts.join(' ')
}

function getGreeting() {
    const hour = new Date().getHours()
    if (hour < 4) return 'Begadang lagi?'
    if (hour < 11) return 'Selamat pagi'
    if (hour < 15) return 'Selamat siang'
    if (hour < 18) return 'Selamat sore'
    return 'Selamat malam'
}

function buildDescription() {
    const umur = getBotAge()
    const tanggalDibuat = formatCreatedDate()
    const nama = config.botName || 'Bot ini'
    return `${nama} nemenin grup lu, jalan pake zapo-js. Online sejak ${tanggalDibuat}, udah aktif ${umur}.`
}

function categoryIcon(category) {
    return CATEGORY_ICON[category?.toLowerCase()] || CATEGORY_ICON.root
}

function formatCategoryName(category) {
    if (!category || category === 'root') return 'Lainnya'
    return category
        .split(/[-_/]/)
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ')
}

function uniquePlugins(plugins) {
    const seen = new Set()
    const unique = []

    for (const plugin of plugins.values()) {
        if (seen.has(plugin)) continue
        seen.add(plugin)
        unique.push(plugin)
    }

    return unique
}

function groupByCategory(pluginList) {
    const groups = new Map()

    for (const plugin of pluginList) {
        if (plugin.hidden) continue

        const category = plugin.category || 'root'
        if (!groups.has(category)) groups.set(category, [])
        groups.get(category).push(plugin)
    }

    for (const list of groups.values()) {
        list.sort((a, b) => a.command.localeCompare(b.command))
    }

    return groups
}

function sortedCategoryKeys(groups) {
    return [...groups.keys()].sort((a, b) => {
        if (a === 'root') return 1
        if (b === 'root') return -1
        return a.localeCompare(b)
    })
}

// Susun daftar jadi 2 kolom rapi (dipake buat kategori padat isinya kayak Owner/Tools/Rpg)
// biar kaga bikin chat kepanjangan ke bawah.
function toTwoColumns(labels) {
    const width = Math.max(...labels.map((l) => l.length)) + 2
    const rows = []

    for (let i = 0; i < labels.length; i += 2) {
        const kiri = labels[i].padEnd(width)
        const kanan = labels[i + 1] || ''
        rows.push(kanan ? `${kiri}${kanan}` : labels[i])
    }

    return rows.join('\n')
}

function buildHeader(m) {
    const prefix = config.noprefix ? 'tanpa prefix' : config.prefixes.join(' ')
    const info = [
        ['Prefix', prefix],
        ['Runtime', getRuntime()],
        ['Library', `zapo-js v${zapoVersion}`],
        ['Aktif', getBotAge()]
    ]
    const width = Math.max(...info.map(([k]) => k.length)) + 1
    const infoBlock = info.map(([k, v]) => `${k.padEnd(width)}: ${v}`).join('\n')

    return [
        `_${getGreeting()}, @${m.sender.split('@')[0]}_`,
        '',
        `*${config.botName || 'BOT'}*`,
        `Asisten grup, ditenagai zapo-js.`,
        '',
        '```' + infoBlock + '```'
    ].join('\n')
}

function buildCategoryListText(groups, usedPrefix, command) {
    const keys = sortedCategoryKeys(groups)
    const totalFitur = keys.reduce((sum, key) => sum + groups.get(key).length, 0)

    const numWidth = String(keys.length).length
    const nameWidth = Math.max(...keys.map((k) => formatCategoryName(k).length + 2)) + 1

    const rows = keys.map((key, i) => {
        const nomor = `${i + 1}.`.padEnd(numWidth + 2)
        const nama = `${categoryIcon(key)} ${formatCategoryName(key)}`.padEnd(nameWidth)
        const jumlah = String(groups.get(key).length).padStart(2)
        return `${nomor}${nama}${jumlah}`
    })

    return [
        `*Kategori* _(${keys.length} kategori · ${totalFitur} fitur)_`,
        '```' + rows.join('\n') + '```',
        `\`${usedPrefix}${command} all\` — liat semua fitur sekaligus`,
        `\`${usedPrefix}${command} <kategori>\` — liat fitur satu-satu`
    ].join('\n')
}

function buildAllMenuText(groups, usedPrefix) {
    const blocks = []
    let total = 0

    for (const category of sortedCategoryKeys(groups)) {
        const items = groups.get(category)
        total += items.length

        const labels = items.map((plugin) => `${usedPrefix}${plugin.command}`)
        const body = labels.length > 6 ? toTwoColumns(labels) : labels.join('\n')

        blocks.push(`*${categoryIcon(category)} ${formatCategoryName(category)}* _(${items.length})_\n` + '```' + body + '```')
    }

    blocks.push(`_Total ${total} fitur — tinggal pilih, gas coba_`)
    return blocks.join('\n\n')
}

function buildCategoryMenuText(groups, categoryKey, usedPrefix) {
    const items = groups.get(categoryKey)
    const labels = items.map((plugin) => `${usedPrefix}${plugin.command}`)
    const body = labels.length > 12 ? toTwoColumns(labels) : labels.map((l, i) => `${String(i + 1).padStart(2)}. ${l}`).join('\n')

    return [
        `*${categoryIcon(categoryKey)} ${formatCategoryName(categoryKey)}* _(${items.length} fitur)_`,
        '```' + body + '```'
    ].join('\n')
}

export default {
    command: 'menu',
    category: 'bot',
    description: `> Menampilkan daftar menu fitur bot berdasarkan kategori.

*Keterangan Format:*
> \`all\` = menampilkan semua fitur.
> \`<kategori>\` = menampilkan fitur berdasarkan kategori tertentu.

contoh penggunaan:
> \`.menu\`
> \`.menu all\`
> \`.menu grup\``,
    help: '<kategori> / all',
    typing: true,

    async execute(m, { plugins, sock }) {
        const pluginList = uniquePlugins(plugins)
        const groups = groupByCategory(pluginList)
        const arg = (m.args[0] || '').toLowerCase()
        const usedPrefix = m.prefix
        const header = buildHeader(m)

        let body

        if (!arg) {
            body = buildCategoryListText(groups, usedPrefix, m.command)
        } else if (arg === 'all') {
            body = buildAllMenuText(groups, usedPrefix)
        } else {
            const matchedKey = [...groups.keys()].find((key) => key.toLowerCase() === arg)

            if (!matchedKey) {
                return m.reply(`Kategori "${arg}" tidak ditemukan. Ketik ${usedPrefix}${m.command} untuk melihat daftar kategori.`)
            }

            body = buildCategoryMenuText(groups, matchedKey, usedPrefix)
        }
        const hasil = header + '\n\n' + body

        try {
            const opts = {
                url: MENU_URL,
                title: m.pushName,
                body: buildDescription(),
                text: hasil,
                thumbnail: 'random',
                quote: m,
                mentions: [m.sender]
            }

            if (getRandomThumb('favicon')) opts.favicon = 'random'

            return await sock.sendThumbnail(m.chat, opts)
        } catch {
            return m.reply(hasil)
        }
    }
}