export default {
  command: 'breakout',
  alias: ['brickbreaker', 'neonbreakout'],
  category: 'game',
  description: 'Bermain game Neon Breakout (Brick Breaker) interaktif',
  help: '',
  typing: true,

  async execute(m, { sock }) {
    try {
      const htmlPayload = `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;padding:0;width:100%;min-height:100%;background:transparent;font-family:Arial,Helvetica,sans-serif;color:#fff;overflow:hidden;touch-action:none}
.wrap{width:100%;max-width:380px;margin:auto;padding:10px}
.card{position:relative;overflow:hidden;border-radius:24px;background:linear-gradient(180deg,#171525 0%,#0b0a12 100%);border:1px solid rgba(255,255,255,.13);box-shadow:0 20px 55px rgba(0,0,0,.55),inset 0 1px rgba(255,255,255,.08);padding:15px}
.header{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:12px}
.mini{font-size:10px;letter-spacing:2px;color:#77748c;margin-bottom:3px}
.title{font-size:18px;font-weight:800}
.stats{text-align:right;font-size:14px;font-weight:bold;color:#8270ff}
.canvas-container{position:relative;width:100%;height:400px;background:#07070b;border-radius:14px;border:1px solid rgba(255,255,255,.09);box-shadow:inset 0 7px 18px rgba(0,0,0,.7);overflow:hidden}
canvas{width:100%;height:100%;display:block;touch-action:none}
.overlay{position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.85);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:10;border-radius:14px}
.overlay h2{margin:0 0 5px;font-size:28px;font-weight:900;letter-spacing:2px}
.overlay p{color:#aaa;margin:0 0 20px;font-size:14px;letter-spacing:1px}
.overlay button{background:linear-gradient(135deg,#8270ff,#5946cc);color:#fff;border:none;padding:14px 28px;border-radius:12px;font-weight:900;font-size:14px;letter-spacing:1px;cursor:pointer;box-shadow:0 6px 18px rgba(105,87,229,.4)}
</style>

<div class="wrap">
  <div class="card">
    <div class="header">
      <div>
        <div class="mini">CYLICDEV ARCADE</div>
        <div class="title">Neon Breakout 🧱</div>
      </div>
      <div class="stats">SCORE: <span id="score">0</span></div>
    </div>
    
    <div class="canvas-container">
      <canvas id="game" width="300" height="400"></canvas>
      <div class="overlay" id="go">
        <h2 id="goTitle">HANCUR</h2>
        <p>Skor Akhir: <span id="finalScore">0</span></p>
        <button onclick="init()">MAIN LAGI</button>
      </div>
    </div>
  </div>
</div>

<script>
const cvs = document.getElementById('game');
const ctx = cvs.getContext('2d');
const scoreEl = document.getElementById('score');
const goEl = document.getElementById('go');
const finalScoreEl = document.getElementById('finalScore');
const goTitle = document.getElementById('goTitle');

let paddle, ball, bricks, score, playing, loop;
const colors = ['#ff3366', '#ffcc00', '#00ffcc', '#8270ff'];

function init() {
  paddle = { x: 115, y: 370, w: 70, h: 10 };
  ball = { x: 150, y: 350, r: 6, dx: 4, dy: -4 };
  bricks = [];
  score = 0; playing = true;
  scoreEl.innerText = score;
  goEl.style.display = 'none';

  for(let r=0; r<4; r++) {
    for(let c=0; c<6; c++) {
      bricks.push({ x: c * 46 + 14, y: r * 20 + 30, w: 42, h: 14, status: 1, color: colors[r] });
    }
  }

  if(loop) clearInterval(loop);
  loop = setInterval(update, 1000/60);
}

function handleTouch(e) {
  if(!playing) return;
  let rect = cvs.getBoundingClientRect();
  let scaleX = cvs.width / rect.width;
  let cx = e.touches ? e.touches[0].clientX : e.clientX;
  paddle.x = (cx - rect.left) * scaleX - paddle.w/2;
  if(paddle.x < 0) paddle.x = 0;
  if(paddle.x + paddle.w > cvs.width) paddle.x = cvs.width - paddle.w;
}

cvs.addEventListener('pointermove', handleTouch);
cvs.addEventListener('touchmove', handleTouch, {passive: false});

function update() {
  ctx.fillStyle = '#07070b';
  ctx.fillRect(0, 0, cvs.width, cvs.height);

  let activeBricks = 0;
  for(let b of bricks) {
    if(b.status === 1) {
      activeBricks++;
      ctx.shadowBlur = 10;
      ctx.shadowColor = b.color;
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x, b.y, b.w, b.h);

      if(ball.x > b.x && ball.x < b.x + b.w && ball.y - ball.r < b.y + b.h && ball.y + ball.r > b.y) {
        ball.dy = -ball.dy;
        b.status = 0;
        score += 10;
        scoreEl.innerText = score;
      }
    }
  }

  if(activeBricks === 0) return over("MENANG!");

  ctx.shadowBlur = 15;
  ctx.shadowColor = '#00ffcc';
  ctx.fillStyle = '#00ffcc';
  ctx.fillRect(paddle.x, paddle.y, paddle.w, paddle.h);

  ctx.shadowBlur = 10;
  ctx.shadowColor = '#fff';
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI*2);
  ctx.fill();
  ctx.shadowBlur = 0;

  ball.x += ball.dx;
  ball.y += ball.dy;

  if(ball.x + ball.r > cvs.width || ball.x - ball.r < 0) ball.dx = -ball.dx;
  if(ball.y - ball.r < 0) ball.dy = -ball.dy;

  if(ball.y + ball.r > paddle.y && ball.y - ball.r < paddle.y + paddle.h && ball.x > paddle.x && ball.x < paddle.x + paddle.w) {
    ball.dy = -Math.abs(ball.dy);
    ball.dx = ((ball.x - (paddle.x + paddle.w/2)) / (paddle.w/2)) * 4.5;
  }

  if(ball.y + ball.r > cvs.height) {
    over("GAME OVER");
  }
}

function over(msg) {
  playing = false;
  clearInterval(loop);
  goTitle.innerText = msg;
  goTitle.style.color = msg === "MENANG!" ? "#00ffcc" : "#ff3366";
  goTitle.style.textShadow = msg === "MENANG!" ? "0 0 20px rgba(0,255,204,0.6)" : "0 0 20px rgba(255,51,102,0.6)";
  finalScoreEl.innerText = score;
  setTimeout(() => { goEl.style.display = 'flex'; }, 300);
}

init();
</script>`

      await sock.message.send(
        m.chat,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            messageSecret: "0cCzjnQ5ERoqM2QrQ7KjmMfxsyeWYu+61/chr2wioyE=",
            botMetadata: {
              messageDisclaimerText: "",
              botResponseId: "cylicdev-breakout-" + Date.now()
            }
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: "CYLICDEV • NEON BREAKOUT"
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(
                    JSON.stringify({
                      response_id: "cylicdev-breakout-" + Date.now(),
                      sections: [
                        {
                          view_model: {
                            primitive: {
                              __typename: "GenAIaeacdsnwHtmlPrimitive",
                              payload: htmlPayload,
                              trusted_sources: ["cylic.dev"]
                            },
                            __typename: "GenAISingleLayoutViewModel"
                          }
                        }
                      ]
                    })
                  ).toString("base64")
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: "867051314767696@bot"
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {
          quote: m.raw,
          additionalAttributes: {
            type: "text"
          }
        }
      )
    } catch (err) {
      return m.reply(`Gagal menjalankan game Breakout: ${err.message || err}`)
    }
  }
}