export default {
  command: 'snake',
  alias: ['gamesnake', 'ular'],
  category: 'game',
  description: 'Bermain game Retro Snake interaktif menggunakan Canvas',
  help: '',
  typing: true,

  async execute(m, { sock }) {
    try {
      const htmlPayload = `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;padding:0;width:100%;min-height:100%;background:transparent;font-family:Arial,Helvetica,sans-serif;color:#fff;overflow:hidden;touch-action:none}
.wrap{width:100%;max-width:380px;margin:auto;padding:10px}
.card{position:relative;overflow:hidden;border-radius:24px;background:linear-gradient(180deg,#171525 0%,#0b0a12 100%);border:1px solid rgba(255,255,255,.13);box-shadow:0 20px 55px rgba(0,0,0,.55),inset 0 1px rgba(255,255,255,.08);padding:15px}
.header{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:12px}
.mini{font-size:10px;letter-spacing:2px;color:#77748c;margin-bottom:3px}
.title{font-size:18px;font-weight:800}
.stats{text-align:right;font-size:14px;font-weight:bold;color:#67e6a5}
.canvas-container{position:relative;width:100%;aspect-ratio:1;margin-bottom:15px;background:#07070b;border-radius:14px;border:1px solid rgba(255,255,255,.09);box-shadow:inset 0 7px 18px rgba(0,0,0,.7)}
canvas{width:100%;height:100%;display:block;border-radius:14px}
.controls{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:200px;margin:0 auto}
.btn{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;color:#fff;font-size:20px;display:flex;align-items:center;justify-content:center;aspect-ratio:1;cursor:pointer;transition:.1s;box-shadow:0 4px 10px rgba(0,0,0,.2)}
.btn:active{transform:scale(.9);background:rgba(103,230,165,.2);border-color:rgba(103,230,165,.4)}
.btn.up{grid-column:2}
.btn.left{grid-column:1}
.btn.down{grid-column:2}
.btn.right{grid-column:3}
.overlay{position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.85);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:10;border-radius:24px}
.overlay h2{color:#ff3366;margin:0 0 5px;font-size:24px;text-shadow:0 0 15px rgba(255,51,102,.6)}
.overlay p{color:#aaa;margin:0 0 15px;font-size:12px}
.overlay button{background:linear-gradient(135deg,#8270ff,#5946cc);color:#fff;border:none;padding:12px 24px;border-radius:12px;font-weight:900;font-size:12px;letter-spacing:1px;cursor:pointer;box-shadow:0 6px 18px rgba(105,87,229,.4)}
</style>

<div class="wrap">
  <div class="card">
    <div class="header">
      <div>
        <div class="mini">CYLICDEV ARCADE</div>
        <div class="title">Retro Snake 🐍</div>
      </div>
      <div class="stats">SCORE: <span id="score">0</span></div>
    </div>
    
    <div class="canvas-container">
      <canvas id="game" width="400" height="400"></canvas>
      <div class="overlay" id="go">
        <h2>GAME OVER</h2>
        <p>Skor Akhir: <span id="finalScore">0</span></p>
        <button onclick="reset()">MAIN LAGI</button>
      </div>
    </div>

    <div class="controls">
      <div class="btn up" onclick="setDir(0,-1)">⬆️</div>
      <div class="btn left" onclick="setDir(-1,0)">⬅️</div>
      <div class="btn down" onclick="setDir(0,1)">⬇️</div>
      <div class="btn right" onclick="setDir(1,0)">➡️</div>
    </div>
  </div>
</div>

<script>
const cvs = document.getElementById('game');
const ctx = cvs.getContext('2d');
const scoreEl = document.getElementById('score');
const finalScoreEl = document.getElementById('finalScore');
const goEl = document.getElementById('go');

let snake, food, dx, dy, score, loop;
const gs = 20; 
const tc = 20; 

function reset() {
  snake = [{x:10, y:10}];
  food = {x:15, y:15};
  dx = 0; dy = 0;
  score = 0;
  scoreEl.innerText = score;
  goEl.style.display = 'none';
  if(loop) clearInterval(loop);
  loop = setInterval(update, 110);
  draw();
}

function setDir(x, y) {
  if (dx === 0 && dy === 0) { dx = x; dy = y; return; }
  if (x !== 0 && dx === -x) return;
  if (y !== 0 && dy === -y) return;
  dx = x; dy = y;
}

function update() {
  if (dx === 0 && dy === 0) return;
  
  let hx = snake[0].x + dx;
  let hy = snake[0].y + dy;
  
  if(hx < 0 || hx >= tc || hy < 0 || hy >= tc) return over();
  
  for(let i=0; i<snake.length; i++) {
    if(hx === snake[i].x && hy === snake[i].y) return over();
  }

  snake.unshift({x:hx, y:hy});

  if(hx === food.x && hy === food.y) {
    score += 10;
    scoreEl.innerText = score;
    food = {
      x: Math.floor(Math.random()*tc),
      y: Math.floor(Math.random()*tc)
    };
  } else {
    snake.pop();
  }

  draw();
}

function over() {
  clearInterval(loop);
  finalScoreEl.innerText = score;
  goEl.style.display = 'flex';
}

function draw() {
  ctx.clearRect(0, 0, cvs.width, cvs.height);
  
  ctx.fillStyle = '#ff3366';
  ctx.shadowBlur = 15;
  ctx.shadowColor = '#ff3366';
  ctx.beginPath();
  ctx.arc(food.x*gs+gs/2, food.y*gs+gs/2, gs/2-2, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle = '#67e6a5';
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#67e6a5';
  for(let i=0; i<snake.length; i++) {
    if(i === 0) ctx.fillStyle = '#ffffff';
    else ctx.fillStyle = '#67e6a5';
    ctx.fillRect(snake[i].x*gs+1, snake[i].y*gs+1, gs-2, gs-2);
  }
  ctx.shadowBlur = 0;
}

reset();
</script>`

      await sock.message.send(
        m.chat,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            messageSecret: "0cCzjnQ5ERoqM2QrQ7KjmMfxsyeWYu+61/chr2wioyE=",
            botMetadata: {
              messageDisclaimerText: "",
              botResponseId: "cylicdev-snake-" + Date.now()
            }
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: "CYLICDEV • RETRO SNAKE"
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(
                    JSON.stringify({
                      response_id: "cylicdev-snake-" + Date.now(),
                      sections: [
                        {
                          view_model: {
                            primitive: {
                              __typename: "GenAIaeacdsnwHtmlPrimitive",
                              payload: htmlPayload,
                              trusted_sources: ["cylic.dev"]
                            },
                            __typename: "GenAISingleLayoutViewModel"
                          }
                        }
                      ]
                    })
                  ).toString("base64")
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: "867051314767696@bot"
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {
          quote: m.raw,
          additionalAttributes: {
            type: "text"
          }
        }
      )
    } catch (err) {
      return m.reply(`Gagal menjalankan game Snake: ${err.message || err}`)
    }
  }
}