import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'gitar',
  alias: ['guitar', 'maingitar'],
  category: 'fun',
  description: 'Bermain gitar virtual interaktif di dalam chat.',
  typing: true,

  async execute(m, { sock }) {
    try {
      const rich = new AIRich(sock)
      
      // 1. Kirim pesan loading awal
      rich.addText('⏳ _Mempersiapkan gitar virtual..._', { id: 'loading_gitar' })
      await rich.send(m.chat)
      
      // Kasih jeda dikit biar animasinya kerasa
      await delay(1200)

      // 2. Kode HTML Mini Game Gitar
      const htmlCode = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{
box-sizing:border-box;
-webkit-tap-highlight-color:transparent;
}
html,body{
margin:0;
padding:0;
background:linear-gradient(#4b2e1a,#8b5a2b);
font-family:Arial,sans-serif;
overflow-x:hidden;
}
body{
padding:20px 0;
}
.title{
text-align:center;
color:#f5deb3;
font-size:24px;
font-weight:bold;
text-shadow:0 2px 4px #000;
}
.sub{
text-align:center;
color:#f5deb3;
font-size:13px;
margin:6px 0 25px;
}
.guitar-wrap{
width:100%;
padding:0 15px;
}
.guitar{
position:relative;
width:100%;
height:60vw;
max-height:300px;
min-height:200px;
background:linear-gradient(180deg,#8b4513,#5c3311);
border-radius:20px 20px 60px 60px;
box-shadow:0 10px 25px rgba(0,0,0,.6);
padding:20px 0;
touch-action:none;
}
.hole{
position:absolute;
top:50%;
left:50%;
transform:translate(-50%,-50%);
width:35%;
height:35%;
background:radial-gradient(circle,#000 40%,#3d2610 100%);
border-radius:50%;
border:4px solid #2a1a0a;
}
.strings{
position:absolute;
top:10%;
left:0;
width:100%;
height:80%;
display:flex;
flex-direction:column;
justify-content:space-between;
}
.string{
position:relative;
height:8px;
background:linear-gradient(90deg,#c0c0c0,#fff,#c0c0c0);
border-radius:4px;
box-shadow:0 1px 2px #000;
cursor:pointer;
border:none;
}
.string:active,
.string.active{
background:linear-gradient(90deg,#ffd700,#fff,#ffd700);
box-shadow:0 0 10px #ffd700;
transform:scaleY(1.5);
}
.string-name{
position:absolute;
right:10px;
top:-8px;
color:#f5deb3;
font-size:10px;
font-weight:bold;
background:#2a1a0a;
padding:2px 5px;
border-radius:4px;
}
#note{
text-align:center;
color:#f5deb3;
font-size:22px;
font-weight:bold;
margin-top:25px;
text-shadow:0 2px 4px #000;
}
</style>
</head>
<body>

<div class="title">GUITAR</div>
<div class="sub">E - A - D - G - B - e</div>

<div class="guitar-wrap">
<div class="guitar">
<div class="hole"></div>
<div class="strings">
<button class="string" data-freq="82.41" data-name="E"><span class="string-name">6-E</span></button>
<button class="string" data-freq="110.00" data-name="A"><span class="string-name">5-A</span></button>
<button class="string" data-freq="146.83" data-name="D"><span class="string-name">4-D</span></button>
<button class="string" data-freq="196.00" data-name="G"><span class="string-name">3-G</span></button>
<button class="string" data-freq="246.94" data-name="B"><span class="string-name">2-B</span></button>
<button class="string" data-freq="329.63" data-name="e"><span class="string-name">1-e</span></button>
</div>
</div>
</div>

<div id="note">Pencet Senarnya!</div>

<script>
let audioContext=null;

function initAudio(){
  if(!audioContext){
    const AudioContext=window.AudioContext||window.webkitAudioContext;
    if(!AudioContext){
      document.getElementById('note').textContent='Audio tidak didukung';
      return null;
    }
    audioContext=new AudioContext();
  }
  if(audioContext.state==='suspended'){
    audioContext.resume();
  }
  return audioContext;
}

function playGuitar(freq){
  const ctx=initAudio();
  if(!ctx)return;
  const now=ctx.currentTime;
  const master=ctx.createGain();
  master.gain.setValueAtTime(0,now);
  master.gain.linearRampToValueAtTime(0.6,now+0.01);
  master.gain.exponentialRampToValueAtTime(0.001,now+2.5);
  master.connect(ctx.destination);

  const osc1=ctx.createOscillator();
  const osc2=ctx.createOscillator();
  const gain1=ctx.createGain();
  const gain2=ctx.createGain();

  osc1.type='sawtooth';
  osc2.type='triangle';
  osc1.frequency.value=freq;
  osc2.frequency.value=freq*2;
  gain1.gain.value=1;
  gain2.gain.value=.3;

  osc1.connect(gain1);
  osc2.connect(gain2);
  gain1.connect(master);
  gain2.connect(master);

  osc1.start(now);
  osc2.start(now);
  osc1.stop(now+2.6);
  osc2.stop(now+2.6);
}

document.querySelectorAll('.string').forEach(function(str){
  function press(e){
    e.preventDefault();
    str.classList.add('active');
    document.getElementById('note').textContent = str.dataset.name;
    playGuitar(parseFloat(str.dataset.freq));
  }
  function release(){
    str.classList.remove('active');
  }
  str.addEventListener('pointerdown',press);
  str.addEventListener('pointerup',release);
  str.addEventListener('pointercancel',release);
  str.addEventListener('pointerleave',release);
});
</script>

</body>
</html>`

      // 3. Susun layout UI pakai AIRich
      const customHtmlSection = AIRich.newLayout('Single', {
        __typename: "GenAIaeacdsnwHtmlPrimitive",
        payload: htmlCode,
        trusted_sources: ["nixel.dev"]
      })

      const customSubmessage = {
        messageType: 2,
        messageText: "Guitar Virtual"
      }

      // 4. Timpa pesan loading dengan widget gitar
      rich._addContent(customHtmlSection, customSubmessage, { replace: 'loading_gitar', id: 'gitar_ready' })

      // 5. Eksekusi Edit Message
      await rich.sendEdit()

    } catch (err) {
      console.error("[GITAR] Error:", err)
      return sock.message.send(m.chat, {
        text: `❌ Gagal memuat gitar:\n${err.message || err}`
      }, {
        additionalAttributes: { type: "text" }
      })
    }
  }
}