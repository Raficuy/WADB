// plugins/game/asahotak.js
import { activeGames } from '../../lib/gameManager.js'

export default {
  command: 'asahotak',
  alias: [],
  category: 'game',
  description: 'Main teka-teki berhadiah saldo RPG.',
  groupOnly: true,

  async execute(m, { sock }) {
    const chatId = m.chat

    if (activeGames.has(chatId)) {
      return m.reply(`Masih ada game *${activeGames.get(chatId).name}* yang belum diselesaikan!\nSelesaikan atau biarkan waktunya habis.`)
    }

    try {
      const res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/refs/heads/master/games/asahotak.json')
      const data = await res.json()
      
      const random = data[Math.floor(Math.random() * data.length)]
      const hadiah = 5000 
      const waktu = 60 
      
      await m.reply(`🧠 *Asah Otak*\n\nSoal: ${random.soal}\nclue: ${random.tipe}\n⏱️ Waktu: ${waktu} detik\n💰 Hadiah: Rp${hadiah}\n\n_👇 Reply / Balas pesan ini dengan jawaban yang benar!_`)
      

      const timer = setTimeout(async () => {
        if (activeGames.has(chatId)) {
          activeGames.delete(chatId) 
          await m.reply(`⏳ WAKTU HABIS!\n\nGame *Asah Otak* dibatalkan.\nJawaban yang benar adalah: *${random.jawaban}*`)
        }
      }, waktu * 1000)

      activeGames.set(chatId, {
        type: 'kuis', 
        name: 'Asah Otak',
        jawaban: random.jawaban,
        hadiah: hadiah,
        timer: timer,
        isReplyRequired: true 
      })

    } catch (e) {
      console.error('[Teka Teki Error]', e)
      return m.reply(`❌ Gagal mengambil data soal.`)
    }
  }
}