import fs from 'fs'
import path from 'path'

// Fungsi buat narik link Cloudflare terbaru dari panel lu
function getCloudflareUrl() {
  const logPaths = [
    path.join(process.cwd(), '../../cloudflared.log'), 
    path.join(process.cwd(), 'cloudflared.log'),
    '/home/container/cloudflared.log',              
    '/tmp/cloudflared.log'                          
  ]

  for (const logPath of logPaths) {
    try {
      if (fs.existsSync(logPath)) {
        const content = fs.readFileSync(logPath, 'utf8')
        const matches = content.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/g)
        if (matches && matches.length > 0) {
          return matches[matches.length - 1] // Ambil link yang paling bawah
        }
      }
    } catch (e) {
      // Abaikan
    }
  }
  return null
}

export default {
  command: 'sakurabrawl',
  alias: ['brawl', 'sbrawl'],
  category: 'game',
  description: 'Bermain Sakura Brawl Multiplayer via Browser',
  typing: true,

  async execute(m) {
    const url = getCloudflareUrl()

    if (!url) {
      return m.reply('❌ *Arena Belum Siap!*\n\nBot tidak menemukan link Cloudflare Tunnel. Pastikan fitur Cloudflare Log menyala di panel dan bot sudah di-restart.')
    }

    const teks = `⚔️ *SAKURA BRAWL MULTIPLAYER* ⚔️\n\n` +
                 `Arena telah dibuka! Ajak teman grupmu untuk saling baku hantam dan lempar bom.\n\n` +
                 `🎮 *Klik link di bawah ini untuk bermain:*\n` +
                 `🔗 ${url}\n\n` +
                 `_Catatan:_ \n` +
                 `1. Buka link menggunakan browser (Chrome/Safari).\n` +
                 `2. Jika muncul halaman peringatan dari Cloudflare, klik tombol biru untuk melanjutkan ke arena.`;

    return m.reply(teks);
  }
}