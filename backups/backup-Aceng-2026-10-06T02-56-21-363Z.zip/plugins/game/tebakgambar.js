import { activeGames } from '../../lib/gameManager.js'

export default {
  command: 'tebakgambar',
  alias: ['tgambar', 'tebakgbr'],
  category: 'game',
  description: 'Main tebak gambar berhadiah saldo RPG.',
  groupOnly: true,

  async execute(m, { sock }) {
    const chatId = m.chat

    if (activeGames.has(chatId)) {
      return m.reply(`Masih ada game *${activeGames.get(chatId).name}* yang belum diselesaikan!\nKetik .nyerah dulu kalo mau ganti game.`)
    }

    try {

      const res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
      const data = await res.json()
      
      const random = data[Math.floor(Math.random() * data.length)]
      const hadiah = 5000 
      const waktu = 60 
      
      const imgRes = await fetch(random.img)
      const imgBuffer = Buffer.from(await imgRes.arrayBuffer())

      await sock.message.send(chatId, {
        type: 'image', 
        media: imgBuffer, 
        mimetype: 'image/jpeg',
        caption: `🖼️ *TEBAK GAMBAR*\n\nClue: ${random.deskripsi}\n\n⏱️ Waktu: ${waktu} detik\n💰 Hadiah: Rp${hadiah}\n\n_👇 Reply / Balas pesan gambar ini dengan jawaban yang benar!_`
      }) 

      const timer = setTimeout(async () => {
        if (activeGames.has(chatId)) {
          activeGames.delete(chatId) 
          await sock.message.send(chatId, { 
            conversation: `⏳ WAKTU HABIS!\n\nGame *Tebak Gambar* dibatalkan.\nJawaban yang benar adalah: *${random.jawaban}*` 
          }, { additionalAttributes: { type: "text" } })
        }
      }, waktu * 1000)

      activeGames.set(chatId, {
        type: 'kuis', 
        name: 'Tebak Gambar',
        jawaban: random.jawaban,
        hadiah: hadiah,
        timer: timer,
        isReplyRequired: true 
      })

    } catch (e) {
      console.error('[Tebak Gambar Error]', e)
      return m.reply(`❌ Gagal: ${e.message}`)
    }
  }
}