export default {
  command: 'shooter',
  alias: ['spaceshooter'],
  category: 'game',
  description: 'Bermain game Space Shooter interaktif dengan efek partikel',
  help: '',
  typing: true,

  async execute(m, { sock }) {
    try {
      const htmlPayload = `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;padding:0;width:100%;min-height:100%;background:transparent;font-family:Arial,Helvetica,sans-serif;color:#fff;overflow:hidden;touch-action:manipulation}
.wrap{width:100%;max-width:380px;margin:auto;padding:10px}
.card{position:relative;overflow:hidden;border-radius:24px;background:linear-gradient(180deg,#171525 0%,#0b0a12 100%);border:1px solid rgba(255,255,255,.13);box-shadow:0 20px 55px rgba(0,0,0,.55),inset 0 1px rgba(255,255,255,.08);padding:15px}
.header{display:flex;align-items:center;justify-content:space-between;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:12px}
.mini{font-size:10px;letter-spacing:2px;color:#77748c;margin-bottom:3px}
.title{font-size:18px;font-weight:800}
.stats{text-align:right;font-size:14px;font-weight:bold;color:#00ffcc}
.canvas-container{position:relative;width:100%;height:400px;background:#07070b;border-radius:14px;border:1px solid rgba(255,255,255,.09);box-shadow:inset 0 7px 18px rgba(0,0,0,.7);overflow:hidden}
canvas{width:100%;height:100%;display:block;touch-action:none}
.overlay{position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.85);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:10;border-radius:14px}
.overlay h2{color:#ff3366;margin:0 0 5px;font-size:28px;font-weight:900;text-shadow:0 0 20px rgba(255,51,102,.6);letter-spacing:2px}
.overlay p{color:#aaa;margin:0 0 20px;font-size:14px;letter-spacing:1px}
.overlay button{background:linear-gradient(135deg,#8270ff,#5946cc);color:#fff;border:none;padding:14px 28px;border-radius:12px;font-weight:900;font-size:14px;letter-spacing:1px;cursor:pointer;box-shadow:0 6px 18px rgba(105,87,229,.4)}
</style>

<div class="wrap">
  <div class="card">
    <div class="header">
      <div>
        <div class="mini">CYLICDEV ARCADE</div>
        <div class="title">Neon Defender 🚀</div>
      </div>
      <div class="stats">SCORE: <span id="score">0</span></div>
    </div>
    
    <div class="canvas-container">
      <canvas id="game" width="300" height="400"></canvas>
      <div class="overlay" id="go">
        <h2>TERBANTAY</h2>
        <p>Skor Akhir: <span id="finalScore">0</span></p>
        <button onclick="reset()">RETRY</button>
      </div>
    </div>
  </div>
</div>

<script>
const cvs = document.getElementById('game');
const ctx = cvs.getContext('2d');
const scoreEl = document.getElementById('score');
const goEl = document.getElementById('go');
const finalScoreEl = document.getElementById('finalScore');

let player, bullets, enemies, particles, score, loop, frames, playing;

function reset() {
  player = { x: 150, y: 360, w: 24, h: 24 };
  bullets = []; enemies = []; particles = [];
  score = 0; frames = 0; playing = true;
  scoreEl.innerText = score;
  goEl.style.display = 'none';
  if(loop) clearInterval(loop);
  loop = setInterval(update, 1000/60);
}

function handleInput(e) {
  if(!playing) return;
  let r = cvs.getBoundingClientRect();
  let scaleX = cvs.width / r.width;
  let clientX = e.touches ? e.touches[0].clientX : e.clientX;
  player.x = (clientX - r.left) * scaleX;
  if(player.x < 12) player.x = 12;
  if(player.x > cvs.width - 12) player.x = cvs.width - 12;
}

cvs.addEventListener('pointermove', handleInput);
cvs.addEventListener('pointerdown', handleInput);
cvs.addEventListener('touchmove', handleInput, {passive: false});

function spawnParticle(x, y, color) {
  for(let i=0; i<12; i++) {
    particles.push({
      x: x, y: y,
      vx: (Math.random()-0.5)*8, vy: (Math.random()-0.5)*8,
      life: 1, color: color
    });
  }
}

function update() {
  frames++;
  ctx.fillStyle = '#07070b';
  ctx.fillRect(0, 0, cvs.width, cvs.height);

  if(frames % 10 === 0) {
    bullets.push({x: player.x, y: player.y - 12, w: 4, h: 16});
  }

  ctx.shadowBlur = 12; 
  ctx.shadowColor = '#00ffcc';
  ctx.fillStyle = '#00ffcc';
  for(let i = bullets.length - 1; i >= 0; i--) {
    let b = bullets[i];
    b.y -= 10;
    ctx.fillRect(b.x - b.w/2, b.y, b.w, b.h);
    if(b.y < 0) bullets.splice(i, 1);
  }

  let spawnRate = Math.max(15, 60 - Math.floor(score/15));
  if(frames % spawnRate === 0) {
    enemies.push({
      x: Math.random() * (cvs.width - 30) + 15,
      y: -20, w: 22, h: 22, hp: score > 150 ? 3 : 2,
      color: Math.random() > 0.5 ? '#ff3366' : '#ffcc00'
    });
  }

  for(let i = enemies.length - 1; i >= 0; i--) {
    let e = enemies[i];
    e.y += 2.5 + score/250;
    
    ctx.shadowColor = e.color;
    ctx.fillStyle = e.color;
    ctx.fillRect(e.x - e.w/2, e.y - e.h/2, e.w, e.h);

    if(Math.abs(e.x - player.x) < (e.w/2 + player.w/2 - 4) && Math.abs(e.y - player.y) < (e.h/2 + player.h/2 - 4)) {
      spawnParticle(player.x, player.y, '#8270ff');
      clearInterval(loop);
      playing = false;
      finalScoreEl.innerText = score;
      setTimeout(() => { goEl.style.display = 'flex'; }, 500);
    }

    for(let j = bullets.length - 1; j >= 0; j--) {
      let b = bullets[j];
      if(Math.abs(e.x - b.x) < e.w/2 && Math.abs(e.y - b.y) < e.h/2) {
        e.hp--;
        bullets.splice(j, 1);
        if(e.hp <= 0) {
          spawnParticle(e.x, e.y, e.color);
          enemies.splice(i, 1);
          score += 10;
          scoreEl.innerText = score;
        }
        break;
      }
    }
    
    if(enemies[i] && e.y > cvs.height + 20) {
      enemies.splice(i, 1);
    }
  }

  ctx.shadowBlur = 8;
  for(let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    p.x += p.vx; p.y += p.vy;
    p.life -= 0.04;
    if(p.life <= 0) { particles.splice(i, 1); continue; }
    ctx.globalAlpha = p.life;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.fillRect(p.x - 2, p.y - 2, 4, 4);
    ctx.globalAlpha = 1;
  }

  ctx.shadowColor = '#8270ff';
  ctx.fillStyle = '#8270ff';
  ctx.beginPath();
  ctx.moveTo(player.x, player.y - player.h/2);
  ctx.lineTo(player.x - player.w/2, player.y + player.h/2);
  ctx.lineTo(player.x + player.w/2, player.y + player.h/2);
  ctx.fill();
  
  ctx.shadowBlur = 0;
}

reset();
</script>`

      await sock.message.send(
        m.chat,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            messageSecret: "0cCzjnQ5ERoqM2QrQ7KjmMfxsyeWYu+61/chr2wioyE=",
            botMetadata: {
              messageDisclaimerText: "",
              botResponseId: "cylicdev-shooter-" + Date.now()
            }
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: "CYLICDEV • NEON DEFENDER"
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(
                    JSON.stringify({
                      response_id: "cylicdev-shooter-" + Date.now(),
                      sections: [
                        {
                          view_model: {
                            primitive: {
                              __typename: "GenAIaeacdsnwHtmlPrimitive",
                              payload: htmlPayload,
                              trusted_sources: ["cylic.dev"]
                            },
                            __typename: "GenAISingleLayoutViewModel"
                          }
                        }
                      ]
                    })
                  ).toString("base64")
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: "867051314767696@bot"
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {
          quote: m.raw,
          additionalAttributes: {
            type: "text"
          }
        }
      )
    } catch (err) {
      return m.reply(`Gagal menjalankan game Shooter: ${err.message || err}`)
    }
  }
}