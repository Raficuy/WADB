import { gotScraping } from 'got-scraping'
import * as cheerio from 'cheerio'

const akiSessions = new Map()

const BASE_URL = 'https://id.akinator.com'
const ANSWERS = { 
    'y': 0, 'ya': 0,
    'n': 1, 'tidak': 1, 
    'i': 2, 'tt': 2, 'gatau': 2, 
    'p': 3, 'mungkin': 3, 
    'pn': 4, 'mungkintidak': 4 
}

async function startAkinator() {
    const jar = {}
    const homeRes = await gotScraping({ url: BASE_URL + '/', throwHttpErrors: false })
    
    if (homeRes.headers['set-cookie']) {
        for (const c of homeRes.headers['set-cookie']) {
            const [k, v] = c.split(';')[0].split('=')
            jar[k.trim()] = v.trim()
        }
    }
    const cookieStr = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ')

    const res = await gotScraping({
        url: BASE_URL + '/game',
        method: 'POST',
        form: { sid: '1', cm: 'false' },
        headers: { 'content-type': 'application/x-www-form-urlencoded', 'cookie': cookieStr },
        throwHttpErrors: false
    })

    const $ = cheerio.load(res.body)
    const question = $('#question-label').text().trim()
    const session = res.body.match(/name="session"[^>]*value="([^"]+)"/)?.[1]
    const signature = res.body.match(/name="signature"[^>]*value="([^"]+)"/)?.[1]

    if (!session || !signature) throw new Error('Gagal menembus server Akinator.')

    return { session, signature, question, step: 0, progression: 0 }
}

async function answerAkinator(session, signature, step, progression, answerId) {
    const res = await gotScraping({
        url: BASE_URL + '/answer',
        method: 'POST',
        form: { step: String(step), progression: String(progression), sid: '1', cm: 'false', answer: String(answerId), session, signature },
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        throwHttpErrors: false
    })

    const data = JSON.parse(res.body)
    if (data.completion === 'KO') throw new Error('Sesi expired mutlak.')

    if (data.id_proposition) {
        return { won: true, name: data.name_proposition, description: data.description_proposition, photo: data.photo }
    }

    return { won: false, question: data.question, step: parseInt(data.step), progression: parseFloat(data.progression) }
}

async function sendAkiButtons(sock, m, title, textBody, buttonsData) {
    const buttons = buttonsData.map(btn => ({
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({
            display_text: btn.text,
            id: btn.id
        })
    }))

    const payload = {
        interactiveMessage: {
            header: { title: title },
            body: { text: textBody },
            footer: { text: "Akinator" },
            nativeFlowMessage: { buttons: buttons }
            
        }
    }

    const extraOpts = {
        additionalNodes: [
            {
                tag: "biz",
                attrs: {},
                content: [
                    {
                        tag: "interactive",
                        attrs: { type: "native_flow", v: "1" },
                        content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                    }
                ]
            }
        ]
    }

    try {
        await sock.message.send(m.chat, payload, extraOpts)
    } catch (err) {
        console.error("[TOMBOL ERROR]", err)
        await m.reply(`❌ *Gagal render UI Tombol:*\n${err.message || err}\n\n_Bermain mode teks aja sementara ketik: .aki y / n / i_`)
    }
}

export default {
    command: 'akinator',
    alias: ['aki'],
    category: 'games',
    description: 'Main tebak karakter bareng Jin Akinator mutlak.',
    help: 'start | stop',
    typing: true,
    wait: true,

    async execute(m, { args, sock }) {
        const action = args[0]?.toLowerCase()
        const sender = m.sender

        const playButtons = [
            { text: "Ya", id: ".aki y" },
            { text: "Tidak", id: ".aki n" },
            { text: "Tidak Tahu", id: ".aki i" },
            { text: "Mungkin", id: ".aki p" },
            { text: "Mungkin Tidak", id: ".aki pn" }
        ]

        if (!action || !['start', 'stop', 'y', 'ya', 'n', 'tidak', 'i', 'tt', 'gatau', 'p', 'mungkin', 'pn', 'mungkintidak'].includes(action)) {
            return await sendAkiButtons(
                sock, m, 
                "🧞‍♂️ AKINATOR GAME", 
                "Main tebak karakter dan lihat apakah Jin ini bisa membaca pikiran lu.\n\nPencet tombol di bawah untuk mulai.", 
                [
                    { text: "Mulai Gam", id: ".aki start" },
                    { text: "Stop", id: ".aki stop" }
                ]
            )
        }

        if (action === 'stop') {
            if (!akiSessions.has(sender)) return m.reply('Lu aja lagi kaga main Akinator.')
            akiSessions.delete(sender)
            return m.reply('Sesi Akinator lu udah gua stop.')
        }

        if (action === 'start') {
            if (akiSessions.has(sender)) {
                return m.reply('Lu masih punya sesi yang gantung! Jawab dulu pertanyaannya atau ketik .aki stop')
            }

            
            try {
                const game = await startAkinator()
                akiSessions.set(sender, game)
                
                return await sendAkiButtons(
                    sock, m,
                    "Akinator Mulai Menerawang...",
                    `*Pertanyaan ${game.step + 1}:*\n📝 ${game.question}`,
                    playButtons
                )
            } catch (err) {
                return m.reply(`*Akinator Error:* ${err.message}`)
            }
        }

        if (akiSessions.has(sender)) {
            const game = akiSessions.get(sender)
            const answerId = ANSWERS[action]

            if (answerId === undefined) return 

            try {
                const result = await answerAkinator(game.session, game.signature, game.step, game.progression, answerId)

                if (result.won) {
                    akiSessions.delete(sender)
                    
                    try {
 
                        const imgRes = await gotScraping({ url: result.photo, responseType: 'buffer' })
                        
                        return m.reply({
                            type: 'image',
                            media: imgRes.body,
                            caption: `*Kemungkinan karakter yang lu maksud ini!*\n\n` +
                                     `*Nama:* ${result.name}\n` +
                                     `*Deskripsi:* ${result.description}\n\n` +
                                     `_Ketik .aki start buat main lagi._`
                        })
                    } catch (dlErr) {
    
                        return m.reply(
                            `*Kemungkinan karakter yang lu maksud ini!*\n\n` +
                            `*Nama:* ${result.name}\n` +
                            `*Deskripsi:* ${result.description}\n\n` +
                            `_(Fotonya gada, tapi tebakannya bener kan?)_\n\n` +
                            `_Ketik .aki start buat main lagi._`
                        )
                    }
                }

                game.step = result.step
                game.progression = result.progression
                akiSessions.set(sender, game) 

                return await sendAkiButtons(
                    sock, m,
                    "🧞‍♂️ Akinator Bertanya",
                    `*Pertanyaan ${result.step + 1}* (Progress: ${result.progression.toFixed(1)}%)\n📝 ${result.question}`,
                    playButtons
                )

            } catch (err) {
                akiSessions.delete(sender)
                return m.reply(`❌ *Koneksi Akinator Terputus:* ${err.message}\n_Sesi dibersihkan. Silakan mulai lagi._`)
            }
        } else {
            return await sendAkiButtons(
                sock, m,
                "🧞‍♂️ AKINATOR GAME",
                "❌ Lu kaga punya sesi aktif. Pencet tombol di bawah buat mulai mutlak.",
                [{ text: "🎮 Mulai Main", id: ".aki start" }]
            )
        }
    }
}