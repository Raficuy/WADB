import { activeGames } from '../../lib/gameManager.js'

export default {
  command: 'nyerah',
  alias: ['stopgame', 'surrender', 'giveup'],
  category: 'game',
  description: 'Menyerah dari game yang sedang berlangsung.',
  groupOnly: true,

  async execute(m, { sock }) {
    const chatId = m.chat

    if (!activeGames.has(chatId)) {
      return m.reply('❌ Kaga ada game yang lagi jalan di grup ini.')
    }

    const session = activeGames.get(chatId)

    if (session.timer) {
      clearTimeout(session.timer)
    }

    activeGames.delete(chatId)

    let pesanNyerah = `YAHH KROCO! Game *${session.name}* Aja gabisa jawab.`
    
    if (session.type === 'kuis' && session.jawaban) {
      pesanNyerah += `\n\nPadahal jawaban yang benar adalah: *${session.jawaban}*`
    }

    await sock.message.send(m.chat, {
  conversation: pesanNyerah
}, {
  additionalAttributes: {"type":"text"}
})

  }
}