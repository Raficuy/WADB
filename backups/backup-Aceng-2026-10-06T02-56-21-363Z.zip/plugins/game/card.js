export default {
  command: 'card',
  alias: ['kartu'],
  category: 'game',
  description: 'Bermain game asah otak Memory Match interaktif',
  help: '',
  typing: true,

  async execute(m, { sock }) {
    try {
      const htmlPayload = `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;padding:0;width:100%;min-height:100%;background:transparent;font-family:Arial,Helvetica,sans-serif;color:#fff;overflow:hidden;touch-action:manipulation}
.wrap{width:100%;max-width:380px;margin:auto;padding:10px}
.card{position:relative;overflow:hidden;border-radius:24px;background:linear-gradient(180deg,#171525 0%,#0b0a12 100%);border:1px solid rgba(255,255,255,.13);box-shadow:0 20px 55px rgba(0,0,0,.55),inset 0 1px rgba(255,255,255,.08);padding:20px}
.header{display:flex;align-items:center;justify-content:space-between;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.08);margin-bottom:14px}
.mini{font-size:10px;letter-spacing:2px;color:#77748c;margin-bottom:3px}
.title{font-size:18px;font-weight:800}
.stats{text-align:right;font-size:14px;font-weight:bold;color:#00ffcc}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.item{aspect-ratio:1;perspective:1000px;cursor:pointer}
.item-inner{width:100%;height:100%;transition:transform .4s;transform-style:preserve-3d;position:relative}
.item.flipped .item-inner{transform:rotateY(180deg)}
.front, .back{position:absolute;width:100%;height:100%;backface-visibility:hidden;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:28px;box-shadow:0 4px 10px rgba(0,0,0,.3)}
.front{background:linear-gradient(135deg,#8270ff,#5946cc);border:1px solid rgba(255,255,255,.2)}
.back{background:#252438;transform:rotateY(180deg);border:1px solid rgba(139,121,255,.4)}
.btn{width:100%;margin-top:16px;padding:14px;background:rgba(255,121,121,.1);color:#ff7979;border:1px solid rgba(255,121,121,.25);border-radius:14px;font-size:14px;font-weight:bold;cursor:pointer;transition:.15s}
.btn:active{transform:scale(.95);background:rgba(255,121,121,.2)}
</style>

<div class="wrap">
  <div class="card">
    <div class="header">
      <div>
        <div class="mini">CYLICDEV ARCADE</div>
        <div class="title">Memory Match 🧠</div>
      </div>
      <div class="stats">MOVES: <span id="moves">0</span></div>
    </div>
    <div class="grid" id="grid"></div>
    <button class="btn" onclick="init()">RESTART GAME</button>
  </div>
</div>

<script>
const emojis = ['🚀','👽','👾','🪐','🛸','☄️','🛰️','👨‍🚀'];
let cards = [], flipped = [], moves = 0, matches = 0, locked = false;
const grid = document.getElementById('grid');
const movesEl = document.getElementById('moves');

function init() {
  grid.innerHTML = '';
  cards = [...emojis, ...emojis].sort(() => Math.random() - 0.5);
  flipped = []; moves = 0; matches = 0; locked = false;
  movesEl.textContent = moves;
  
  cards.forEach((e, i) => {
    const c = document.createElement('div');
    c.className = 'item';
    c.innerHTML = '<div class="item-inner"><div class="front">❓</div><div class="back">'+e+'</div></div>';
    c.onclick = () => flip(c, e);
    grid.appendChild(c);
  });
}

function flip(card, emoji) {
  if (locked || flipped.length === 2 || card.classList.contains('flipped')) return;
  card.classList.add('flipped');
  flipped.push({card, emoji});
  
  if (flipped.length === 2) {
    locked = true;
    moves++;
    movesEl.textContent = moves;
    setTimeout(checkMatch, 600);
  }
}

function checkMatch() {
  if (flipped[0].emoji === flipped[1].emoji) {
    matches++;
    if (matches === 8) {
      setTimeout(() => alert('🎉 YOU WIN IN ' + moves + ' MOVES!'), 300);
    }
  } else {
    flipped[0].card.classList.remove('flipped');
    flipped[1].card.classList.remove('flipped');
  }
  flipped = [];
  locked = false;
}

init();
</script>`

      await sock.message.send(
        m.chat,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            messageSecret: "0cCzjnQ5ERoqM2QrQ7KjmMfxsyeWYu+61/chr2wioyE=",
            botMetadata: {
              messageDisclaimerText: "",
              botResponseId: "cylicdev-memory-" + Date.now()
            }
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: "CYLICDEV • MEMORY MATCH"
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(
                    JSON.stringify({
                      response_id: "cylicdev-memory-" + Date.now(),
                      sections: [
                        {
                          view_model: {
                            primitive: {
                              __typename: "GenAIaeacdsnwHtmlPrimitive",
                              payload: htmlPayload,
                              trusted_sources: ["cylic.dev"]
                            },
                            __typename: "GenAISingleLayoutViewModel"
                          }
                        }
                      ]
                    })
                  ).toString("base64")
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: "867051314767696@bot"
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {
          quote: m.raw,
          additionalAttributes: {
            type: "text"
          }
        }
      )
    } catch (err) {
      return m.reply(`Gagal menjalankan game Memory Match: ${err.message || err}`)
    }
  }
}