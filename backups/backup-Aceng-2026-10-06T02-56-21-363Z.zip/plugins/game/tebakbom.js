import { activeGames } from '../../lib/gameManager.js'
import { addBalance } from '../../lib/rpgDatabase.js'

export default {
  command: 'tebakbom',
  alias: ['bom', 'minesweeper'],
  category: 'game',
  description: 'Main tebak bom pake sistem reply berhadiah duit RPG.',
  groupOnly: true,

  async execute(m, { sock, args }) {
    const chatId = m.chat

    if (args[0] === 'nyerah' || args[0] === 'stop') {
      if (!activeGames.has(chatId)) return m.reply('Kaga ada game tebak bom yang lagi jalan.')
      activeGames.delete(chatId)
      return m.reply('Game dibatalkan! Takut meledak lu ya.')
    }

    if (activeGames.has(chatId)) {
      return m.reply(`Masih ada game *${activeGames.get(chatId).name}* di grup ini!\nBeresin dulu atau ketik \`.tebakbom nyerah\`.`)
    }

    const totalBoxes = 5
    const bombPos = Math.floor(Math.random() * totalBoxes)
    const hadiah = 5000 
    const gameState = {
      bombPos,
      opened: [],
      totalBoxes
    }

    const handleInput = async (msg, sock, input) => {
      const tebakan = parseInt(input.trim())
      
      if (isNaN(tebakan)) return false 

      if (tebakan < 1 || tebakan > gameState.totalBoxes) {
        await msg.reply(`❌ Cuma boleh pilih angka dari 1 sampe ${gameState.totalBoxes} temanku yanh hebat!`)
        return true
      }

      const guessIndex = tebakan - 1

      if (gameState.opened.includes(guessIndex)) {
        await msg.reply(`⚠️ Kotak nomor ${tebakan} udah kebuka dan aman! Reply lagi pake nomor lain.`)
        return true
      }

      if (guessIndex === gameState.bombPos) {
        activeGames.delete(chatId) 
        let ui = ''
        for (let i = 0; i < gameState.totalBoxes; i++) {
          ui += (i === gameState.bombPos) ? '💥 ' : (gameState.opened.includes(i) ? '💎 ' : '📦 ')
        }
        
        await msg.reply(`DUARRRR!!! 💥💥💥\n\n${ui}\n\nLu nebak bom! Game Over, uang lu kaga nambah!`)
        return true
      }

      gameState.opened.push(guessIndex)

      if (gameState.opened.length === (gameState.totalBoxes - 1)) {
        activeGames.delete(chatId)
        let ui = ''
        for (let i = 0; i < gameState.totalBoxes; i++) {
          ui += (i === gameState.bombPos) ? '💣 ' : '💎 '
        }
        
        const saldoBaru = addBalance(msg.sender, hadiah)

        await sock.message.send(chatId, { 
          text: `🎉 GOKILLL! LU MENANG! 🎉\n\n${ui}\n\nSemua kotak aman berhasil ditebak!\n\n🎁 *REWARD*\nHadiah: +Rp${hadiah} 💰\nTotal Uang: Rp${saldoBaru}\nPemenang: @${msg.sender.split('@')[0]}`,
          mentions: [msg.sender]
        }, { additionalAttributes: { type: "text" } })
        
        return true
      }

      let ui = ''
      for (let i = 0; i < gameState.totalBoxes; i++) {
        ui += (gameState.opened.includes(i) ? '💎 ' : '📦 ')
      }
      
      await msg.reply(`Fuhh, AMAN! 💎\n\n${ui}\n\nSisa ${gameState.totalBoxes - gameState.opened.length - 1} kotak lagi.\n*Reply pesan ini* dengan angka buat lanjut tebak!`)
      return true
    }

    activeGames.set(chatId, { 
      type: 'custom', 
      name: 'tebakbom', 
      handleInput, 
      isReplyRequired: true 
    })

    const boxUI = Array(totalBoxes).fill('📦').join(' ')
    await m.reply(`*TEBAK BOM DIMULAI!*\n\n${boxUI}\n\nAda 1 BOM tersembunyi. Buka semua kotak aman untuk menang hadiah *Rp${hadiah}*!\n\n👇 *CARA MAIN:*\n*Reply / Balas* pesan ini dengan angka 1 sampai ${totalBoxes}!`)
  }
}