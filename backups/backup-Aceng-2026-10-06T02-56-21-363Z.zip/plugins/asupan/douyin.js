export default {
  command: 'douyin',
  alias: [],
  category: 'asupan',
  typing: true,
  description: 'Kirim video asupan random (Direct Buffer).',

  async execute(m, { sock }) {
    try {

      const apiUrl = 'https://api.botcahx.eu.org/api/asupan/douyin?apikey=vL5Eg6jo'
      
      const res = await fetch(apiUrl)
      if (!res.ok) {
        return m.reply(`gagal (Status: ${res.status}).`)
      }

      const buffer = Buffer.from(await res.arrayBuffer())

      await sock.message.send(
        m.chat, 
        { 
          type: 'video', 
          media: buffer, 
          mimetype: 'video/mp4', 
          caption: '*Nih asupannya...*' 
        }, 
        { 
          quoted: m 
        }
      )

    } catch (err) {
      console.error('[ASUPAN ERROR]', err)
      return m.reply(`ERROR JIR:\n${err.message || err}`)
    }
  }
}