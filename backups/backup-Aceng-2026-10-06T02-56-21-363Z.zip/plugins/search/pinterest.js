import axios from 'axios'
import { delay } from 'baileys'
import { AIRich } from '../../lib/MessageBuilder.js'

export default {
  command: 'pinterest',
  alias: ['pin', 'pint'],
  category: 'search',
  description: 'Cari gambar Pinterest dengan live rendering.',
  help: '<query>',
  typing: true,

  async execute(m, { sock, args }) {
    const query = args.join(' ').trim()

    if (!query) {
      return sock.message.send(m.chat, { 
        text: '❌ Masukkan query pencarian!\nContoh: .pin furina' 
      }, { 
        additionalAttributes: { type: "text" } 
      })
    }

    try {
      const rich = new AIRich(sock)
        .setTitle('Pinterest Search')
        .addText(`Mencari *${query}*...`, { id: 'status' })
      
      await rich.send(m.chat, { additionalAttributes: { type: "text" } })

      const res = await axios.get('https://wolep.dev/pinterest-search-lite', {
        params: { query },
        timeout: 30000,
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'Accept': 'application/json'
        }
      })

      const urls = res.data?.data
      if (!Array.isArray(urls) || !urls.length) {
        rich.addText(`❌ Tidak ada hasil untuk: *${query}*`, { replace: 'status' })
        return await rich.sendEdit()
      }

      rich.addText(`hasil untuk: *${query}*`, { replace: 'status', id: 'found' })
      await rich.sendEdit()
      await delay(800)

      const images = urls.slice(0, 5)

      for (let i = 0; i < images.length; i++) {
        rich.addImage('', {
          status: 'GENERATING',
          update_text: `Mengunduh gambar ${i + 1}/5...`,
          insertAt: i === 0 ? 'found' : `img_${i - 1}`,
          id: `loading_img_${i}`
        })
        await rich.sendEdit()
        await delay(1200)

        rich.addImage(images[i], { replace: `loading_img_${i}`, id: `img_${i}` })
        await rich.sendEdit()
        await delay(600)
      }

      rich.setFooter('Pinterest')
      await rich.sendEdit()

    } catch (err) {
      return sock.message.send(m.chat, {
        text: `❌ Gagal: ${err.message}`
      }, { additionalAttributes: { type: "text" } })
    }
  }
}