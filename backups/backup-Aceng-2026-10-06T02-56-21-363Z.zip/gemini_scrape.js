#!/usr/bin/env node
/**
 * gemini_scrape.js — alur penuh Gemini via login OAuth Antigravity (tanpa API key).
 * Murni Node.js (axios), dari LOGIN sampai EDIT IMAGE multi-gambar.
 */

import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { fileURLToPath } from 'url'
import axios from 'axios'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const AGY_CLIENT_ID = "1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com"
const AGY_CLIENT_SECRET = "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"
const OAUTH_SCOPES = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
]
const AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
const TOKEN_URL = "https://oauth2.googleapis.com/token"
const REDIRECT_URI = "http://localhost:7777/oauth2callback"

const CA_BASE = "https://daily-cloudcode-pa.googleapis.com/v1internal"
const CA_PROJECT = "aicode-consumers"
const CA_UA = "antigravity/cli/1.2.2 (aidev_client; os_type=linux; arch=amd64; cl=980147163; auth_method=consumer)"

const DEFAULT_MODEL = "gemini-3.5-flash-lite"
const MODELS = ["gemini-3.5-flash-lite", "gemini-3.8-flash-tiered", "gemini-3.1-pro-low"]
const IMAGE_MODEL = "gemini-3.1-flash-image"

const TOKEN_PATH = path.join(__dirname, "gemini_token.json")
const MAX_IMG_BYTES = 15 * 1024 * 1024

const MIME_MAGIC = [
    { magic: Buffer.from([0xff, 0xd8, 0xff]), mime: "image/jpeg" },
    { magic: Buffer.from([0x89, 0x50, 0x4e, 0x47]), mime: "image/png" }, // \x89PNG
    { magic: Buffer.from("GIF8"), mime: "image/gif" },
    { magic: Buffer.from("OggS"), mime: "audio/ogg" },
    { magic: Buffer.from("fLaC"), mime: "audio/flac" },
    { magic: Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), mime: "video/webm" },
    { magic: Buffer.from([0x46, 0x4c, 0x56, 0x01]), mime: "video/x-flv" }, // FLV\x01
]

function b64url(data) {
    return data.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function emailFromIdToken(idToken) {
    try {
        let p = idToken.split(".")[1]
        p += "=".repeat((4 - p.length % 4) % 4)
        return JSON.parse(Buffer.from(p, 'base64').toString('utf-8')).email
    } catch (e) {
        return null
    }
}

function sniffMime(data, fallback) {
    if (data.subarray(0, 4).toString() === "RIFF") {
        return data.subarray(8, 12).toString() === "WEBP" ? "image/webp" : "audio/wav"
    }
    if (data.subarray(4, 8).toString() === "ftyp") {
        const brand = data.subarray(8, 12).toString()
        return ["M4A ", "M4B ", "M4P "].includes(brand) ? "audio/mp4" : "video/mp4"
    }
    for (const { magic, mime } of MIME_MAGIC) {
        if (data.subarray(0, magic.length).equals(magic)) {
            return mime
        }
    }
    return (fallback && fallback.startsWith("image/")) ? fallback : "image/jpeg"
}

function caHeaders(token) {
    return {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        "User-Agent": CA_UA,
    }
}

function loadToken() {
    if (fs.existsSync(TOKEN_PATH)) {
        return JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf-8'))
    }
    return {}
}

function saveToken(d) {
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(d, null, 2))
}

async function authUrl() {
    const verifier = b64url(crypto.randomBytes(48))
    const challenge = b64url(crypto.createHash('sha256').update(verifier).digest())
    saveToken({ verifier, created: Date.now() / 1000 })
    
    const url = `${AUTH_URL}?client_id=${AGY_CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&response_type=code&scope=${encodeURIComponent(OAUTH_SCOPES.join(' '))}&access_type=offline&prompt=select_account%20consent&code_challenge_method=S256&code_challenge=${challenge}`
    
    console.log("1. Buka URL ini di browser, pilih akun Google, setujui semua:\n")
    console.log(url + "\n")
    console.log("2. Browser dialihkan ke localhost:7777 yang gagal dibuka (normal).")
    console.log("3. Copy SELURUH URL address bar (atau kode 4/...), lalu jalankan:")
    console.log(`   node ${path.basename(__filename)} authz '<URL-atau-kode>'`)
}

async function authorize(raw) {
    const tok = loadToken()
    const verifier = tok.verifier
    if (!verifier) {
        console.log("Belum ada sesi login — jalankan perintah 'auth' dulu.")
        return
    }
    let code = raw.trim()
    if (code.includes("code=")) {
        try {
            const urlObj = new URL(code)
            code = urlObj.searchParams.get("code") || ""
        } catch (e) {}
    }
    if (!code.startsWith("4/")) {
        console.log("Kode tidak valid — harus diawali '4/' (dari URL localhost:7777).")
        return
    }
    
    try {
        const r = await axios.post(TOKEN_URL, new URLSearchParams({
            code,
            client_id: AGY_CLIENT_ID,
            client_secret: AGY_CLIENT_SECRET,
            redirect_uri: REDIRECT_URI,
            grant_type: "authorization_code",
            code_verifier: verifier,
        }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
        
        const d = r.data
        if (!d.refresh_token) {
            console.log("Google tidak memberi refresh_token — hapus akses aplikasi di myaccount.google.com/permissions lalu login ulang.")
            return
        }
        
        const email = emailFromIdToken(d.id_token || "") || "tidak-diketahui"
        saveToken({
            email,
            refresh_token: d.refresh_token,
            access_token: d.access_token,
            expires_at: (Date.now() / 1000) + (d.expires_in || 3600),
        })
        console.log(`Login sukses: ${email}`)
        console.log(`Token tersimpan: ${TOKEN_PATH} (refresh_token permanen)`)
    } catch (e) {
        console.log(`Tukar token gagal: ${e.response?.data ? JSON.stringify(e.response.data) : e.message}`)
    }
}

async function getAccessToken() {
    const tok = loadToken()
    if (!tok.refresh_token) {
        console.log("Belum login — jalankan perintah 'auth' lalu 'authz'.")
        process.exit(1)
    }
    if (tok.access_token && (tok.expires_at || 0) > (Date.now() / 1000) + 60) {
        return tok.access_token
    }
    
    try {
        const r = await axios.post(TOKEN_URL, new URLSearchParams({
            client_id: AGY_CLIENT_ID,
            client_secret: AGY_CLIENT_SECRET,
            refresh_token: tok.refresh_token,
            grant_type: "refresh_token"
        }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
        
        const d = r.data
        tok.access_token = d.access_token
        tok.expires_at = (Date.now() / 1000) + (d.expires_in || 3600)
        saveToken(tok)
        return d.access_token
    } catch (e) {
        console.log(`Refresh token gagal (cabut akses?): ${e.response?.data ? JSON.stringify(e.response.data) : e.message}`)
        process.exit(1)
    }
}

async function fetchQuota() {
    const token = await getAccessToken()
    try {
        const r = await axios.post(`${CA_BASE}:retrieveUserQuotaSummary`, { project: CA_PROJECT }, { headers: caHeaders(token) })
        const groups = r.data.groups || []
        for (const g of groups) {
            console.log(`[${g.displayName || '-'}]`)
            for (const b of (g.buckets || [])) {
                const frac = b.remainingFraction
                const pct = frac !== undefined ? `${(frac * 100).toFixed(1)}%` : "?"
                console.log(`  ${(b.bucketId || b.displayName).padEnd(15)} sisa ${pct.padStart(6)}  reset: ${b.resetTime || '-'}`)
            }
        }
    } catch (e) {
        console.log(`Gagal: HTTP ${e.response?.status} - ${e.message}`)
    }
}

async function fetchModels() {
    const token = await getAccessToken()
    try {
        const r = await axios.post(`${CA_BASE}:fetchAvailableModels`, { project: CA_PROJECT }, { headers: caHeaders(token) })
        const j = r.data
        const imgIds = new Set(j.imageGenerationModelIds || [])
        for (const [mid, m] of Object.entries(j.models || {})) {
            if (!mid.startsWith("gemini-") && !imgIds.has(mid)) continue
            const tipe = imgIds.has(mid) ? "IMAGE" : "chat"
            console.log(`  [${tipe.padEnd(5)}] ${mid.padEnd(32)} ${m.displayName || ''}`)
        }
    } catch (e) {
        console.log(`Gagal: HTTP ${e.response?.status} - ${e.message}`)
    }
}

async function generateParts(parts, model, system = null, imageOutput = false, timeout = 60000) {
    const token = await getAccessToken()
    let request = {
        contents: [{ role: "user", parts }],
        generationConfig: { maxOutputTokens: 8192 },
    }
    if (imageOutput) {
        request.generationConfig.responseModalities = ["TEXT", "IMAGE"]
    }
    if (system) {
        request.systemInstruction = { role: "user", parts: [{ text: system }] }
    }
    
    const body = {
        project: CA_PROJECT,
        requestId: `checkpoint/${crypto.randomUUID()}`,
        request,
        model,
        userAgent: "antigravity",
        requestType: "checkpoint",
    }
    
    try {
        const r = await axios.post(`${CA_BASE}:generateContent`, body, { headers: caHeaders(token), timeout })
        const resp = r.data.response || r.data
        let text = "", images = []
        
        for (const cand of (resp.candidates || [])) {
            for (const p of (cand.content?.parts || [])) {
                if (typeof p !== 'object') continue
                if (p.text) text += p.text
                const idata = p.inlineData || p.inline_data
                if (idata && idata.data) {
                    images.push({
                        mime: idata.mimeType || idata.mime_type || "image/png",
                        b64: idata.data,
                    })
                }
            }
        }
        return { text: text.trim(), images, usage: resp.usageMetadata }
    } catch (e) {
        throw new Error(`HTTP ${e.response?.status}: ${e.response?.data ? JSON.stringify(e.response.data) : e.message}`)
    }
}

async function chatProcess(prompt, model = DEFAULT_MODEL, system = null) {
    try {
        const out = await generateParts([{ text: prompt }], model, system)
        console.log(out.text)
        if (out.usage) {
            console.log(`\n--- token: ${out.usage.promptTokenCount || '?'} prompt, ${out.usage.candidatesTokenCount || '?'} output`)
        }
    } catch (e) {
        console.error(e.message)
    }
}

async function downloadImages(urls, maxN = 4) {
    let out = []
    for (const u of urls.slice(0, maxN)) {
        try {
            const r = await axios.get(u.trim(), { responseType: 'arraybuffer', timeout: 120000 })
            const data = Buffer.from(r.data)
            if (data.length > MAX_IMG_BYTES) throw new Error(`${u} > 15MB`)
            out.push({
                mime: sniffMime(data, r.headers['content-type'] || ""),
                b64: data.toString('base64'),
            })
        } catch (e) {
            throw new Error(`Gagal unduh ${u}: ${e.message}`)
        }
    }
    return out
}

async function editImage(prompt, imageUrls) {
    if (imageUrls.length < 1 || imageUrls.length > 4) {
        console.log("Jumlah gambar harus 1-4.")
        return
    }
    try {
        const medias = await downloadImages(imageUrls)
        const parts = medias.map(m => ({ inline_data: { mime_type: m.mime, data: m.b64 } }))
        parts.push({ text: prompt })
        
        const out = await generateParts(parts, IMAGE_MODEL, null, true, 75000)
        if (!out.images || out.images.length === 0) {
            if (out.text) console.log(`Ditolak filter konten / teks saja: ${out.text.substring(0, 300)}`)
            else console.log("Respons kosong (kemungkinan filter konten).")
            return
        }
        out.images.forEach((im, i) => {
            const ext = im.mime.includes("jpeg") ? "jpg" : "png"
            const name = `gemini_edit_${Math.floor(Date.now() / 1000)}_${i + 1}.${ext}`
            fs.writeFileSync(name, Buffer.from(im.b64, 'base64'))
            console.log(`tersimpan: ${name}  (${im.mime}, ${Math.floor(im.b64.length / 1024)} KB b64)`)
        })
        if (out.text) console.log(`catatan model: ${out.text.substring(0, 200)}`)
    } catch (e) {
        console.error(e.message)
    }
}

async function generateImage(prompt) {
    try {
        const out = await generateParts([{ text: prompt }], IMAGE_MODEL, null, true, 75000)
        if (!out.images || out.images.length === 0) {
            console.log(`Tidak ada gambar: ${out.text ? out.text.substring(0, 300) : 'respons kosong'}`)
            return
        }
        out.images.forEach((im, i) => {
            const ext = im.mime.includes("jpeg") ? "jpg" : "png"
            const name = `gemini_gen_${Math.floor(Date.now() / 1000)}_${i + 1}.${ext}`
            fs.writeFileSync(name, Buffer.from(im.b64, 'base64'))
            console.log(`tersimpan: ${name}`)
        })
    } catch (e) {
        console.error(e.message)
    }
}

async function main() {
    const args = process.argv.slice(2)
    const cmd = args[0]
    
    if (!cmd) {
        console.log("Gunakan: auth, authz <code>, quota, models, chat <prompt>, gen <prompt>, edit <prompt> <url...>")
        return
    }

    switch (cmd) {
        case "auth":
            await authUrl()
            break
        case "authz":
            if (!args[1]) return console.log("Butuh argumen kode/URL")
            await authorize(args[1])
            break
        case "quota":
            await fetchQuota()
            break
        case "models":
            await fetchModels()
            break
        case "chat":
            if (!args[1]) return console.log("Butuh argumen prompt")
            await chatProcess(args[1])
            break
        case "gen":
            if (!args[1]) return console.log("Butuh argumen prompt")
            await generateImage(args[1])
            break
        case "edit":
            if (!args[1] || !args[2]) return console.log("Butuh prompt dan minimal 1 URL")
            await editImage(args[1], args.slice(2))
            break
        default:
            console.log("Perintah tidak dikenal.")
    }
}

main()
