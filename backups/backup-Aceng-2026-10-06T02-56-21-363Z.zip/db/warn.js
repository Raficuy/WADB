// db/warn.js
// Data warn per grup per member (SQLite)

import fs from 'fs'
import path from 'path'
import Database from 'better-sqlite3'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const storeDir = path.join(__dirname, '..', 'store')
const dbPath = path.join(storeDir, 'warn.db')

fs.mkdirSync(storeDir, { recursive: true })

const db = new Database(dbPath)
db.pragma('journal_mode = WAL')
db.pragma('synchronous = NORMAL')

db.exec(`
    CREATE TABLE IF NOT EXISTS warns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        jid_group TEXT NOT NULL,
        jid_user TEXT NOT NULL,
        reason TEXT,
        warned_by TEXT,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    )
`)
db.exec(`CREATE INDEX IF NOT EXISTS idx_warns_group_user ON warns (jid_group, jid_user)`)

const stmtAdd = db.prepare(`INSERT INTO warns (jid_group, jid_user, reason, warned_by) VALUES (?, ?, ?, ?)`)
const stmtCount = db.prepare(`SELECT COUNT(*) AS total FROM warns WHERE jid_group = ? AND jid_user = ?`)
const stmtList = db.prepare(`SELECT id, reason, warned_by, created_at FROM warns WHERE jid_group = ? AND jid_user = ? ORDER BY id ASC`)
const stmtLast = db.prepare(`SELECT id FROM warns WHERE jid_group = ? AND jid_user = ? ORDER BY id DESC LIMIT 1`)
const stmtDelete = db.prepare(`DELETE FROM warns WHERE id = ?`)
const stmtClear = db.prepare(`DELETE FROM warns WHERE jid_group = ? AND jid_user = ?`)
const stmtAllWarned = db.prepare(`
    SELECT jid_user, COUNT(*) AS total FROM warns
    WHERE jid_group = ? GROUP BY jid_user ORDER BY total DESC, MAX(id) DESC
`)

export function countWarns(group, user) {
    return stmtCount.get(group, user).total
}

export function addWarn(group, user, reason, by) {
    stmtAdd.run(group, user, reason ?? null, by ?? null)
    return countWarns(group, user)
}

export function getWarns(group, user) {
    return stmtList.all(group, user)
}

// kurangi 1 warn (paling baru). return sisa warn, atau null kalau memang tidak punya
export function removeLastWarn(group, user) {
    const last = stmtLast.get(group, user)
    if (!last) return null
    stmtDelete.run(last.id)
    return countWarns(group, user)
}

// hapus semua warn. return jumlah yang dihapus
export function clearWarns(group, user) {
    return stmtClear.run(group, user).changes
}

export function listWarned(group) {
    return stmtAllWarned.all(group)
}