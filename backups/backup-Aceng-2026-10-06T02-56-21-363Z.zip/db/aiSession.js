// db/aiSession.js
import Database from 'better-sqlite3'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const STORE_DIR = path.join(__dirname, '..', 'store')
const dbPath = path.join(STORE_DIR, 'ai_session.db')

if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true })

const db = new Database(dbPath)

db.pragma('journal_mode = WAL')
db.pragma('synchronous = NORMAL')

db.exec(`
    CREATE TABLE IF NOT EXISTS ai_chats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        jid TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('user', 'model')),
        content TEXT NOT NULL,
        timestamp INTEGER NOT NULL
    )
`)
db.exec(`CREATE INDEX IF NOT EXISTS idx_ai_chats_jid ON ai_chats(jid, id)`)

db.exec(`
    CREATE TABLE IF NOT EXISTS ai_replies (
        msg_id TEXT PRIMARY KEY,
        timestamp INTEGER NOT NULL
    )
`)

const stmtInsert = db.prepare(`INSERT INTO ai_chats (jid, role, content, timestamp) VALUES (?, ?, ?, ?)`)

const stmtGetHistory = db.prepare(`
    SELECT role, content, timestamp FROM (
        SELECT * FROM ai_chats WHERE jid = ? ORDER BY id DESC LIMIT ?
    ) ORDER BY id ASC
`)
const stmtClearHistory = db.prepare(`DELETE FROM ai_chats WHERE jid = ?`)
const stmtMarkReply = db.prepare(`INSERT OR IGNORE INTO ai_replies (msg_id, timestamp) VALUES (?, ?)`)
const stmtIsReply = db.prepare(`SELECT 1 AS ok FROM ai_replies WHERE msg_id = ?`)
const stmtPruneChats = db.prepare(`DELETE FROM ai_chats WHERE timestamp < ?`)
const stmtPruneReplies = db.prepare(`DELETE FROM ai_replies WHERE timestamp < ?`)

export function saveAiMessage(jid, role, content) {
    if (!content) return
    stmtInsert.run(jid, role, content, Math.floor(Date.now() / 1000))
}

export function getAiHistory(jid, limit = 10) {
    return stmtGetHistory.all(jid, limit)
}

export function clearAiHistory(jid) {
    return stmtClearHistory.run(jid).changes
}

export function markAiReply(msgId) {
    if (!msgId) return
    stmtMarkReply.run(String(msgId), Math.floor(Date.now() / 1000))
}

export function isAiReply(msgId) {
    return !!msgId && !!stmtIsReply.get(String(msgId))
}

export function pruneAiData(days = 14) {
    const cutoff = Math.floor(Date.now() / 1000) - days * 86400
    stmtPruneChats.run(cutoff)
    stmtPruneReplies.run(cutoff)
}

pruneAiData()
